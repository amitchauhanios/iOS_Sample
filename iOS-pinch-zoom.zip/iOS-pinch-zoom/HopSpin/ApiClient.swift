//
//  ApiClient.swift
//  HopSpin
//
//  Created by Antonio Carella on 8/17/23.
//

import Foundation

/*
Swaggar docs: https://qa.hopspin.com/openapi/
*/

struct ApiClient {
    var beers: () async throws -> [Beer]
    var beer: (Int) async throws -> BeerDetail
    var beerSearch: (BeerSearch) async throws -> [Beer]
    
    var breweries: () async throws -> [Brewery]
    var brewery: (Int) async throws -> BreweryDetail
    var brewerySearch: (BrewerySearch) async throws -> [Brewery]
    var beersAtBrewery: (Int) async throws -> [Beer]
    var beersAtBrewerySearch: (Int, BeerSearch) async throws -> [Beer]
    
    var artists: () async throws -> [Artist]
    var artist: (Int) async throws -> ArtistDetail
    var artistsSearch: (ArtistSearch) async throws -> [Artist]
    var beersAtArtist: (Int) async throws -> [Beer]
    var beersAtArtistSearch: (Int, BeerSearch) async throws -> [Beer]
    
    var image: (String)  async throws -> Data
}

extension ApiClient {
    private static let decoder = JSONDecoder()
    
    private static let urlSession = {
        let session = URLSession.shared
    }
    
    static let live: ApiClient = .init(
        beers: {
            async let (data, response) = await URLSession.shared.data(from: .beers())
            return try await Self.decoder.decode([Beer].self, from: data)
        },
        beer: { id in
            async let (data, response) = await URLSession.shared.data(from: .beer(id: id))
            return try await Self.decoder.decode(BeerDetail.self, from: data)
        },
        beerSearch: { search in
            async let (data, response) = await URLSession.shared.data(from: .beerSearch(search: search))
            return try await Self.decoder.decode([Beer].self, from: data)
        },
        breweries: {
            async let (data, response) = await URLSession.shared.data(from: .breweries())
            return try await Self.decoder.decode([Brewery].self, from: data)
        },
        brewery: { id in
            async let (data, response) = await URLSession.shared.data(from: .brewery(id: id))
            return try await Self.decoder.decode(BreweryDetail.self, from: data)
        },
        brewerySearch: { search in
            async let (data, response) = await URLSession.shared.data(from: .brewerySearch(search: search))
            return try await Self.decoder.decode([Brewery].self, from: data)
        },
        beersAtBrewery: { id in
            async let (data, response) = await URLSession.shared.data(from: .beersForBrewery(id: id))
            return try await Self.decoder.decode([Beer].self, from: data)
        },
        beersAtBrewerySearch: { id, search in
            async let (data, response) = await URLSession.shared.data(from: .beersForBrewery(breweryId: id, search: search))
            return try await Self.decoder.decode([Beer].self, from: data)
        },
        artists: {
            async let (data, response) = await URLSession.shared.data(from: .artists())
            return try await Self.decoder.decode([Artist].self, from: data)
        },
        artist: { id in
            async let (data, response) = await URLSession.shared.data(from: .artist(id: id))
            return try await Self.decoder.decode(ArtistDetail.self, from: data)
        },
        artistsSearch: { search in
            async let (data, response) = await URLSession.shared.data(from: .artistSearch(search: search))
            return try await Self.decoder.decode([Artist].self, from: data)
        },
        beersAtArtist: { id in
            async let (data, response) = await URLSession.shared.data(from: .beersForArtist(id: id))
            return try await Self.decoder.decode([Beer].self, from: data)
        },
        beersAtArtistSearch: { id, search in
            async let (data, response) = await URLSession.shared.data(from: .beersForArtist(artistId: id, search: search))
            return try await Self.decoder.decode([Beer].self, from: data)
        },
        image: { path in
            async let (data, response) = await URLSession.shared.data(from: .image(path: path))
            return try await data
        }
    )
}

enum HTTPMethod: String {
    case get = "GET"
    case post = "POST"
    
}

struct Endpoint {
    let path: String
    let queryItems: [URLQueryItem]?
    let body: Encodable?
    let env: ApiEnvironment
    let method: HTTPMethod
    
    init(
        path: String,
        queryItems: [URLQueryItem]? = nil,
        body: Encodable? = nil,
        env: ApiEnvironment,
        method: HTTPMethod = .get
    ) {
        self.path = path
        self.queryItems = queryItems
        self.body = body
        self.env = env
        self.method = method
    }
}

struct Environment {
    static let sharedProd = Environment(api: .prod)
    static let sharedQa = Environment(api: .qa)
    static let sharedDev = Environment(api: .dev)
    
    let api: ApiEnvironment
}

struct App {
    static let environment: Environment = .sharedProd
}

enum ApiEnvironment: String {
    case prod = "app"
    case qa
    case dev
}

extension Endpoint {
    static func beers() -> Endpoint {
        .init(
            path: "/app/beers",
            env: App.environment.api
        )
    }
    
    static func beer(id: Int) -> Endpoint {
        .init(
            path: "/app/beers/\(id)",
            env: App.environment.api
        )
    }
    
    static func beerSearch(search: BeerSearch) -> Endpoint {
        .init(
            path: "/app/beers/search",
            body: search,
            env: App.environment.api,
            method: .post
        )
    }
    
    static func breweries() -> Endpoint {
        .init(
            path: "/app/breweries",
            env: App.environment.api
        )
    }
    
    static func brewery(id: Int) -> Endpoint {
        .init(
            path: "/app/breweries/\(id)",
            env: App.environment.api
        )
    }
    
    static func brewerySearch(search: BrewerySearch) -> Endpoint {
        .init(
            path: "/app/breweries/search",
            body: search,
            env: App.environment.api,
            method: .post
        )
    }
    
    static func artists() -> Endpoint {
        .init(
            path: "/app/designers",
            env: App.environment.api
        )
    }
    
    static func artist(id: Int) -> Endpoint {
        .init(
            path: "/app/designers/\(id)",
            env: App.environment.api
        )
    }
    
    static func artistSearch(search: ArtistSearch) -> Endpoint {
        .init(
            path: "/app/designers/search",
            body: search,
            env: App.environment.api,
            method: .post
        )
    }
    
    static func beersForBrewery(id: Int) -> Endpoint {
        .init(
            path: "/app/breweries/\(id)/beers",
            env: App.environment.api
        )
    }
    
    static func beersForBrewery(breweryId: Int, search: BeerSearch) -> Endpoint {
        .init(
            path: "/app/breweries/\(breweryId)/beers/search",
            body: search,
            env: App.environment.api,
            method: .post
        )
    }
    
    static func beersForArtist(id: Int) -> Endpoint {
        .init(
            path: "/app/designers/\(id)/beers",
            env: App.environment.api
        )
    }
    
    static func beersForArtist(artistId: Int, search: BeerSearch) -> Endpoint {
        .init(
            path: "/app/designers/\(artistId)/beers/search",
            body: search,
            env: App.environment.api,
            method: .post
        )
    }
    
    static func image(path: String) -> Endpoint {
        .init(
            path: path,
            env: App.environment.api
        )
    }
}

extension Endpoint {
    // We still have to keep 'url' as an optional, since we're
    // dealing with dynamic components that could be invalid.
    var url: URL? {
        var components = URLComponents()
        components.scheme = "https"
        components.host = "\(env.rawValue).hopspin.com"
        components.path = path
        components.queryItems = queryItems
        
        return components.url
    }
    
    func request() throws -> URLRequest  {
        guard let url = url else {
            throw ApiError.invalidURL
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = method.rawValue
        request.setValue("Zps8gpwPCzQ6t1zRhmazOnQCj5ZKVgV3HWCHWWLxZG8Qi04khSxOfoEsE7qU13HH", forHTTPHeaderField: "apikey")
        
        if let body {
            request.httpBody = try JSONEncoder().encode(body)
        }
        
        return request
    }
}

enum ApiError: Error {
    case invalidURL
}

extension URLSession {
    
    func data(from endpoint: Endpoint)  async throws -> (Data, URLResponse) {
        try await data(for: endpoint.request())
    }
}
