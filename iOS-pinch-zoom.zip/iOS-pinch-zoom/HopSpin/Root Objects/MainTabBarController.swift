//
//  MainTabBarController.swift
//  HopSpin
//
//  Created by Antonio Carella on 8/20/23.
//

import UIKit
import SwiftUI
import Combine
import OrderedCollections

protocol SearchResultSelectedHandler: AnyObject {
    
    func navigateToFilters(
        _ filters: OrderedDictionary<String, [FilterParam]>,
        selected selectedFilters: FiltersAndOperator,
        tintColor: UIColor,
        offset: CGFloat,
        sectionTitleItem: FilterSectionItem,
        applyFiltersHandler: ((FiltersAndOperator) -> Void)?
    )
    
    func navigateToSorting(
        _ sortingOptions: [String],
        selected selectedSorting: (OrderOption, String),
        applySortingHandler: (((OrderOption, String)) -> Void)?,
        tintColor: UIColor,
        offset: CGFloat,
        sectionTitleItem: SortSectionTitleItem
    )
    
    func navigateToBrewery(_ brewery: Brewery)
    func navigateToBeer(_ beer: Beer, shouldUpdate: PassthroughSubject<Void, Never>?, tintColor: UIColor?)
    func navigateToArtist(_ artist: Artist)
}

class MainTabBarController: UITabBarController {
        
    private let discoverNavigationController: NavigationController
    private let favoriteViewController: NavigationController
    private let cellarViewController: NavigationController
    private let profileViewController: NavigationController
    
    // Filters custom presenter
    let slideUpTransitionDelegate = SlideUpTransitionDelegate()
    
    init(
        discoverNavigationController: NavigationController,
        favoriteViewController: NavigationController,
        cellarViewController: NavigationController,
        profileViewController: NavigationController
    ) {
        self.discoverNavigationController = discoverNavigationController
        self.favoriteViewController = favoriteViewController
        self.cellarViewController = cellarViewController
        self.profileViewController = profileViewController
        
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupTabs()
        style()
        delegate = self
    }
    
    private func setupTabs() {
        discoverNavigationController.tabBarItem = UITabBarItem(title: "Discover", image: .init(systemName: "hands.and.sparkles"), tag: 0)
        discoverNavigationController.tabBarItem.selectedImage = .init(systemName: "hands.and.sparkles.fill")
        
        favoriteViewController.tabBarItem = UITabBarItem(title: "Releases", image: .init(systemName: "calendar"), tag: 2)
        favoriteViewController.tabBarItem.selectedImage = .init(named: "calendar.fill")
        
        cellarViewController.tabBarItem = UITabBarItem(title: "My Cellar", image: .init(systemName: "cabinet"), tag: 3)
        cellarViewController.tabBarItem.selectedImage = .init(systemName: "cabinet.fill")
        
        profileViewController.tabBarItem = UITabBarItem(title: "My Profile", image: .init(systemName: "person.text.rectangle"), tag: 3)
        profileViewController.tabBarItem.selectedImage = .init(systemName: "person.text.rectangle.fill")
        
        setViewControllers([
            discoverNavigationController,
            favoriteViewController,
            cellarViewController,
            profileViewController
        ], animated: false)
    }
    
    private func style() {
        let appearance = UITabBarAppearance()
        appearance.configureWithDefaultBackground()
            
        appearance.compactInlineLayoutAppearance.normal.iconColor = .white
        appearance.compactInlineLayoutAppearance.selected.iconColor = .white
        appearance.compactInlineLayoutAppearance.normal.titleTextAttributes = [.foregroundColor : UIColor.white, .font: UIFont.systemFont(ofSize: 10.0, weight: .medium)]
        appearance.compactInlineLayoutAppearance.selected.titleTextAttributes = [.foregroundColor : UIColor.white, .font: UIFont.systemFont(ofSize: 10.0, weight: .medium)]
        
        appearance.inlineLayoutAppearance.normal.iconColor = .white
        appearance.inlineLayoutAppearance.selected.iconColor = .white
        appearance.inlineLayoutAppearance.normal.titleTextAttributes = [.foregroundColor : UIColor.white, .font: UIFont.systemFont(ofSize: 10.0, weight: .medium)]
        appearance.inlineLayoutAppearance.selected.titleTextAttributes = [.foregroundColor : UIColor.white, .font: UIFont.systemFont(ofSize: 10.0, weight: .medium)]
        
        appearance.stackedLayoutAppearance.normal.iconColor = .white
        appearance.stackedLayoutAppearance.selected.iconColor = .white
        appearance.stackedLayoutAppearance.normal.titleTextAttributes = [.foregroundColor : UIColor.white, .font: UIFont.systemFont(ofSize: 10.0, weight: .medium)]
        appearance.stackedLayoutAppearance.selected.titleTextAttributes = [.foregroundColor : UIColor.white, .font: UIFont.systemFont(ofSize: 10.0, weight: .medium)]
                
        appearance.shadowImage = nil
        appearance.shadowColor = nil
        
        appearance.backgroundImage = UIImage(named: "navigation-header-background")
        
        tabBar.standardAppearance = appearance
        tabBar.scrollEdgeAppearance = tabBar.standardAppearance
        view.backgroundColor = .white
    }
    
}

extension MainTabBarController: UITabBarControllerDelegate {
    
    func tabBarController(_ tabBarController: UITabBarController, shouldSelect viewController: UIViewController) -> Bool {
        return viewController != tabBarController.selectedViewController
    }
}

extension MainTabBarController: SearchResultSelectedHandler {
    
    func navigateToFilters(
        _ filters: OrderedDictionary<String, [FilterParam]>,
        selected selectedFilters: FiltersAndOperator,
        tintColor: UIColor,
        offset: CGFloat,
        sectionTitleItem: FilterSectionItem,
        applyFiltersHandler: ((FiltersAndOperator) -> Void)?
    ) {
        
        let viewModel = AppDependencyContainer.makeFiltersViewModel(
            tintColor: tintColor,
            filteringParams: filters,
            selectedFilters: selectedFilters,
            applyFiltersHandler: applyFiltersHandler,
            sectionTitleItem: sectionTitleItem
        )
        let viewController = AppDependencyContainer.createFiltersViewController(viewModel: viewModel)
        
        viewController.modalPresentationStyle = .custom
        slideUpTransitionDelegate.topOffset = offset
        viewController.transitioningDelegate = slideUpTransitionDelegate

        guard let navigationController = viewControllers?[selectedIndex] as? NavigationController else {
            assertionFailure("Navigation Controller not set correctly")
            return
        }
        
        if let presented = navigationController.presentedViewController {
            presented.present(viewController, animated: true)
        } else {
            navigationController.present(viewController, animated: true)
        }
    }

    func navigateToSorting(
        _ sortingOptions: [String],
        selected selectedSorting: (OrderOption, String),
        applySortingHandler: (((OrderOption, String)) -> Void)?,
        tintColor: UIColor,
        offset: CGFloat,
        sectionTitleItem: SortSectionTitleItem
    ) {
        let viewModel = AppDependencyContainer.makeSortingViewModel(
            sortingOptions: sortingOptions,
            selectedSorting: selectedSorting,
            applySortingHandler: applySortingHandler,
            tintColor: tintColor, 
            sectionTitleItem: sectionTitleItem
        )
        
        let viewController = AppDependencyContainer.createSortingViewController(viewModel: viewModel)
        viewController.modalPresentationStyle = .custom
        slideUpTransitionDelegate.topOffset = offset
        viewController.transitioningDelegate = slideUpTransitionDelegate
        
        guard let navigationController = viewControllers?[selectedIndex] as? NavigationController else {
            assertionFailure("Navigation Controller not set correctly")
            return
        }
        
        if let presented = navigationController.presentedViewController {
            presented.present(viewController, animated: true)
        } else {
            navigationController.present(viewController, animated: true)
        }
    }
    
    func navigateToBrewery(_ brewery: Brewery) {
        DispatchQueue.main.async { [weak self] in
            guard let self else { return }
            let viewModel = AppDependencyContainer.makeBreweryDetailViewModel(brewery: brewery)
            viewModel.delegate = self
            let tintColor = StyleKit.parseUIColor(string: brewery.iosHeaderTextColor.coallesceToEmpty, fallback: Colors.hopspinGreen)
            let navigationController = self.getNavigationControllerForDetailPresentations()
            let newAppearance = NavigationBarAppearance(backgroundColor: tintColor, statusBarStyle: brewery.iosStatusBarColor.coallesceToEmpty.statusBarColor.statusBarStyle)
            let breweryDetailView = BreweryDetailView(viewModel: viewModel)
            let hostingController = BreweryHostingControler(rootView: breweryDetailView, navBarAppearance: newAppearance)
            hostingController.title = brewery.name
            hostingController.navigationItem.backButtonDisplayMode = .minimal
            hostingController.hidesBottomBarWhenPushed = true
            navigationController.pushViewController(hostingController, animated: true)
        }
    }
    
    func navigateToBeer(_ beer: Beer, shouldUpdate: PassthroughSubject<Void, Never>?, tintColor: UIColor?) {
        let viewModel = BeerDetailViewModel(beer: beer, apiClient: .live, shouldUpdate: shouldUpdate, tintColor: tintColor)
        let tintColor = StyleKit.parseUIColor(string: beer.iosHeaderTextColor, fallback: Colors.hopspinGreen)
        let newAppearance = NavigationBarAppearance(backgroundColor: tintColor, statusBarStyle: beer.iosStatusBarColor.statusBarColor.statusBarStyle)
        let beerDetailViewController = BeerDetailViewController(viewModel: viewModel, navigationBarAppearance: newAppearance)
        beerDetailViewController.lockModal()
        beerDetailViewController.hidesBottomBarWhenPushed = true
        let navigationController = self.getNavigationControllerForDetailPresentations()
        viewModel.menuPresenter = navigationController
        viewModel.threeDPresenter = navigationController
        navigationController.pushViewController(beerDetailViewController, animated: true)
    }
    
    func getNavigationControllerForDetailPresentations() -> NavigationController {
        // if there is a presented navigation controller
        // on top of the search results navigation controller, use that one
        
        // If we're in the Discovery Tab
        if selectedIndex == 0 {
            // This should always be true
            let navigationController = viewControllers!.first as! NavigationController
            
            if let presented = navigationController.presentedViewController as? NavigationController {
                return presented
            }
            
            return navigationController
        } else if selectedIndex == 1 {
            // If we're in the Search tab
            let navigationController = viewControllers![1] as! NavigationController
            
            if let presented = navigationController.presentedViewController as? NavigationController,
               presented.viewControllers.first is BeerCellarViewController {
                return presented
            }
            
            return navigationController
        }
        // Otherwise assert and return a new navigation controller in prod
        assertionFailure("We're looking in the wrong place to present a beer")
        return NavigationController(rootViewController: UIViewController())
    }
    
    func navigateToArtist(_ artist: Artist) {
        DispatchQueue.main.async { [weak self] in
            guard let self else { return }
            let viewModel = AppDependencyContainer.makeArtistDetailViewModel(artist: artist)
            viewModel.delegate = self
            let tintColor = StyleKit.parseUIColor(string: artist.iosHeaderTextColor.coallesceToEmpty, fallback: Colors.hopspinGreen)
            let navigationController = self.getNavigationControllerForDetailPresentations()
            let newAppearance = NavigationBarAppearance(backgroundColor: tintColor, statusBarStyle: .lightContent)
            let artistDetailView = ArtistDetailView(viewModel: viewModel)
            let hostingController = ArtistHostingControler(rootView: artistDetailView, navBarAppearance: newAppearance)
            hostingController.title = artist.name
            hostingController.navigationItem.backButtonDisplayMode = .minimal
            hostingController.hidesBottomBarWhenPushed = true
            navigationController.pushViewController(hostingController, animated: true)
        }
    }
}

extension MainTabBarController {
    
    private func getDiscoveryNavigationController() -> NavigationController {
        if let searchViewController = viewControllers?
            .compactMap({ $0 as? NavigationController })
            .filter({ $0.viewControllers.first is DiscoverViewController })
            .first {
                return searchViewController
        }
        
        assertionFailure("Can't find search view controller")
        return NavigationController(rootViewController: UIViewController())
        
    }
}

extension MainTabBarController: DetailsPresenter {

    func presentBeers(breweryDetail: BreweryDetail) {
        let viewModel = AppDependencyContainer.makeBeerCellarViewModel(breweryDetail: breweryDetail)
        viewModel.delegate = self
        let viewController = AppDependencyContainer.makeBeerCellarViewController(viewModel: viewModel)
        viewController.isModalInPresentation = true
        let navigationController = getDiscoveryNavigationController()
        navigationController.present(viewController, animated: true)
    }
    
    func presentBeers(artistDetail: ArtistDetail) {
        let viewModel = AppDependencyContainer.makeBeerCellarViewModel(artistDetail: artistDetail)
        viewModel.delegate = self
        let viewController = AppDependencyContainer.makeBeerCellarViewController(viewModel: viewModel)
        viewController.isModalInPresentation = true
        let navigationController = getDiscoveryNavigationController()
        navigationController.present(viewController, animated: true)
    }
    
    func presentArtists(name: String, tint: UIColor) {
        print("present artists")
    }
        
    func presentLocations(viewModel: LocationViewModel) {
        let viewController = AppDependencyContainer.makeLocationViewController(locationViewModel: viewModel)
        viewController.isModalInPresentation = true
        let navigationController = getDiscoveryNavigationController()
        navigationController.present(viewController, animated: true)
    }
}

extension MainTabBarController {
    
    func setTabBarVisible(
        visible: Bool,
        duration: TimeInterval = StyleKit.animationDuration,
        animated: Bool = true,
        tableView: UITableView
    ) {
       if (tabBarIsVisible() == visible) { return }
       let frame = self.tabBar.frame
       let height = frame.size.height
       let offsetY = visible ? -height : height
       
       UIViewPropertyAnimator(duration: duration, curve: .linear) {
           self.tabBar.frame = CGRect(x: 0, y: self.view.frame.height+offsetY, width: self.view.frame.width, height: height)

           tableView.frame = CGRect(x: tableView.frame.origin.x, y:  tableView.frame.origin.y, width:  tableView.bounds.width, height:  tableView.bounds.height+offsetY)

           self.view.setNeedsDisplay()
           self.view.layoutIfNeeded()
        }
       .startAnimation()
   }

    func tabBarIsVisible() ->Bool {
        return self.tabBar.frame.origin.y < UIScreen.main.bounds.height
    }
    
}
