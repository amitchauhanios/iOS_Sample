//
//  SceneDelegate.swift
//  HopSpin
//
//  Created by Antonio Carella on 8/15/23.
//

import UIKit
import Combine
import OrderedCollections

class SceneDelegate: UIResponder, UIWindowSceneDelegate {

    var window: UIWindow?

    func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
        let mainTabBarController = AppDependencyContainer.createMainTabBarController()
        
        guard let windowScene = (scene as? UIWindowScene) else { return }
        window = UIWindow(windowScene: windowScene)
        window?.makeKeyAndVisible()
        window?.overrideUserInterfaceStyle = .light
        window?.rootViewController = mainTabBarController
    }

}
