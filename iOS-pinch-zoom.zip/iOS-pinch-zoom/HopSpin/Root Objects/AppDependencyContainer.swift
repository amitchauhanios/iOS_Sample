//
//  AppDependencyContainer.swift
//  HopSpin
//
//  Created by Antonio Carella on 8/20/23.
//

import UIKit
import OrderedCollections

class AppDependencyContainer {
    private static let filtersStoryboard = UIStoryboard(name: "Filters", bundle: nil)
    private static let sortingStoryboard = UIStoryboard(name: "Sorting", bundle: nil)

    static func createMainTabBarController() -> MainTabBarController {
        
        let discoveryViewModel = Self.makeDiscoveryViewModel()
        let discoverViewController = DiscoverViewController(viewModel: discoveryViewModel)
        let discoverNavigationController = NavigationController(rootViewController: discoverViewController)
        
        let mainTabBarController =  MainTabBarController(
            discoverNavigationController: discoverNavigationController,
            favoriteViewController: NavigationController(rootViewController: PlaceholderViewController()),
            cellarViewController: NavigationController(rootViewController: PlaceholderViewController()),
            profileViewController: NavigationController(rootViewController: PlaceholderViewController())
        )
                
        discoveryViewModel.delegate = mainTabBarController
        return mainTabBarController
    }
    
    static func makeDiscoveryViewModel() -> DiscoverViewModel {
        
        let imageCache = KingFisherImageCache()
        let imageRepository = HopSpinImageRepository(cache: imageCache, api: .live)
        
        return DiscoverViewModel(
            imageRepository: imageRepository
        )
    }

    static func makeFiltersViewModel(
        tintColor: UIColor,
        filteringParams: OrderedDictionary<String, [FilterParam]>,
        selectedFilters: FiltersAndOperator,
        applyFiltersHandler: ((FiltersAndOperator) -> Void)?,
        sectionTitleItem: FilterSectionItem
    ) -> FiltersViewModel {
        FiltersViewModel(
            tintColor: tintColor,
            filteringParams: filteringParams,
            selectedFilters: selectedFilters,
            applyFiltersHandler: applyFiltersHandler,
            sectionTitleItem: sectionTitleItem
        )
    }

    static func createFiltersViewController(viewModel: FiltersViewModel) -> UIViewController {
        FiltersContainerViewController(viewModel: viewModel)
    }

    static func makeSortingViewModel(
        sortingOptions: [String],
        selectedSorting: (OrderOption, String),
        applySortingHandler: (((OrderOption, String)) -> Void)?,
        tintColor: UIColor,
        sectionTitleItem: SortSectionTitleItem
    ) -> SortingViewModel {
        SortingViewModel(
            sortingOptions,
            selected: selectedSorting,
            applySortingHandler: applySortingHandler,
            tintColor: tintColor,
            sectionTitleItem: sectionTitleItem
        )
    }

    static func createSortingViewController(viewModel: SortingViewModel) -> UIViewController {
        SortingViewController(viewModel: viewModel)
    }
    
    @MainActor static func makeBreweryDetailViewModel(brewery: Brewery) -> BreweryDetailViewModel {
        BreweryDetailViewModel(breweryFetch: ApiClient.live.brewery, brewery: brewery)
    }
    
    @MainActor static func makeArtistDetailViewModel(artist: Artist) -> ArtistDetailViewModel {
        ArtistDetailViewModel(artistFetch: ApiClient.live.artist, artist: artist)
    }
    
    static func makeLocationViewController(locationViewModel: LocationViewModel) -> NavigationController {
        let viewController = LocationsHostingViewController(viewModel: locationViewModel)
        let appearance = NavigationBarAppearance(backgroundColor: locationViewModel.tintColor)
        let navigationController = NavigationController(rootViewController: viewController, appearance: appearance)
        return navigationController
    }
    
    static func makeBeerCellarViewModel(breweryDetail: BreweryDetail) -> BeerCellarViewModel {
        let imageCache = KingFisherImageCache()
        let imageRepository = HopSpinImageRepository(cache: imageCache, api: .live)
                
        return BeerCellarViewModel(
            sharedNetworkProvider: BreweryBeerCellarNetworkProvider(breweryId: breweryDetail.ID, apiClient: .live),
            name: breweryDetail.name,
            imageRepository: imageRepository,
            tintColor: StyleKit.parseUIColor(
                string: breweryDetail.iosHeaderTextColor,
                fallback: Colors.hopspinGreen
            ),
            secondaryTintColor: StyleKit.parseUIColor(
                string: breweryDetail.iosPressHoldColor.coallesceToEmpty,
                fallback: Colors.pressAndHoldGreen
            ),
            searchControlBarBackground: StyleKit.parseUIColor(
                string: breweryDetail.iosHeaderTextColorLight,
                fallback: Colors.hopSpinLightGreen
            )
        )
    }
    
    static func makeBeerCellarViewModel(artistDetail: ArtistDetail) -> BeerCellarViewModel {
        let imageCache = KingFisherImageCache()
        let imageRepository = HopSpinImageRepository(cache: imageCache, api: .live)
                
        return BeerCellarViewModel(
            sharedNetworkProvider: ArtistBeerCellarNetworkProvider(artistId: artistDetail.ID, apiClient: .live),
            name: artistDetail.name,
            imageRepository: imageRepository,
            tintColor: StyleKit.parseUIColor(
                string: artistDetail.iosHeaderTextColor.coallesceToEmpty,
                fallback: Colors.hopspinGreen)
            ,
            secondaryTintColor: StyleKit.parseUIColor(
                string: artistDetail.iosPressHoldColor.coallesceToEmpty,
                fallback: Colors.pressAndHoldGreen
            ),
            searchControlBarBackground: StyleKit.parseUIColor(
                string: artistDetail.iosHeaderTextColorLight.coallesceToEmpty,
                fallback: Colors.hopSpinLightGreen
            )
        )
    }
    
    static func makeBeerCellarViewController(viewModel: BeerCellarViewModel) -> NavigationController {
        let viewController = BeerCellarViewController(viewModel: viewModel)
        let appearance = NavigationBarAppearance(backgroundColor: viewModel.tintColor)
        return NavigationController(rootViewController: viewController, appearance: appearance)
    }
    
}
