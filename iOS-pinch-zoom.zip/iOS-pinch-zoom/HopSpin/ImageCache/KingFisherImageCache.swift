//
//  KingFisherImageCache.swift
//  BlockDirectory
//
//  Created by Antonio Carella on 8/5/23.
//

import Kingfisher
import UIKit

struct KingFisherImageCache: ImageCacheable {
    
    private let cache = ImageCache.default
    
    func getImage(for key: String) async throws -> UIImage? {
        return try await withCheckedThrowingContinuation { continuation in
            cache.retrieveImage(forKey: key) { result in
                switch result {
                case .success(let value):
                    guard let image = value.image else {
                        continuation.resume(with: .success(nil))
                        return
                    }
                    
                    continuation.resume(with: .success(image))
                    
                case .failure(let error):
                    continuation.resume(throwing: error)
                }
            }
        }
    }
    
    func set(image: UIImage, for key: String) {
        cache.store(image, forKey: key, options: .init(nil))
    }
}


