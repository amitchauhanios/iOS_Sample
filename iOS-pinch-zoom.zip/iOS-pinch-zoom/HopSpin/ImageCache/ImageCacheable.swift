//
//  ImageCacheable.swift
//  BlockDirectory
//
//  Created by Antonio Carella on 8/5/23.
//

import UIKit

protocol ImageCacheable {
    
    /// Asynchronously fetches image for a cache key.
    /// - Parameter key: String value of the key where the cached image was stored.
    /// - Returns: Optional UIImage, if found, nil otherwise.
    func getImage(for key: String) async throws -> UIImage?
        
    /// Sets UIImage in cache with given key
    /// - Parameters:
    ///   - image: the UIImage to set.
    ///   - key: the key to set the image with.
    func set(image: UIImage, for key: String)
}
