//
//  ImageRepository.swift
//  HopSpin
//
//  Created by Antonio Carella on 8/6/23.
//

import UIKit

protocol ImageRepository {
    
    /// Will attempt to fetch a UIImage from a local cache, using the provided url as the cahche key.
    /// If the image can't be found in the cache, will attempt to fetch from the network at the given url.
    /// - Parameter path: The url path to locate the UIImage, either in the cache, or on the network.
    /// - Returns: A UIImage, if found, nil otherwise.
    func image(path: String) async throws -> UIImage?
    
}

