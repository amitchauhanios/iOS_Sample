//
//  HopSpinImageRepository.swift
//  HopSpin
//
//  Created by Antonio Carella on 8/20/23.
//

import UIKit

class HopSpinImageRepository: ImageRepository {
    
    private let cache: ImageCacheable
    private let api: ApiClient
    
    init(cache: ImageCacheable, api: ApiClient) {
        self.cache = cache
        self.api = api
    }
    
    func image(path: String) async throws -> UIImage? {
        
        if let image = try await cache.getImage(for: path) {
            return image
        }
                
        let data = try await api.image(path)
        if let image = UIImage(data: data) {
            cache.set(image: image, for: path)
            return image
        }
        
        return nil
    }
    
}

extension HopSpinImageRepository {
    static let mock: HopSpinImageRepository = .init(cache: KingFisherImageCache(), api: .live)
}
