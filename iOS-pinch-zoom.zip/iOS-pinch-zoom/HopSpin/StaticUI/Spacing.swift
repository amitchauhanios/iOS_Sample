//
//  Spacing.swift
//  HopSpin
//
//  Created by Antonio Carella on 1/31/24.
//

import Foundation
import UIKit

struct Spacing {
    static let sectionalVSpacing = 40.0
    static let interiorVSpacing = 20.0
    static let detailVSpacing = 4.0
    
    static func makeSectionalSpacer() -> UIView {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            view.heightAnchor.constraint(equalToConstant: Spacing.sectionalVSpacing)
        ])
        view.setContentHuggingPriority(.required, for: .vertical)
        view.setContentCompressionResistancePriority(.required, for: .vertical)
        
        return view
    }
    
    static func makeInteriorSpacer() -> UIView {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            view.heightAnchor.constraint(equalToConstant: Spacing.interiorVSpacing)
        ])
        view.setContentHuggingPriority(.required, for: .vertical)
        view.setContentCompressionResistancePriority(.required, for: .vertical)
        
        return view
    }
    
    static func makeDetailSpacer() -> UIView {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            view.heightAnchor.constraint(equalToConstant: Spacing.detailVSpacing)
        ])
        view.setContentHuggingPriority(.required, for: .vertical)
        view.setContentCompressionResistancePriority(.required, for: .vertical)
        
        return view
    }
    
}
