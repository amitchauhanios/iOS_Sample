//
//  StyleKit.swift
//  HopSpin
//
//  Created by Antonio Carella on 8/20/23.
//

import UIKit
import SwiftUI

struct StyleKit {
    
    static let cornerRadius: CGFloat = 15.0
    static let animationDuration: TimeInterval = 0.2
    
    static func bold(searchText: String, in targetText: String, fontSize: Double) -> NSMutableAttributedString {
        let attributedString = NSMutableAttributedString(string: targetText)
            
            let regularFont = UIFont.systemFont(ofSize: fontSize)
            attributedString.addAttribute(.font, value: regularFont, range: NSRange(targetText.startIndex..<targetText.endIndex, in: targetText))
            
            let boldFont = UIFont.boldSystemFont(ofSize: fontSize)
            var searchStartIndex = targetText.startIndex
            
            while let range = targetText.range(of: searchText, options: [.caseInsensitive], range: searchStartIndex..<targetText.endIndex) {
                let nsRange = NSRange(range, in: targetText)
                attributedString.addAttribute(.font, value: boldFont, range: nsRange)
                            
                searchStartIndex = range.upperBound
            }
            
            return attributedString
    }
    
    static func parseColor(string: String, fallBack: Color) -> Color {
        guard let values = parseValues(string: string) else {
            return fallBack
        }
        
        return Color(red: values[0], green: values[1], blue: values[2], opacity: values[3])
    }
    
    static func parseUIColor(string: String, fallback: UIColor) -> UIColor {
        guard let values = parseValues(string: string) else {
            return fallback
        }
        
        return UIColor(red: values[0], green: values[1], blue: values[2], alpha: values[3])
    }
    
    private static func parseValues(string: String) -> [Double]? {
        let tintColorValues = string
            .replacingOccurrences(of: "rgba(", with: "")
            .replacingOccurrences(of: " ", with: "")
            .dropLast()
            .split(separator: ",")
            
        
        if tintColorValues.count != 4 {
            return nil
        }
        
        var doubles: [Double] = tintColorValues.dropLast().compactMap { Double($0) }.map { $0 / 255 }
        guard let last = tintColorValues.last,
                let opacity = Double(last),
                doubles.count == 3 else
        {
                return nil
        }
        
        doubles.append(opacity)
        
        return doubles
    }
}

struct Colors {

    static let dimmedWhite = UIColor(red: 1, green: 1, blue: 1, alpha: 0.75)
    //HopSpin Green - Light = RGBa(92, 154, 83, 1)
    static let hopSpinLightGreen = UIColor(r: 92, g: 154, b: 83)
    //HopSpin Green = RGBa(34, 127, 18, 1)
    static let hopspinGreen = UIColor(r: 34, g: 127, b: 18)
    // HopSpin Green - Press and Hold = RGBa(233, 241, 232, 1) 
    static let pressAndHoldGreen = UIColor(r: 233, g: 241, b: 232)
    static let greyText = UIColor(red: 0.235, green: 0.235, blue: 0.263, alpha: 0.6)
    static let lightGrey = UIColor(red: 245/255, green: 245/255, blue: 245/255, alpha: 1.0)
    static let darkGrey = UIColor(red: 51/255, green: 51/255, blue: 51/255, alpha: 1.0)
    static let disabledGrey = UIColor(red: 0.235, green: 0.235, blue: 0.263, alpha: 0.4)
    // rgba(142, 142, 147, 1)
    static let graysGray = UIColor(r: 142, g: 142, b: 147, a: 1)    
    static let redText = UIColor(red: 0.918, green: 0, blue: 0.161, alpha: 1)
    static let toastBackground = UIColor(red: 65/255, green: 65/255, blue: 65/255, alpha: 1/0)
    static let badgeRed = UIColor(red: 255/255, green: 59/255, blue: 48/255, alpha: 1/0)
}

extension Color {
    static let dimmedWhite = Color(UIColor(red: 1, green: 1, blue: 1, alpha: 0.75))
    //HopSpin Green - Light = RGBa(144, 191, 136, 1)
    static let hopSpinLightGreen = Color(UIColor(r: 144, g: 191, b: 136))
    //HopSpin Green = RGBa(34, 127, 18, 1)
    static let hopspinGreen = Color(UIColor(r: 34, g: 127, b: 18))
    static let greyText = Color(UIColor(red: 0.235, green: 0.235, blue: 0.263, alpha: 0.6))
    static let lightGrey = Color(UIColor(red: 245/255, green: 245/255, blue: 245/255, alpha: 1.0))
    static let redText = Color(UIColor(red: 0.918, green: 0, blue: 0.161, alpha: 1))
    static let toastBackground = Color(UIColor(red: 65/255, green: 65/255, blue: 65/255, alpha: 1/0))
}

extension UIColor {
    convenience init(r: CGFloat, g: CGFloat, b: CGFloat, a: CGFloat = 1.0) {
        self.init(red: r/255, green: g/255, blue: b/255, alpha: a)
    }
}
