//
//  BreweryHostingControler.swift
//  HopSpin
//
//  Created by Antonio Carella on 11/24/23.
//

import UIKit
import SwiftUI

class BreweryHostingControler: UIHostingController<BreweryDetailView> {
    
    private let navBarAppearance: NavigationBarAppearance
    
    init(
        rootView: BreweryDetailView,
        navBarAppearance: NavigationBarAppearance
    ) {
        self.navBarAppearance = navBarAppearance
        super.init(rootView: rootView)
    }
    
    @MainActor required dynamic init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        adjustSafeAreasForMaxScreens()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        updateNavigationControllerAppearance(navBarAppearance)
    }
}

enum StatusBarColor: String, Decodable {
    case lightContent, darkContent
    
    var statusBarStyle: UIStatusBarStyle {
        switch self {
        case .darkContent: return .darkContent
        case .lightContent: return .lightContent
        }
    }
}
