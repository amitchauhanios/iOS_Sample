//
//  LoadingView.swift
//  BlockDirectory
//
//  Created by Antonio Carella on 8/7/23.
//

import UIKit

/// Loading view with LoadingAnimationView and UILabel
class LoadingView: UIView {
    
    private let animationView = LoadingAnimationView()
    
    var animationStrokeColor: UIColor = Colors.hopspinGreen {
        didSet {
            animationView.strokeColor = animationStrokeColor
        }
    }
    
    private lazy var label: UILabel = {
        let label = UILabel()
        label.font = UIFont.preferredFont(forTextStyle: .body)
        label.textAlignment = .center
        label.setContentCompressionResistancePriority(.required, for: .horizontal)
        return label
    }()
    
    private lazy var stackView: UIStackView = {
        let stack = UIStackView(arrangedSubviews: [animationView, label])
        stack.axis = .vertical
        stack.spacing = UIStackView.spacingUseDefault
        return stack
    }()
    
    init(loadingText: String? = nil) {
        super.init(frame: .zero)
        
        if let text = loadingText {
            label.text = text
        } else {
            label.isHidden = true
        }
        constrainViews()
    }
    
    func startAnimating() {
        animationView.play()
    }
    
    func stopAnimating() {
        animationView.stop()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func constrainViews() {
        addSubview(stackView)
        stackView.translatesAutoresizingMaskIntoConstraints = false
        stackView.setContentCompressionResistancePriority(.required, for: .horizontal)
        animationView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            animationView.heightAnchor.constraint(equalToConstant: 120),
            animationView.widthAnchor.constraint(equalToConstant: 120),
            stackView.leadingAnchor.constraint(equalTo: leadingAnchor),
            stackView.topAnchor.constraint(equalTo: topAnchor),
            stackView.bottomAnchor.constraint(equalTo: bottomAnchor),
            stackView.trailingAnchor.constraint(equalTo: trailingAnchor)
        ])
    }
}
