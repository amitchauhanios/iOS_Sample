//
//  LoadingAnimationView.swift
//  HopSpin
//
//  Created by Antonio Carella on 4/5/24.
//

import Lottie
import UIKit

class LoadingAnimationView: LottieAnimationView {
    private let hopSpinAnimation = LottieAnimation.named("hopspin-spinner")
    
    var strokeColor: UIColor = Colors.hopspinGreen {
        didSet {
            updateStrokeColor(color: strokeColor)
        }
    }
    
    override init(
        configuration: LottieConfiguration = .shared,
        logger: LottieLogger = .shared
    ) {
        super.init(configuration: configuration, logger: logger)
        setup()
    }
    
    @MainActor required dynamic init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setup() {
        animation = hopSpinAnimation
        loopMode = .loop
        animationSpeed = 1.25
        contentMode = .scaleAspectFit
    }
    
    private func updateStrokeColor(color: UIColor) {
        let fillKeypath = AnimationKeypath(keypath: "**.Stroke *.Color")
        let colorValueProvider = ColorValueProvider(color.lottieColorValue)
        setValueProvider(colorValueProvider, keypath: fillKeypath)
    }
}
