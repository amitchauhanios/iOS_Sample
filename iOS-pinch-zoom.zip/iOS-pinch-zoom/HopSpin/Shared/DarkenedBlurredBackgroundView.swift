//
//  DarkenedBlurredBackgroundView.swift
//  HopSpin
//
//  Created by Antonio Carella on 12/17/23.
//

import UIKit

class DarkenedBackgroundView: UIView {
    
    private let dimmingAlpha: CGFloat = 0.725 // Adjust the alpha for more darkness if needed
    
    init() {
        super.init(frame: .zero)
        setupView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setupView()
    }
    
    private func setupView() {
        
        // Apply a semi-transparent black view to increase the darkening effect
        let dimmingView = UIView(frame: self.bounds)
        dimmingView.backgroundColor = UIColor(white: 0.0, alpha: dimmingAlpha)
        dimmingView.autoresizingMask = [.flexibleWidth, .flexibleHeight]

        // Add the dimming view on top of the blur effect view
        addSubview(dimmingView)
        
        // Allow interaction with views underneath
        isUserInteractionEnabled = true
    }
}
