//
//  LoadingViewSUI.swift
//  HopSpin
//
//  Created by Antonio Carella on 4/7/24.
//

import SwiftUI

struct LoadingViewSUI: UIViewRepresentable {
    let shouldAnimate: Bool
    let strokeColor: UIColor
    
    func makeUIView(context: Context) -> LoadingView {
        return LoadingView()
    }
    
    func updateUIView(_ uiView: LoadingView, context: Context) {
        uiView.animationStrokeColor = strokeColor
        if self.shouldAnimate {
            uiView.startAnimating()
        } else {
            uiView.stopAnimating()
        }
    }
}

#Preview {
    LoadingViewSUI(shouldAnimate: true, strokeColor: .blue)
}
