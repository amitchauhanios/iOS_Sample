//
//  RadioButtonLabelView.swift
//  HopSpin
//
//  Created by Antonio Carella on 12/30/23.
//

import UIKit

class RadioButtonLabelView: UIView {
    
    private let gestureRecognizer = UITapGestureRecognizer()
    private let imageView = UIImageView()
    let label = UILabel()
            
    private lazy var stack: UIStackView = {
        let stack = UIStackView(arrangedSubviews: [imageView, label])
        stack.alignment = .center
        stack.spacing = 8.0
        return stack
    }()
    
    var onTap: (() -> Void)?
    
    var isSelected: Bool = false {
        didSet {
            imageView.image = Self.image(selected: isSelected, tintColor: tintColor)
        }
    }
    
    init() {
        super.init(frame: .zero)
        setup()
        layout()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setup() {
        label.font = UIFont.systemFont(ofSize: 17.0, weight: .semibold)
        
        gestureRecognizer.addTarget(self, action: #selector(tapped))
        addGestureRecognizer(gestureRecognizer)
    }
    
    private func layout() {
        addSubview(stack)
        stack.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate {
            imageView.heightAnchor.constraint(equalToConstant: 22)
            imageView.widthAnchor.constraint(equalToConstant: 26)
            
            stack.topAnchor.constraint(equalTo: topAnchor, constant: 11)
            stack.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -11)
            stack.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 16)
            stack.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -16)
        }
    }
    
    @objc private func tapped() {
        onTap?()
    }
    
    private static func image(selected: Bool, tintColor: UIColor) -> UIImage {
        let symbolConfig = UIImage.SymbolConfiguration(pointSize: 17, weight: .regular, scale: .large)
        let imageName = selected ? "circle.inset.filled" : "circle"
        
        return UIImage(
            systemName: imageName,
            withConfiguration: symbolConfig)!
            .withTintColor(
                tintColor,
                renderingMode: .alwaysOriginal
            )
    }
    
}


