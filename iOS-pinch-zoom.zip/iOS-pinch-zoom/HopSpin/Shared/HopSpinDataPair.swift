//
//  HopSpinDataPair.swift
//  HopSpin
//
//  Created by Antonio Carella on 8/26/23.
//

import SwiftUI

class HopSpinDataPairViewModel: ObservableObject {
    @Published var title: String
    @Published var value: String
    
    init(title: String, value: String) {
        self.title = title
        self.value = value
    }
    
    var isEmpty: Bool {
        return title.isEmpty && value.isEmpty
    }
}

extension HopSpinDataPairViewModel {
    static let empty: HopSpinDataPairViewModel = .init(title: "", value: "")
}

extension HopSpinDataPairViewModel {
    static let mockFounder: HopSpinDataPairViewModel = .init(title: "Founder", value: "Josh Deth")
    
    static let mockBrewing: HopSpinDataPairViewModel = .init(title: "Brewing", value: "David Blackford\nJim Cibek\nJosh Deth\nMatty Kemp")
}

extension HopSpinDataPairViewModel: Hashable {
    static func == (lhs: HopSpinDataPairViewModel, rhs: HopSpinDataPairViewModel) -> Bool {
        lhs.title == rhs.title
    }
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(self.title)
    }
}

struct HopSpinDataPair: View {
    @ObservedObject var viewModel: HopSpinDataPairViewModel
    
    var body: some View {
        VStack(alignment: .leading) {
            Text(verbatim: viewModel.title)
                .font(Font.system(size: 17.0, weight: .semibold))
            Text(verbatim: viewModel.value)
                    .font(Font.system(size: 17.0))
        }
    }
}

struct HopSpinDataPair_Previews: PreviewProvider {
    static var previews: some View {
        HopSpinDataPair(viewModel: .mockBrewing)
    }
}
