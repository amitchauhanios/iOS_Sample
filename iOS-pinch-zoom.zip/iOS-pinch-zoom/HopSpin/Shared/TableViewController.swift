//
//  TableViewController.swift
//  HopSpin
//
//  Created by Antonio Carella on 11/14/23.
//

import UIKit

enum UserScrollDirection {
    case up, down
}

class TableViewController: UIViewController {
    
    //MARK: DiffableDataSource
    struct Section: Hashable {
        let id: UUID
        let title: String
    }
    
    private let refreshControl = UIRefreshControl()
    private let animationView = LoadingAnimationView()
    
    let tableView = UITableView()
    
    private let countToast = CountToast()
    let galleryOrListButton = GalleryOrListButton()
    
    lazy var bottomToast: UIStackView = {
        let stack = UIStackView(arrangedSubviews: [countToast, galleryOrListButton])
        stack.spacing = 16
        return stack
    }()
    
    private(set) var bottomToastBottomConstaintConstant: CGFloat = 16.0
    
    let loadingView = LoadingView()
    
    private(set) lazy var loadingViewBackground: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = .white
        return view
    }()
    
    init(hidesGallerOrListButton: Bool = true) {        
        galleryOrListButton.isHidden = hidesGallerOrListButton
        super.init(nibName: nil, bundle: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        constrainViews()
        constrainTableView()
        constrainLoadingViewBackground()
        constrainLoadingView()
        constrainBottomStack()
        
        refreshControl.tintColor = .clear
        tableView.panGestureRecognizer.addTarget(self, action: #selector(gestureRecognizerUpdate))
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        tableView.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: 40, right: 0)
    }
    
    override func viewSafeAreaInsetsDidChange() {
        super.viewSafeAreaInsetsDidChange()
        if shouldAdjustSafeAreasForMaxScreens() {
            tableView.scrollIndicatorInsets = makeMaxScreenAdditionalSafeAreaInsetsInverted()
        }
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func constrainViews() {
        tableView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(tableView)
        
        bottomToast.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(bottomToast)
        
        loadingViewBackground.addSubview(loadingView)
        loadingView.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(loadingViewBackground)
        loadingViewBackground.translatesAutoresizingMaskIntoConstraints = false
        
        refreshControl.addSubview(animationView)
        animationView.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            animationView.centerXAnchor.constraint(equalTo: refreshControl.centerXAnchor),
            animationView.centerYAnchor.constraint(equalTo: refreshControl.centerYAnchor),
            animationView.heightAnchor.constraint(equalToConstant: 120),
            animationView.widthAnchor.constraint(equalToConstant: 120)
        ])
    }
    
    // Subclasses may override
    func constrainTableView() {
        NSLayoutConstraint.activate([
            tableView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor),
            tableView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
    }
    
    // Subclasses may override
    func constrainLoadingViewBackground() {
        NSLayoutConstraint.activate([
            loadingViewBackground.leadingAnchor.constraint(equalTo: tableView.leadingAnchor),
            loadingViewBackground.topAnchor.constraint(equalTo: tableView.topAnchor),
            loadingViewBackground.trailingAnchor.constraint(equalTo: tableView.trailingAnchor),
            loadingViewBackground.bottomAnchor.constraint(equalTo: tableView.bottomAnchor)
        ])
    }
    
    func constrainLoadingView() {
        NSLayoutConstraint.activate([
            loadingView.centerXAnchor.constraint(equalTo: loadingViewBackground.centerXAnchor),
            loadingView.centerYAnchor.constraint(equalTo: loadingViewBackground.centerYAnchor),
            loadingView.widthAnchor.constraint(greaterThanOrEqualToConstant: 50.0),
            loadingView.heightAnchor.constraint(greaterThanOrEqualToConstant: 50.0),
                        
            animationView.centerXAnchor.constraint(equalTo: refreshControl.centerXAnchor),
            animationView.centerYAnchor.constraint(equalTo: refreshControl.centerYAnchor),
            animationView.heightAnchor.constraint(equalToConstant: 120),
            animationView.widthAnchor.constraint(equalToConstant: 120)
        ])
    }
    
    func constrainBottomStack() {        
        NSLayoutConstraint.activate([
            bottomToast.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            bottomToast.bottomAnchor.constraint(
                equalTo: view.safeAreaLayoutGuide.bottomAnchor,
                constant: -bottomToastBottomConstaintConstant
            ),
            bottomToast.heightAnchor.constraint(equalToConstant: 48)
            ]
        )
    }
    
    @objc private func gestureRecognizerUpdate() {
        let userIsScrollingDown = tableView.panGestureRecognizer.translation(in: tableView).y < 0
        userScrolled(direction: userIsScrollingDown ? .down : .up)
    }
    
    func userScrolled(direction: UserScrollDirection) {
        // for subclasses to override
    }
    
    func showToast(presentation: ToastPresentation) {
        switch presentation {
        case .display(let count):
            countToast.label.text = "\(count)"
            view.bringSubviewToFront(bottomToast)
            bottomToast.isHidden = false
        case .animateUp(let count):
            countToast.label.text = "\(count)"
            animateBottomToast(visible: true)
        case .animateDown:
            animateBottomToast(visible: false)
        case .dismiss:
            dismissToast()
        }
        
    }
    
    func dismissToast() {
        bottomToast.isHidden = true
    }
    
    func showLoadingView(show: Bool) {
        loadingView.isHidden = !show
        loadingViewBackground.isHidden = !show
        
        if show {
            view.bringSubviewToFront(loadingViewBackground)
            loadingView.startAnimating()
        } else {
            loadingView.stopAnimating()
            view.sendSubviewToBack(loadingViewBackground)
        }
    }
    
    /// Call to add a UIRefreshControl to the tableView
    func addRefreshControl(color: UIColor) {
        animationView.strokeColor = color
        tableView.refreshControl = refreshControl
        refreshControl.addTarget(self, action: #selector(refresh), for: .valueChanged)
    }
    
    @objc private func refresh() {
        animationView.isHidden = false
        animationView.play()
        refreshTriggered()
    }
    
    @objc func refreshTriggered() {
        assertionFailure("Should override!")
    }
    
    /// Override to control showing behavior for refresh control
    func showRefreshControl() {
        refreshControl.beginRefreshing()
    }
    
    /// Override to control hiding behavior for refresh control
    func hideRefreshControl() {
        animationView.isHidden = true
        animationView.stop()
        refreshControl.endRefreshing()
    }
    
    func animateBottomToast(visible: Bool, duration: TimeInterval = StyleKit.animationDuration) {
        if visible == bottomToastIsVisible() { return }
        let offsetY = visible ? -bottomToastVOffset : bottomToastVOffset
        
        UIViewPropertyAnimator(duration: duration, curve: .linear) { [weak self] in
            guard let self else { return }
            self.bottomToast.frame = CGRect(
                x: self.bottomToast.frame.minX,
                y: self.tableView.frame.height + offsetY,
                width: self.bottomToast.frame.width,
                height: self.bottomToast.frame.height
            )
            
            self.view.setNeedsDisplay()
            self.view.layoutIfNeeded()
        }
        .startAnimation()
    }
    
    func bottomToastIsVisible() -> Bool {
        return bottomToast.frame.origin.y < view.bounds.height
    }
    
    var bottomToastVOffset: CGFloat {
        bottomToast.frame.size.height + view.safeAreaInsets.bottom + bottomToastBottomConstaintConstant
    }
    
}
