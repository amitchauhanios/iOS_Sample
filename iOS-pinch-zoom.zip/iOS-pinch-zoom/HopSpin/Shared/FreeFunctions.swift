//
//  FreeFunctions.swift
//  HopSpin
//
//  Created by Antonio Carella on 1/28/24.
//

import Foundation
import UIKit

func zipThree<T, U, V>(_ array1: [T], _ array2: [U], _ array3: [V]) -> [(T, U, V)] {
    let minCount = min(array1.count, array2.count, array3.count)
    var result: [(T, U, V)] = []
    
    for i in 0..<minCount {
        let element1 = array1[i]
        let element2 = array2[i]
        let element3 = array3[i]
        result.append((element1, element2, element3))
    }
    
    return result
}

func shouldAdjustSafeAreasForMaxScreens() -> Bool {
    UIScreen.main.bounds.width >= 414
}
