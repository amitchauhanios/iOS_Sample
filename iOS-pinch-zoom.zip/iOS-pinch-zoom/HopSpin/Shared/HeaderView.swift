//
//  HeaderView.swift
//  HopSpin
//
//  Created by Antonio Carella on 8/21/23.
//

import UIKit

class HeaderView: UIView {
    
    private var topStackConstraint: NSLayoutConstraint!
    
    var stackTopConstant = 1.0 {
        didSet {
            topStackConstraint.constant = stackTopConstant
            setNeedsLayout()
            layoutIfNeeded()
        }
    }
    
    private let backgroundImageView = UIImageView(image: .init(named: "navigation-header-background"))
    
    private lazy var backButton: UIButton = {
        let button = UIButton()
        button.setImage(.init(named: "back-chevron"), for: .normal)
        button.tintColor = .white
        let action = UIAction { [weak self] _ in
            self?.backButtonHandler?()
        }
        button.addAction(action, for: .touchUpInside)
        return button
    }()
    
    private lazy var logoImageView: UIImageView = {
        let logo = UIImage(named: "logo")
        let imageView = UIImageView(image: logo)
        imageView.contentMode = .scaleAspectFit
        imageView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            imageView.heightAnchor.constraint(equalToConstant: 31),
            imageView.widthAnchor.constraint(equalToConstant: 103)
        ])
        return imageView
    }()
    
    private lazy var searchTermLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 17.0, weight: .semibold)
        label.textAlignment = .center
        label.textColor = .white
        label.translatesAutoresizingMaskIntoConstraints = false
        label.setContentHuggingPriority(.required, for: .vertical)
        return label
    }()
    
    private lazy var searchTermView: UIView = {
        let view = UIView()
        view.backgroundColor = .black
        view.clipsToBounds = true
        view.addSubview(searchTermLabel)
        
        NSLayoutConstraint.activate([
            searchTermLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            searchTermLabel.topAnchor.constraint(equalTo: view.topAnchor),
            searchTermLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            searchTermLabel.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -3)
        ])
                
        view.layer.maskedCorners = [
            CACornerMask.layerMaxXMaxYCorner,
            CACornerMask.layerMaxXMinYCorner,
            CACornerMask.layerMinXMaxYCorner,
            CACornerMask.layerMinXMinYCorner
        ]
        
        return view
    }()
    
    private lazy var vStack: UIStackView = {
        let stack = UIStackView(arrangedSubviews: [
            logoImageView, searchTermView
        ])
        
        stack.axis = .vertical
        stack.spacing = UIStackView.spacingUseSystem
        return stack
    }()
    
    private var backButtonHandler: (() -> Void)?
    
    init(
        searchTerm: String,
        backButtonHandler: (() -> Void)?
    ) {
        self.backButtonHandler = backButtonHandler
        super.init(frame: .zero)
        searchTermLabel.text = searchTerm
        layout()
        setNeedsLayout()
        layoutIfNeeded()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func layout() {
        addSubview(backgroundImageView)
        backgroundImageView.translatesAutoresizingMaskIntoConstraints = false
        
        addSubview(vStack)
        vStack.translatesAutoresizingMaskIntoConstraints = false
        
        addSubview(backButton)
        backButton.translatesAutoresizingMaskIntoConstraints = false
        
        let height = heightAnchor.constraint(equalToConstant: 133.0)
        height.priority = .defaultHigh
        
        topStackConstraint = vStack.topAnchor.constraint(equalTo: safeAreaLayoutGuide.topAnchor, constant: stackTopConstant)
        
        NSLayoutConstraint.activate([
            height,
            
            backgroundImageView.leadingAnchor.constraint(equalTo: leadingAnchor),
            backgroundImageView.topAnchor.constraint(equalTo: topAnchor),
            backgroundImageView.trailingAnchor.constraint(equalTo: trailingAnchor),
            backgroundImageView.bottomAnchor.constraint(equalTo: bottomAnchor),
            topStackConstraint,
            
            vStack.bottomAnchor.constraint(greaterThanOrEqualTo: layoutMarginsGuide.bottomAnchor),
            vStack.centerXAnchor.constraint(equalTo: centerXAnchor),
            
            backButton.centerYAnchor.constraint(equalTo: logoImageView.centerYAnchor),
            backButton.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 0.0),
            backButton.widthAnchor.constraint(equalToConstant: 44),
            backButton.heightAnchor.constraint(equalToConstant: 44)
        ])
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        searchTermView.layer.cornerRadius = searchTermView.bounds.height / 2
    }
    
}
