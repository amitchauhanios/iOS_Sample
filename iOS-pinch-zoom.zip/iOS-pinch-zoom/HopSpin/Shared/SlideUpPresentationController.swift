//
//  SlideUpPresentationController.swift
//  HopSpin
//
//  Created by Antonio Carella on 12/23/23.
//

import UIKit

class SlideUpPresentationController: UIPresentationController {
    private var dimmingView: UIView!
    
    var topOffset: CGFloat = 100
    
    override init(presentedViewController: UIViewController, presenting presentingViewController: UIViewController?) {
        super.init(presentedViewController: presentedViewController, presenting: presentingViewController)        
        setupDimmingView()
    }
    
    private func setupDimmingView() {
        dimmingView = UIView()
        dimmingView.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        dimmingView.alpha = 0.0
    }
    
    override var frameOfPresentedViewInContainerView: CGRect {
        guard let containerView = containerView else { return .zero }
        var frame: CGRect = containerView.bounds
        frame.origin.y += topOffset // Space from the top
        frame.size.height -= topOffset
        return frame
    }
    
    override func presentationTransitionWillBegin() {
        guard let containerView = containerView, let dimmingView = dimmingView else { return }
        
        containerView.addSubview(dimmingView)
        dimmingView.frame = containerView.bounds
        
        presentedViewController.view.frame = frameOfPresentedViewInContainerView
        presentedViewController.view.layer.cornerRadius = 20
        presentedViewController.view.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner] // Round top corners
        presentedViewController.view.clipsToBounds = true
        
        containerView.addSubview(presentedViewController.view)
        presentedViewController.view.frame = frameOfPresentedViewInContainerView
        presentedViewController.view.frame.origin.y = containerView.bounds.height
        
        let transitionCoordinator = presentingViewController.transitionCoordinator
        transitionCoordinator?.animate(alongsideTransition: { _ in
            self.dimmingView.alpha = 1.0
            self.presentedViewController.view.frame = self.frameOfPresentedViewInContainerView
        })
    }
    
    override func dismissalTransitionWillBegin() {
        let transitionCoordinator = presentingViewController.transitionCoordinator
        transitionCoordinator?.animate(alongsideTransition: { _ in
            self.dimmingView.alpha = 0.0
            self.presentedViewController.view.frame.origin.y = self.containerView!.frame.height
        })
    }
    
    override func containerViewWillLayoutSubviews() {
        super.containerViewWillLayoutSubviews()
        dimmingView.frame = containerView!.bounds
    }
}


class SlideUpTransitionDelegate: NSObject, UIViewControllerTransitioningDelegate {
    
    var topOffset: CGFloat = 100.0
    
    func presentationController(forPresented presented: UIViewController, presenting: UIViewController?, source: UIViewController) -> UIPresentationController? {
        let controller = SlideUpPresentationController(presentedViewController: presented, presenting: presenting)
        controller.topOffset = topOffset
        return controller
    }
}

