//
//  PlaceholderViewController.swift
//  HopSpin
//
//  Created by Antonio Carella on 12/17/23.
//

import UIKit

class PlaceholderViewController: UIViewController {
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    init() {
        super.init(nibName: nil, bundle: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        placeLogoInNavBar()
    }
}
