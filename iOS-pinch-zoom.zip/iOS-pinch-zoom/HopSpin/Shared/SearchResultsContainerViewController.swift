//
//  SearchResultsContainerViewController.swift
//  HopSpin
//
//  Created by Antonio Carella on 11/5/23.
//

import UIKit

/// Contains a search results view controller, and provides a header view with the search result displayed in it
class SearchResultsContainerViewController: UIViewController {
    
    private var headerView: HeaderView!
    private let child: UIViewController
    
    init(
        searchTerm: String,
        childViewController: UIViewController
    ) {
        self.child = childViewController
        super.init(nibName: nil, bundle: nil)
        self.headerView = HeaderView(
            searchTerm: searchTerm,
            backButtonHandler: { [weak self] in
                self?.navigationController?.popViewController(animated: true)
            }
        )
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        add(childViewController: child)
        layout()
    }
    
    override func viewIsAppearing(_ animated: Bool) {
        super.viewIsAppearing(animated)
        navigationController?.setNavigationBarHidden(true, animated: false)
        
        // So that the header view's logo Y value can match that of when it's in a
        // NavigationItem's titleView, we need to adjust it's constraint's contant
        // on a per device basis. Below is the logic to do so.
        let topSafeAreaInset = view.safeAreaInsets.top
        
        // For devices with a nook, instead of a dynamic island
        if topSafeAreaInset == 47.0 {
            headerView.stackTopConstant = 6.6666666666667
        // This is for the iPhone SE, which has neither nook, nor dynamic island
        } else if topSafeAreaInset == 20.0 {
            headerView.stackTopConstant = 4
        // For phones with Dynamic islands
        } else {
            headerView.stackTopConstant = 1.0
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(false, animated: false)
    }
    
    private func layout() {
        view.addSubview(headerView)
        headerView.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            headerView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            headerView.topAnchor.constraint(equalTo: view.topAnchor),
            headerView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            
            child.view.topAnchor.constraint(equalTo: headerView.bottomAnchor),
            child.view.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            child.view.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            child.view.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
    }
    
    func add(childViewController: UIViewController) {
        addChild(childViewController)
        view.addSubview(childViewController.view)
        childViewController.view.translatesAutoresizingMaskIntoConstraints = false
        childViewController.didMove(toParent: self)
    }
    
    func handleBackButtonTap() {
        self.dismiss(animated: true)
    }
}
