//
//  ListDataProcessorProtocol.swift
//  HopSpin
//
//  Created by Antonio Carella on 4/26/24.
//

import OrderedCollections

protocol ListDataProcessorProtocol {
    associatedtype ItemType: Listable
    associatedtype SortingOption: Sortable
    static func process(
        items: [ItemType],
        searchTerm: String,
        orderOption: OrderOption,
        sortingOption: SortingOption
    ) -> OrderedDictionary<String, [SearchListItem]>
}
