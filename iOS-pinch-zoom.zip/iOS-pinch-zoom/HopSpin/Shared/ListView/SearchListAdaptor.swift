//
//  SearchListAdaptor.swift
//  HopSpin
//
//  Created by Antonio Carella on 11/19/23.
//

import OrderedCollections

struct SearchListAdaptor {
    
    static func format(searchListItems: [SearchListItem]) -> OrderedDictionary<String, [SearchListItem]> {
        let groupedItems = Dictionary(grouping: searchListItems) { item -> String in
            let initial = item.titleText.uppercased().first ?? "#"
            return initial.isNumber ? "#" : String(initial)
        }

        let sortedKeys = groupedItems.keys.sorted {
            String($0).localizedStandardCompare(String($1)) == .orderedAscending
        }

        return OrderedDictionary(uniqueKeysWithValues: sortedKeys.map { key in (key, groupedItems[key]!) })
    }
}
