//
//  GenericListViewModel.swift
//  HopSpin
//
//  Created by Antonio Carella on 11/19/23.
//

import Combine
import OrderedCollections
import UIKit

protocol Listable {}

struct ItemsPayload {
    let orderedDict: OrderedDictionary<String, [SearchListItem]>
    let sort: (any Sortable)?
}

extension ItemsPayload {
    static let empty: ItemsPayload = .init(orderedDict: [:], sort: nil)
    
    var totalCount: Int {
        let values = orderedDict.values.flatMap { $0 }
            .map(\.id)
            .map(UUIDHandler.deciper)
        return Set<String>(values).count
    }
}

protocol ListItemsViewModel {
    var listItems: AnyPublisher<ItemsPayload, Never> { get }
    var showLoadingViewSubject: PassthroughSubject<Bool, Never> { get }
    var showRefreshSubject: PassthroughSubject<Bool, Never> { get }
    var errorMessageSubject: PassthroughSubject<ErrorMessage?, Never> { get }
    var showCountSubject: PassthroughSubject<ToastPresentation, Never> { get }
    var tableViewShouldScrollToTop: PassthroughSubject<Void, Never> { get }
    var tintColor: UIColor { get }
    var activityIndicatorColor: UIColor { get }
    
    func itemSelected(at indexPath: IndexPath)
    func userScrolled(direction: UserScrollDirection)
}

class GenericListViewModel<
        ItemType: Listable & FilteringParamsProtocol,
        Processor: ListDataProcessorProtocol,
        Fetcher: DataFetcherProtocol,
        SortingOption
    >: ListItemsViewModel where
        Processor.ItemType == ItemType,
        Processor.SortingOption == SortingOption,
        Fetcher.ItemType == ItemType,
        Fetcher.SortingOption == SortingOption 
{
    
    // State
    @Published var items: [ItemType] = []
    let itemsSubject = CurrentValueSubject<ItemsPayload, Never>(.empty)
    var listItems: AnyPublisher<ItemsPayload, Never> {
        itemsSubject.eraseToAnyPublisher()
    }
    let tintColor: UIColor
    let cellSelectionColor: UIColor
    let activityIndicatorColor: UIColor
    
    // The "snapshot" of initial filter values. This snapshot should be taken just once,
    // at the first fetch of items.
    // We'll use these as the superset of filtering options that the user can choose from while filtering.
    var filteringParamsSnapshot = CurrentValueSubject<[FilterParam], Never>([])

    // Combine
    let showLoadingViewSubject = PassthroughSubject<Bool, Never>()
    let showRefreshSubject = PassthroughSubject<Bool, Never>()
    let errorMessageSubject = PassthroughSubject<ErrorMessage?, Never>()
    let tableViewShouldScrollToTop = PassthroughSubject<Void, Never>()
    let showCountSubject = PassthroughSubject<ToastPresentation, Never>()
    private var cancellables = Set<AnyCancellable>()

    // Dependencies
    let dataFetcher: Fetcher
    private let searchTerm: CurrentValueSubject<String, Never>
    private let filters: CurrentValueSubject<FiltersAndOperator, Never>
    let sorting: CurrentValueSubject<(OrderOption, SortingOption), Never>
    weak var delegate: SearchResultSelectedHandler?

    init(
        dataFetcher: Fetcher,
        searchTerm: CurrentValueSubject<String, Never>,
        filters: CurrentValueSubject<FiltersAndOperator, Never>,
        sorting: CurrentValueSubject<(OrderOption, SortingOption), Never>,
        tintColor: UIColor,
        cellSelectionColor: UIColor,
        activityIndicatorColor: UIColor
    ) {
        self.dataFetcher = dataFetcher
        self.searchTerm = searchTerm
        self.filters = filters
        self.sorting = sorting
        self.tintColor = tintColor
        self.cellSelectionColor = cellSelectionColor
        self.activityIndicatorColor = activityIndicatorColor
        self.bind()
    }
    
    private func bind() {
        
        showRefreshSubject
            .filter { $0 }
            .sink { [weak self] _ in
                self?.fetchResults()
            }
            .store(in: &cancellables)
        
        Publishers
            .CombineLatest(
                searchTerm,
                filters
            )
            .sink { [weak self] searchTerm, filters in
                self?.showLoadingViewSubject.send(true)
                self?.fetchResults()
            }
            .store(in: &cancellables)
        
        // whenever we filter or sort, scroll the table view to the top
        filters
            .combineLatest(sorting)
            .sink { _ in
                self.tableViewShouldScrollToTop.send(())
            }
            .store(in: &cancellables)
        
        sorting
            .dropFirst()
            .sink { [weak self] sorting in
                guard let self else { return }
                self.showLoadingViewSubject.send(true)
                self.fetchResults()
            }
            .store(in: &cancellables)           
        
        $items            
            .filter { !$0.isEmpty }
            .first()
            .map {
                $0.flatMap { $0.filteringParams }
            }
            .sink(receiveValue: { [filteringParamsSnapshot] in
                filteringParamsSnapshot.send($0)
            })
            .store(in: &cancellables)
        
        listItems
           .map { $0.totalCount }
           .sink(receiveValue: { [weak self] count in
               self?.showCountSubject.send(.display(count))
           })
           .store(in: &cancellables)
    }

    func fetchResults() {
        Task {
            do {
                
                let filteredSearchTerm = searchTerm.value.replacingQuoteWithApostrophe
                
                let fetchedItems = try await dataFetcher.fetchItems(
                    searchTerm: filteredSearchTerm,
                    filters: filters.value,
                    sorting: sorting.value
                )
                
                self.items = fetchedItems

                let formatted = process(
                    items: fetchedItems,
                    searchTerm: searchTerm.value
                )                                

                itemsSubject.send(.init(orderedDict: formatted, sort: sorting.value.1))
                showLoadingViewSubject.send(false)
                showRefreshSubject.send(false)
            } catch {
                showLoadingViewSubject.send(false)
                showRefreshSubject.send(false)
                let errorMessage = ErrorMessage(
                    title: "Error",
                    subtitle: error.localizedDescription
                )
                errorMessageSubject.send(errorMessage)
                print("Error", error)
            }
        }
    }
    
    func process(items: [ItemType], searchTerm: String) -> OrderedDictionary<String, [SearchListItem]> {
        Processor.process(items: items, searchTerm: searchTerm, orderOption: sorting.value.0, sortingOption: sorting.value.1)
    }

    func itemSelected(at indexPath: IndexPath) {
        assertionFailure("Subclasses must override")
    }
    
    func userScrolled(direction: UserScrollDirection) {
        switch direction {
        case .down:
            showCountSubject.send(.animateDown)
        default:
            let total = itemsSubject.value.totalCount
            showCountSubject.send(.animateUp(total))
        }
    }
}
