//
//  DataFetcherProtocol.swift
//  HopSpin
//
//  Created by Antonio Carella on 4/26/24.
//

import Foundation

protocol DataFetcherProtocol {
    associatedtype ItemType: Listable
    associatedtype SortingOption: Sortable
    func fetchItems(
        searchTerm: String,
        filters: FiltersAndOperator,
        sorting: (OrderOption, SortingOption)
    ) async throws -> [ItemType]
}
