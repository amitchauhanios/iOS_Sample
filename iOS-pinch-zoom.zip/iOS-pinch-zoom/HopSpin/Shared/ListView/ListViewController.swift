//
//  ListViewController.swift
//  HopSpin
//
//  Created by Antonio Carella on 11/14/23.
//

import Combine
import OrderedCollections
import UIKit

class ListViewController: TableViewController {
    
    typealias ListItemsSnapshot = NSDiffableDataSourceSnapshot<Section, SearchListItem>
    typealias ListItemsDataSource = SectionTitledDiffableDataSource<Section, SearchListItem>
    
    var listDataSource: ListItemsDataSource!
    
    static let cellId = "cellId"
    static let headerId = "headerId"
    
    // MARK: Combine
    var subscriptions = Set<AnyCancellable>()
    
    private let viewModel: ListItemsViewModel
    
    init(
        viewModel: ListItemsViewModel,
        hidesGallerOrListButton: Bool = true
    ) {
        self.viewModel = viewModel
        super.init(hidesGallerOrListButton: hidesGallerOrListButton)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupTableView()
        bindViewModel()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)        
        colorTableViewIndex()
        if let selectedIndexPath = tableView.indexPathForSelectedRow {
            tableView.deselectRow(at: selectedIndexPath, animated: true)
        }
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        showLoadingView(show: false)
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        tableView.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: 40, right: 0)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func bindViewModel() {
        viewModel
            .listItems
            .receive(on: DispatchQueue.main)
            .sink(receiveValue: updateList)
            .store(in: &subscriptions)
        
        viewModel
            .errorMessageSubject
            .receive(on: DispatchQueue.main)
            .compactMap { $0 }
            .sink { [weak self] in
                self?.present(errorMessage: $0)
            }
            .store(in: &subscriptions)
        
        viewModel
            .showCountSubject
            .receive(on: DispatchQueue.main)
            .sink(receiveValue: showToast)
            .store(in: &subscriptions)
        
        viewModel
            .showLoadingViewSubject
            .receive(on: DispatchQueue.main)
            .compactMap { $0 }
            .sink(receiveValue: showLoadingView)
            .store(in: &subscriptions)
        
        viewModel
            .tableViewShouldScrollToTop
            .receive(on: DispatchQueue.main)
            .sink { [tableView] in
                tableView.setContentOffset(.zero, animated: true)
            }
            .store(in: &subscriptions)
        
        viewModel
            .showRefreshSubject
            .receive(on: DispatchQueue.main)
            .filter { !$0 }
            .sink { [weak self] _ in
                self?.hideRefreshControl()
            }
            .store(in: &subscriptions)
    }
    
    private func setupTableView() {
        tableView.rowHeight = UITableView.automaticDimension
        tableView.register(SearchResultsTableViewCell.self, forCellReuseIdentifier: Self.cellId)
        tableView.register(SearchResultsSectionHeader.self, forHeaderFooterViewReuseIdentifier: Self.headerId)
        tableView.delegate = self
        tableView.sectionHeaderTopPadding = 0.0
        loadingView.animationStrokeColor = viewModel.activityIndicatorColor
    }
    
    var tableViewSectionIndexColor: UIColor {
        Colors.hopspinGreen
    }
    
    func colorTableViewIndex() {
        tableView.sectionIndexColor = viewModel.activityIndicatorColor
    }
    
    private func updateList(itemsPayload: ItemsPayload) {
        var snapshot = ListItemsSnapshot()
        let sections = itemsPayload.orderedDict.map { key, _ in
            Section(id: UUID(), title: "\(key)")
        }
        
        snapshot.appendSections(sections)
        
        for section in sections {
            if let cellViewModels = itemsPayload.orderedDict[section.title] {
                snapshot.appendItems(cellViewModels, toSection: section)
            }
        }
        
        listDataSource.useSectionIndex = false
        if itemsPayload.sort?.isName ?? false {
            listDataSource.useSectionIndex = true
            listDataSource.sectionTitleProvider = { tableView, identifier -> String in
                if let first = identifier.title.first {
                    return "\(first)"
                }
                
                return ""
            }
        }
        
        listDataSource.apply(snapshot, animatingDifferences: false)
        
    }
    
    override func refreshTriggered() {
        viewModel.showRefreshSubject.send(true)
    }
    
    override func userScrolled(direction: UserScrollDirection) {
        // tell view model so it can control toast display
        viewModel.userScrolled(direction: direction)
        
        guard let tabBarController = tabBarController as? MainTabBarController else {
            return
        }
        
        let tabBarVisible: Bool
        switch direction {
        case .down:
            tabBarVisible = false
        default:
            tabBarVisible = true
        }
        
        tabBarController.setTabBarVisible(visible: tabBarVisible, tableView: tableView)
        
    }
    
}

extension ListViewController: UITableViewDelegate {

    func tableView(_ tableView: UITableView, willSelectRowAt indexPath: IndexPath) -> IndexPath? {
        let cell = tableView.dequeueReusableCell(withIdentifier: Self.cellId, for: indexPath)
        let backgroundView = UIView()
        backgroundView.backgroundColor = viewModel.tintColor
        cell.selectedBackgroundView = backgroundView
        cell.contentView.backgroundColor = viewModel.tintColor
        return indexPath
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        viewModel.itemSelected(at: indexPath)
    }

    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        guard let header = tableView.dequeueReusableHeaderFooterView(withIdentifier: Self.headerId) as? SearchResultsSectionHeader else {
            assertionFailure("Failed to dequeue header view")
            return UITableViewHeaderFooterView()
        }
        
        header.label.text = listDataSource.sectionIdentifier(for: section)?.title
        
        return header
    }
    
    func tableView(_ tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int) {}
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        48.0
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        listDataSource.numberOfSections(in: tableView)
    }
}


open class SectionTitledDiffableDataSource<SectionIdentifierType, ItemIdentifierType>: UITableViewDiffableDataSource<SectionIdentifierType, ItemIdentifierType>
    where SectionIdentifierType : Hashable, ItemIdentifierType : Hashable {
    
    public typealias SectionTitleProvider = (UITableView, SectionIdentifierType) -> String?
    
    open var sectionTitleProvider: SectionTitleProvider?
    open var useSectionIndex: Bool = false
    
    open override func sectionIndexTitles(for tableView: UITableView) -> [String]? {
        guard useSectionIndex, let sectionTitleProvider = sectionTitleProvider else { return nil }
        return snapshot().sectionIdentifiers.compactMap { sectionTitleProvider(tableView, $0) }
    }
}
