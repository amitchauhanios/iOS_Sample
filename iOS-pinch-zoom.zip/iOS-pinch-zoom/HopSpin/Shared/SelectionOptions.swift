//
//  SelectionOptions.swift
//  HopSpin
//
//  Created by Antonio Carella on 24.08.2023.
//

import Foundation

struct SelectionOptions<T: Hashable> {

    var values: [T]
    var selectedValues: [T]
    var multipleSelection: Bool

    init(_ values: [T], selected: [T] = [], multiple: Bool = false) {
        self.values = values
        self.selectedValues = selected
        self.multipleSelection = multiple
    }

    mutating func toggle(_ value: T) {
        guard multipleSelection else {
            selectedValues = [value]
            return
        }
        if selectedValues.contains(value) {
            selectedValues = selectedValues.filter { $0 != value }
        }
        else {
            selectedValues.append(value)
        }
    }
    
    mutating func update(_ values: [T]) {
        selectedValues = values
    }
}

/// The following allows items to be used across different shard key-spaces, by combining a shard's hash values with the item's hash.
///
/// EXAMPLE: For sectioned UICollectionViews, simply use a section identifier as the sharding key to allow items to show up in multiple sections-
struct ShardedItem<Key, Item> : Hashable
    where Key: Hashable, Item: Hashable
{
    let shard: Key
    let item: Item
}
