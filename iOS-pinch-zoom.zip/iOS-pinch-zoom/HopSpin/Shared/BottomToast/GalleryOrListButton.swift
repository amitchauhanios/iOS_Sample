//
//  GalleryOrListButton.swift
//  HopSpin
//
//  Created by Antonio Carella on 4/29/24.
//

import Combine
import UIKit

class GalleryOrListButton: UIView {
    
    private lazy var galleryTapGestureRecognizer: UITapGestureRecognizer = {
        UITapGestureRecognizer(target: self, action: #selector(galleryTapped))
    }()
    
    private lazy var listTapGestureRecognizer: UITapGestureRecognizer = {
        UITapGestureRecognizer(target: self, action: #selector(listTapped))
    }()
    
    private lazy var galleryLabel: UILabel = {
        let label = UILabel()
        label.text = "3D"
        label.font = UIFont.systemFont(ofSize: 10.0, weight: .medium)
        label.textAlignment = .center
        label.textColor = .white
        label.setContentHuggingPriority(.required, for: .vertical)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private lazy var galleryImageView: UIImageView = {
        UIImageView(image: Image.create(image: .galleryEnabled))
    }()
    
    private lazy var gallery: UIView = {
        
        let parent = UIView()
        parent.translatesAutoresizingMaskIntoConstraints = false
        galleryLabel.translatesAutoresizingMaskIntoConstraints = false
        parent.addSubview(galleryLabel)
        galleryImageView.translatesAutoresizingMaskIntoConstraints = false
        parent.addSubview(galleryImageView)
        
        NSLayoutConstraint.activate([
            galleryImageView.widthAnchor.constraint(equalToConstant: 14),
            galleryImageView.topAnchor.constraint(equalTo: parent.topAnchor),
            galleryImageView.centerXAnchor.constraint(equalTo: parent.centerXAnchor),
            galleryLabel.topAnchor.constraint(equalTo: galleryImageView.bottomAnchor, constant: 4),
            galleryLabel.centerXAnchor.constraint(equalTo: parent.centerXAnchor),
            galleryLabel.bottomAnchor.constraint(equalTo: parent.bottomAnchor),
            parent.widthAnchor.constraint(equalToConstant: 27.0)
        ])
        
        parent.addGestureRecognizer(galleryTapGestureRecognizer)
        
        return parent
    }()
    
    private lazy var listLabel: UILabel = {
        let label = UILabel()
        label.text = "List"
        label.font = UIFont.systemFont(ofSize: 10.0, weight: .medium)
        label.textAlignment = .center
        label.textColor = Colors.graysGray
        label.setContentHuggingPriority(.required, for: .vertical)
        return label
    }()
    
    private lazy var listImageView: UIImageView = {
        UIImageView(image: Image.create(image: .listDisabled))
    }()
    
    private lazy var list: UIView = {
        
        let parent = UIView()
        parent.translatesAutoresizingMaskIntoConstraints = false
        listLabel.translatesAutoresizingMaskIntoConstraints = false
        parent.addSubview(listLabel)
        listImageView.translatesAutoresizingMaskIntoConstraints = false
        parent.addSubview(listImageView)
        
        NSLayoutConstraint.activate([
            listImageView.heightAnchor.constraint(equalToConstant: 18),
            listImageView.widthAnchor.constraint(equalToConstant: 20),
            listImageView.topAnchor.constraint(equalTo: parent.topAnchor),
            listImageView.centerXAnchor.constraint(equalTo: parent.centerXAnchor),
            listLabel.topAnchor.constraint(equalTo: listImageView.bottomAnchor, constant: 3),
            listLabel.centerXAnchor.constraint(equalTo: parent.centerXAnchor),
            listLabel.bottomAnchor.constraint(equalTo: parent.bottomAnchor),
            parent.widthAnchor.constraint(equalToConstant: 33.0)
        ])
        
        parent.addGestureRecognizer(listTapGestureRecognizer)
        
        return parent
    }()
    
    let valueChanged = PassthroughSubject<BeerViewSegmentState, Never>()    
    
    private lazy var hStack: UIStackView = {
        let stack = UIStackView(arrangedSubviews: [gallery, list])
        stack.spacing = 6.0
        stack.alignment = .bottom
        return stack
    }()
    
    override init(frame: CGRect) {
        super.init(frame: .zero)
        backgroundColor = Colors.darkGrey
        layout()
        clipsToBounds = true
        layer.maskedCorners = [
            CACornerMask.layerMaxXMaxYCorner,
            CACornerMask.layerMaxXMinYCorner,
            CACornerMask.layerMinXMaxYCorner,
            CACornerMask.layerMinXMinYCorner
        ]
        
        layer.borderColor = UIColor.white.cgColor
        layer.borderWidth = 2.0
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        fatalError("Method Not implemented")
    }
    
    func style(view: BeerViewSegmentState) {
        switch view {
        case .gallery:
            galleryLabel.textColor = .white
            galleryImageView.image = Image.create(image: .galleryEnabled)
    
            listLabel.textColor = Colors.graysGray
            listImageView.image = Image.create(image: .listDisabled)
        case .list:
            galleryLabel.textColor = Colors.graysGray
            galleryImageView.image = Image.create(image: .galleryDisabled)
    
            listLabel.textColor = .white
            listImageView.image = Image.create(image: .listEnabled)
        }
    }
    
    private func layout() {
        hStack.translatesAutoresizingMaskIntoConstraints = false
        addSubview(hStack)
        
        NSLayoutConstraint.activate([
            hStack.leadingAnchor.constraint(equalTo: leadingAnchor, constant: BottomBarPadding.horizontal),
            hStack.topAnchor.constraint(equalTo: topAnchor, constant: 6.0),
            hStack.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -BottomBarPadding.horizontal),
            hStack.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -6)
        ])
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        layer.cornerRadius = StyleKit.cornerRadius
    }
    
    @objc private func galleryTapped() {
        valueChanged.send((.gallery))
    }
    
    @objc private func listTapped() {
        valueChanged.send((.list))
    }
    
}

extension GalleryOrListButton {
    
    private enum Image {
        case galleryEnabled
        case listEnabled
        case galleryDisabled
        case listDisabled
        
        var systemName: String {
            switch self {
            case .galleryEnabled, .galleryDisabled: return "homepod"
            case .listEnabled, .listDisabled: return "list.bullet"
            }
        }
        
        var color: UIColor {
            switch self {
            case .galleryEnabled, .listEnabled: return .white
            case .galleryDisabled, .listDisabled: return Colors.graysGray
            }
        }
        
        var config: UIImage.SymbolConfiguration {
            switch self {
            case .galleryEnabled, .galleryDisabled:
                return UIImage.SymbolConfiguration(pointSize: 14, weight: .heavy, scale: .default)
            case .listEnabled, .listDisabled:
                return UIImage.SymbolConfiguration(pointSize: 16, weight: .heavy, scale: .default)
            }
        }
        
        static func create(image: Image) -> UIImage {
            UIImage(
                systemName: image.systemName,
                withConfiguration: image.config
            )!.withTintColor(
                image.color,
                renderingMode: .alwaysOriginal
            )
        }
    }
    
}
