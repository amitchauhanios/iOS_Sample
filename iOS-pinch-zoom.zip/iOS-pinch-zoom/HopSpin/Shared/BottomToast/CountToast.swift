//
//  CountToast.swift
//  HopSpin
//
//  Created by Antonio Carella on 9/3/23.
//

import UIKit

enum BottomBarPadding {
    static let horizontal = 12.0
    static let vertical = 12.0
}

class CountToast: UIView {
    lazy var label: UILabel = {
        let label = UILabel()
        label.backgroundColor = Colors.darkGrey
        label.textColor = .white
        label.font = .systemFont(ofSize: 22, weight: .bold)
        label.textAlignment = .center
        label.setContentHuggingPriority(.required, for: .vertical)
        label.setContentHuggingPriority(.required, for: .horizontal)
        label.setContentCompressionResistancePriority(.defaultLow, for: .vertical)
        return label
    }()
    
    lazy var uniqueLabel: UIView = {
        let label = UILabel()
        label.backgroundColor = Colors.darkGrey
        label.textColor = .white
        label.font = .systemFont(ofSize: 10, weight: .medium)
        label.textAlignment = .center
        label.text = "Unique"
        return label
    }()
    
    lazy var labelsVStack: UIStackView = {
        let stack = UIStackView(arrangedSubviews: [label, uniqueLabel])
        stack.axis = .vertical
        stack.alignment = .center
        
        return stack
    }()
    
    lazy var labelsStack: UIStackView = {
        let stack = UIStackView(arrangedSubviews: [
            Self.createSpacerView(),
            labelsVStack,
            Self.createSpacerView()
        ])
        stack.axis = .horizontal
        stack.alignment = .center
        
        return stack
    }()
    
    override init(frame: CGRect) {
        super.init(frame: .zero)
        backgroundColor = Colors.darkGrey
        layout()
        clipsToBounds = true
        layer.maskedCorners = [
            CACornerMask.layerMaxXMaxYCorner,
            CACornerMask.layerMaxXMinYCorner,
            CACornerMask.layerMinXMaxYCorner,
            CACornerMask.layerMinXMinYCorner
        ]
        
        layer.borderColor = UIColor.white.cgColor
        layer.borderWidth = 2.0
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        fatalError("Method Not implemented")
    }
    
    private func layout() {
        labelsStack.translatesAutoresizingMaskIntoConstraints = false
        addSubview(labelsStack)
        labelsStack.setContentHuggingPriority(.required, for: .horizontal)
        NSLayoutConstraint.activate([
            labelsStack.leadingAnchor.constraint(
                equalTo: leadingAnchor,
                constant: 2.0
            ),
            labelsStack.topAnchor.constraint(greaterThanOrEqualTo: topAnchor),
            labelsStack.trailingAnchor.constraint(
                equalTo: trailingAnchor,
                constant: -2.0
            ),
            labelsStack.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -6),
            labelsStack.centerYAnchor.constraint(equalTo: centerYAnchor)
        ])
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        layer.cornerRadius = StyleKit.cornerRadius
    }
    
    private static func createSpacerView() -> UIView {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            view.heightAnchor.constraint(equalToConstant: 1.0),
            view.widthAnchor.constraint(equalToConstant: 16.0)
        ])
        
        return view
    }
}
