//
//  ToastPresentation.swift
//  HopSpin
//
//  Created by Antonio Carella on 4/29/24.
//

import Foundation

enum ToastPresentation {
    case display(Int)
    case animateUp(Int)
    case animateDown
    case dismiss
}
