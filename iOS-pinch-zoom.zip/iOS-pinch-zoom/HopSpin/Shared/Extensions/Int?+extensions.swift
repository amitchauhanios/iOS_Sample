//
//  Int?+Extensions.swift
//  HopSpin
//
//  Created by Antonio Carella on 9/7/23.
//

import Foundation

extension Int? {
    var emptyOrValue: String {
        if let self = self {
            return "\(self)"
        }
        
        return ""
    }
}
