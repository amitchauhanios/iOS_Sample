//
//  String+extensions.swift
//  HopSpin
//
//  Created by Antonio Carella on 8/29/23.
//

import Foundation

extension String {
    
    func getStateAbbreviation() -> String {
        let components = self.split(separator: "–")
        if let firstComponent = components.first {
            return firstComponent.trimmingCharacters(in: .whitespaces)
        }
        return ""
    }
    
    var dashIfEmpty: String {
        return self.isEmpty ? "-" : self
    }
    
    var webpageDisplayFormat: String {
        return self.replacingOccurrences(of: "https://", with: "")
    }
    
    var phoneLinkFormat: String {
        return "tel:\(self.replacingOccurrences(of: "-", with: ""))"
    }
    
    var phoneDisplayFormat: String {
        // Remove all non-numeric characters from the string
        let numericString = self.filter { "0"..."9" ~= $0 }
        
        // Ensure we have exactly 10 digits
        guard numericString.count == 10 else {
            return self
        }
        
        // Extract parts of the phone number
        let areaCode = numericString.prefix(3)
        let middle = numericString.dropFirst(3).prefix(3)
        let last = numericString.dropFirst(6)
        
        // Format and return
        return "(\(areaCode)) \(middle)-\(last)"
    }
    
    var emailFormat: String {
        return "mailto:\(self)"
    }
    
    var statusBarColor: StatusBarColor {
        switch self {
        case "lightContent":
            return .lightContent
        case "darkContent":
            return .darkContent
        default:
            return .lightContent
        }
    }
    
    var replacingQuoteWithApostrophe: String {
        self.replacingOccurrences(of: "\u{2019}", with: "\u{0027}")
            .replacingOccurrences(of: "\u{2018}", with: "\u{0027}")
    }
    
    var replacingApostropheWithQuote: String {
        self.replacingOccurrences(of: "\u{2019}", with: "\u{0027}")
            .replacingOccurrences(of: "\u{2018}", with: "\u{0027}")
    }
}
