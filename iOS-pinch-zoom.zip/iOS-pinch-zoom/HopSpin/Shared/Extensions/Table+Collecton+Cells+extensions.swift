//
//  Table+Collecton+Cells+Extensions.swift
//  HopSpin
//
//  Created by Antonio Carella on 23.08.2023.
//

import UIKit

public protocol NibLoadable {
    static var nib: UINib { get }
    static var identifier: String { get }
}

public extension NibLoadable {
    static var nib: UINib {
        UINib(nibName: identifier, bundle: Bundle.main)
    }

    static var identifier: String {
        String(describing: self)
    }
}

public extension UINib {
    convenience init<T>(_: T.Type) {
        self.init(nibName: String(describing: T.self), bundle: Bundle.main)
    }
}

extension UITableViewCell: NibLoadable {}
extension UITableViewHeaderFooterView: NibLoadable {}
extension UICollectionReusableView: NibLoadable {}

public extension UITableView {
    func register<T: UITableViewCell>(_: T.Type) {
        register(T.nib, forCellReuseIdentifier: T.identifier)
    }

    func register<T: UITableViewHeaderFooterView>(_: T.Type) {
        register(T.nib, forHeaderFooterViewReuseIdentifier: T.identifier)
    }

    func dequeue<T: UITableViewCell>(_: T.Type) -> T {
        dequeueReusableCell(withIdentifier: T.identifier) as! T
    }

    func dequeue<T: UITableViewCell>(_: T.Type, for indexPath: IndexPath) -> T {
        dequeueReusableCell(withIdentifier: T.identifier, for: indexPath) as! T
    }

    func dequeueHeaderFooterView<T: UITableViewHeaderFooterView>(_: T.Type) -> T {
        dequeueReusableHeaderFooterView(withIdentifier: T.identifier) as! T
    }
}

public extension UICollectionView {
    func register<T: UICollectionViewCell>(_: T.Type) {
        register(T.nib, forCellWithReuseIdentifier: T.identifier)
    }

    func dequeue<T: UICollectionViewCell>(_: T.Type, for indexPath: IndexPath) -> T {
        dequeueReusableCell(withReuseIdentifier: T.identifier, for: indexPath) as! T
    }

    func register<T: UICollectionReusableView>(_: T.Type, for supplementaryViewOfKind: String) {
        register(T.nib, forSupplementaryViewOfKind: supplementaryViewOfKind, withReuseIdentifier: T.identifier)
    }

    func dequeueReusableCell<T: UICollectionViewCell>(_: T.Type, for indexPath: IndexPath) -> T {
        dequeueReusableCell(withReuseIdentifier: T.identifier, for: indexPath) as! T
    }
}

public extension UICollectionView {
    func select(_ indexPaths: [IndexPath],
                animated: Bool = true,
                scrollPosition: UICollectionView.ScrollPosition = .centeredHorizontally) {
        for indexPath in indexPaths {
            selectItem(at: indexPath, animated: animated, scrollPosition: scrollPosition)
        }
    }

    func deselect(_ indexPaths: [IndexPath], animated: Bool = true) {
        for indexPath in indexPaths {
            deselectItem(at: indexPath, animated: animated)
        }
    }

    func deselectAll(animated: Bool = true) {
        deselect(indexPathsForSelectedItems ?? [], animated: animated)
    }

    func deselectAllInSection(except indexPath: IndexPath) {
        let indexPathsToDeselect = (indexPathsForSelectedItems ?? []).filter {
            $0.section == indexPath.section && $0.row != indexPath.row
        }
        deselect(indexPathsToDeselect)
    }
}

public extension UITableView {

    func select(_ indexPaths: [IndexPath],
                animated: Bool = true,
                scrollPosition: UITableView.ScrollPosition = .none) {
        for indexPath in indexPaths {
            selectRow(at: indexPath, animated: animated, scrollPosition: scrollPosition)
        }
    }

    func deselect(_ indexPaths: [IndexPath], animated: Bool = true) {
        for indexPath in indexPaths {
            deselectRow(at: indexPath, animated: animated)
        }
    }

    func deselectAll(animated: Bool = true) {
        deselect(indexPathsForSelectedRows ?? [], animated: animated)
    }

    func deselectAllInSection(except indexPath: IndexPath) {
        let indexPathsToDeselect = (indexPathsForSelectedRows ?? []).filter {
            $0.section == indexPath.section && $0.row != indexPath.row
        }
        deselect(indexPathsToDeselect)
    }
}

extension UITableViewDiffableDataSource {

    func selectedIndexPaths<T: Hashable>(_ selection: SelectionOptions<T>,
                                         _ transform: (T) -> ItemIdentifierType) ->  [IndexPath] {
        selection.values
            .filter { selection.selectedValues.contains($0) }
            .map { transform($0) }
            .compactMap { indexPath(for: $0) }
    }
}

extension UICollectionViewDiffableDataSource {

    func selectedIndexPaths<T: Hashable>(_ selection: SelectionOptions<T>,
                                         _ transform: (T) -> ItemIdentifierType) ->  [IndexPath] {
        selection.values
            .filter { selection.selectedValues.contains($0) }
            .map { transform($0) }
            .compactMap { indexPath(for: $0) }
    }
}
