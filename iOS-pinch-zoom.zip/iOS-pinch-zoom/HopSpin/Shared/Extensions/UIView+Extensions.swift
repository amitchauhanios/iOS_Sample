//
//  UIView+Extensions.swift
//  HopSpin
//
//  Created by Antonio Carella on 9/11/23.
//

import UIKit

extension UIView {}
