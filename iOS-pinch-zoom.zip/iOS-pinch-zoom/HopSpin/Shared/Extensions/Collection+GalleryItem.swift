//
//  Collection+GalleryItem.swift
//  HopSpin
//
//  Created by Antonio Carella on 4/26/24.
//

import Foundation

extension Collection where Element == GalleryItem {
    var totalUniqueCount: Int {
        let allItems = self
            .flatMap(\.labelURLsAndIds)
            .map(\.url)
        return Set<String>(allItems).count
    }
}
