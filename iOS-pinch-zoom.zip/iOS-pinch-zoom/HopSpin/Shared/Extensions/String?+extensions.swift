//
//  String?+extensions.swift
//  HopSpin
//
//  Created by Antonio Carella on 9/7/23.
//

import Foundation

extension String? {
    
    var coallesceToDash: String {
        if let self { self } else { "-" }
    }
    
    var coallesceToEmpty: String {
        if let self { self } else { "" }
    }
}
