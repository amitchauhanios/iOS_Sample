//
//  UIButton+extensions.swift
//  HopSpin
//
//  Created by Antonio Carella on 12/26/23.
//

import UIKit

extension UIButton {}
