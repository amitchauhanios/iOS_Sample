//
//  UITableViewCell+Sepparator.swift
//  HopSpin
//
//  Created by Antonio Carella on 01.09.2023.
//

import UIKit

public extension UITableViewCell {
    func hideSeparator() {
        separatorInset = Self.hiddenSeparatorInset
    }

    func showFullSeparator() {
        separatorInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
    }
    
    func showStandardSeparator() {
        separatorInset = UIEdgeInsets(top: 0, left: 16, bottom: 0, right: 16)
    }
    
    static let hiddenSeparatorInset: UIEdgeInsets = .init(top: 0, left: CGFloat(Int16.max), bottom: 0, right: 0)
    static let fullSeparatorInset: UIEdgeInsets = .init(top: 0, left: 0, bottom: 0, right: 0)
    static let standardSeparatorInset: UIEdgeInsets = .init(top: 0, left: 16, bottom: 0, right: 16)
}

