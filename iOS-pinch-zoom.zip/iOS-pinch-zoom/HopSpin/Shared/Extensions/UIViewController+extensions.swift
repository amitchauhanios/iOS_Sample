//
//  UIViewController+Extensions.swift
//  HopSpin
//
//  Created by Antonio Carella on 12/28/23.
//

import UIKit
import SwiftUI

extension UIViewController {
    func addChildViewController(_ child: UIViewController) -> UIView {
            // Add Child View Controller
            addChild(child)
            
            // Add Child View as Subview
            view.addSubview(child.view)
            
            // Notify Child View Controller
            child.didMove(toParent: self)
            
            return child.view
    }
    
    func placeLogoInNavBar() {
        // Set the logo as the titleView
        let logo = UIImage(named: "header-logo")
        let imageView = UIImageView(image: logo)
        imageView.contentMode = .scaleAspectFit
        navigationItem.titleView = imageView
        imageView.translatesAutoresizingMaskIntoConstraints = true
        
        NSLayoutConstraint.activate([
            imageView.heightAnchor.constraint(equalToConstant: 31),
            imageView.widthAnchor.constraint(equalToConstant: 103)
        ])
    }
    
    func makeBorderView() -> UIView {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = .lightGray
        return view
    }
    
    func makeMaxScreenAdditionalSafeAreaInsets() -> UIEdgeInsets {
        .init(top: 0.0, left: 4.0, bottom: 0.0, right: 4.0)
    }
    
    func makeMaxScreenAdditionalSafeAreaInsetsInverted() -> UIEdgeInsets {
        .init(top: 0.0, left: -4.0, bottom: 0.0, right: -4.0)
    }
    
    func adjustSafeAreasForMaxScreens() {
        if shouldAdjustSafeAreasForMaxScreens() {
            additionalSafeAreaInsets = makeMaxScreenAdditionalSafeAreaInsets()
        }
    }
    
    /// Presents standard UIAlertAction with "OK" button to dismiss.
    /// - Parameter errorMessage: ErrorMessage to display
    /// - Parameter onCompletion: completion handler to be called when user dismisses alert
    func present(errorMessage: ErrorMessage, onCompletion: (() -> Void)? = nil) {
      let errorAlertController = UIAlertController(title: errorMessage.title,
                                                   message: errorMessage.subtitle,
                                                   preferredStyle: .alert)
      let okAction = UIAlertAction(title: "OK", style: .default)
      errorAlertController.addAction(okAction)
      present(errorAlertController, animated: true, completion: onCompletion)
    }
    
    func lockModal() {
        navigationController?.presentationController?.presentedView?.gestureRecognizers?.forEach {
            $0.isEnabled = false
        }
    }
    

}
