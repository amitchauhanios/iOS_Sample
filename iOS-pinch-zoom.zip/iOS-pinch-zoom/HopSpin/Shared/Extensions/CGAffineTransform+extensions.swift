//
//  CGAffineTransform+extensions.swift
//  HopSpin
//
//  Created by Antonio Carella on 9/13/23.
//

import Foundation

extension CGAffineTransform {
    
    func applyTitleTransform() -> Self {
        self.translatedBy(x: 0, y: 2)
    }
}
