//
//  UINavigationItem+extensions.swift
//  HopSpin
//
//  Created by Antonio Carella on 9/13/23.
//

import UIKit

extension UINavigationItem {
    
    func setTitleTransform() {
        if let transform = self.titleView?.transform {
            titleView?.transform = transform.applyTitleTransform()
        }
    }
}
