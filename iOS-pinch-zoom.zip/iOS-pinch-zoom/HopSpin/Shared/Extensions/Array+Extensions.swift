//
//  Array+Extensions.swift
//  HopSpin
//
//  Created by Antonio Carella on 13.09.2023.
//

import Foundation

extension Array: Comparable where Element: Comparable {
    public static func < (lhs: [Element], rhs: [Element]) -> Bool {
        for (leftElement, rightElement) in Swift.zip(lhs, rhs) {
            if leftElement < rightElement {
                return true
            } else if leftElement > rightElement {
                return false
            }
        }
        return lhs.count < rhs.count
    }
    
    public var isNotEmpty: Bool {
        !self.isEmpty
    }
}

extension Array<String> {
    
    func uniquedAndSorted() -> Self {
        let uniqued = Set<String>(self)
        return Array(uniqued).sorted(by: {
            $0.localizedStandardCompare($1) == .orderedAscending
        })
    }
}

extension Array<Int> {
    
    func uniquedAndSortedYears() -> Self {
        let uniqued = Set<Int>(self)
        return Array(uniqued).sorted(by: >)
    }
    
    func uniquedAndSorted() -> Self {
        let uniqued = Set<Int>(self)
        return Array(uniqued).sorted()
    }
}
