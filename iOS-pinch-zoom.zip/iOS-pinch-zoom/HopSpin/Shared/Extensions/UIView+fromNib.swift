//
//  UIView+fromNib.swift
//  HopSpin
//
//  Created by Antonio Carella on 23.08.2023.
//

import Foundation
import UIKit

public extension UIView {
    class func fromNib(_ nibName: String? = nil) -> Self {
        fromNib(nibName, type: self)
    }

    class func fromNib(in bundle: Bundle) -> Self {
        bundle.loadNibNamed(defaultNibName, owner: nil, options: nil)?.first { $0 is Self } as! Self
    }

    class func fromNib<T: UIView>(_ nibName: String? = nil, type _: T.Type) -> T {
        let view: T? = fromNib(nibName, type: T.self)
        return view!
    }

    class func fromNib<T: UIView>(_ nibName: String? = nil, type _: T.Type) -> T? {
        guard let nibViews = Bundle(for: self).loadNibNamed(nibName ?? defaultNibName, owner: nil, options: nil) else {
            return nil
        }
        return nibViews.first { view -> Bool in
            view is T
        } as? T
    }

    class var defaultNibName: String {
        let name = String(describing: self).components(separatedBy: ".").first ?? ""
        return name
    }

    class var nib: UINib? {
        if Bundle(for: self).path(forResource: defaultNibName, ofType: "nib") != nil {
            return UINib(nibName: defaultNibName, bundle: nil)
        } else {
            return nil
        }
    }
}
