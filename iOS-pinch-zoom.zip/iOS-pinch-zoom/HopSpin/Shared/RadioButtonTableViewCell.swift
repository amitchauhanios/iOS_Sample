//
//  RadioButtonTableViewCell.swift
//  HopSpin
//
//  Created by Antonio Carella on 12/30/23.
//

import UIKit

class RadioButtonTableViewCell: UITableViewCell {
    
    let view = RadioButtonLabelView()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        layout()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func layout() {
        contentView.addSubview(view)
        view.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate {
            view.topAnchor.constraint(equalTo: contentView.topAnchor)
            view.leadingAnchor.constraint(equalTo: contentView.leadingAnchor)
            view.trailingAnchor.constraint(equalTo: contentView.trailingAnchor)
            view.bottomAnchor.constraint(equalTo: contentView.bottomAnchor)
        }
    }
    
}
