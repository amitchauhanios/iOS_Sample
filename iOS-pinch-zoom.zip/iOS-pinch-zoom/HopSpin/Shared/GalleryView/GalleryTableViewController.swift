//
//  GalleryTableViewController.swift
//  HopSpin
//
//  Created by Antonio Carella on 11/14/23.
//

import Combine
import Kingfisher
import UIKit
import OrderedCollections

class BeerGalleryTableViewController: GalleryTableViewController {

    init(viewModel: BeerGalleryTableViewModel) {
        super.init(viewModel: viewModel)
        
        galleryOrListButton
            .valueChanged
            .receive(on: DispatchQueue.main)
            .sink { state in
                viewModel.beerViewSegementStateFilterSubject.send(state)
            }
            .store(in: &subscriptions)
        
        galleryOrListButton.style(view: .gallery)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}


class GalleryTableViewController: TableViewController {

    typealias GalleryItemsSnapshot = NSDiffableDataSourceSnapshot<Section, GalleryItem>
    typealias GalleryItemsDataSource = UITableViewDiffableDataSource<Section, GalleryItem>
    
    var galleryDataSource: GalleryItemsDataSource!
    
    static let cellId = "cellId"
    static let headerId = "headerId"
    
    // MARK: Combine
    var subscriptions = Set<AnyCancellable>()
    
    private let viewModel: GalleryItemsViewModel
    
    init(viewModel: GalleryItemsViewModel) {
        self.viewModel = viewModel
        
        super.init(hidesGallerOrListButton: false)
        
        addRefreshControl(color: viewModel.activityIndicatorColor)
        
        self.galleryDataSource = GalleryItemsDataSource(tableView: tableView, cellProvider: { tableView, indexPath, cellViewModel in
            guard let cell = tableView.dequeueReusableCell(withIdentifier: Self.cellId, for: indexPath) as? GalleryTableViewCell else {
                assertionFailure("Error dequeueing GalleryTableViewCell.")
                return UITableViewCell()
            }
            
            cell.separatorInset = UIEdgeInsets(top: 0, left: 500, bottom: 0, right: 0)
            
            for (index, labelURLsAndId) in cellViewModel.labelURLsAndIds.enumerated() {
                let url = Endpoint.image(path: labelURLsAndId.url).url                                
                cell.imageViews[index].kf.setImage(with: url)
                cell.imageViews[index].isUserInteractionEnabled = true
            }
            
            cell.imageSelected = { index in
                viewModel.itemSelected(with: cellViewModel.labelURLsAndIds[index].id)
            }
            
            return cell
        })
        
        self.setupTableView()
        self.bindViewModel()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        viewModel.viewDidAppearSubject.send(())
        if let selectedIndexPath = tableView.indexPathForSelectedRow {
            tableView.deselectRow(at: selectedIndexPath, animated: true)
        }
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        showLoadingView(show: false)
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        tableView.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: 40, right: 0)
    }
    
    private func setupTableView() {
        tableView.rowHeight = UITableView.automaticDimension
        tableView.register(GalleryTableViewCell.self, forCellReuseIdentifier: Self.cellId)
        tableView.delegate = self
        tableView.sectionHeaderTopPadding = 0.0
        
        loadingView.animationStrokeColor = viewModel.activityIndicatorColor
    }
    
    override func constrainLoadingViewBackground() {
        NSLayoutConstraint.activate([
            loadingViewBackground.leadingAnchor.constraint(equalTo: tableView.leadingAnchor),
            loadingViewBackground.topAnchor.constraint(equalTo: tableView.topAnchor),
            loadingViewBackground.trailingAnchor.constraint(equalTo: tableView.trailingAnchor),
            loadingViewBackground.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
    }
        
    
    private func bindViewModel() {
        viewModel
            .galleryItems
            .receive(on: DispatchQueue.main)
            .sink(receiveValue: updateGallery)
            .store(in: &subscriptions)
        
        viewModel
            .errorMessageSubject
            .receive(on: DispatchQueue.main)
            .compactMap { $0 }
            .sink { [weak self] in
                self?.present(errorMessage: $0)
            }
            .store(in: &subscriptions)
        
        viewModel
            .showCountSubject
            .receive(on: DispatchQueue.main)
            .sink(receiveValue: showToast)
            .store(in: &subscriptions)
        
        viewModel
            .showLoadingViewSubject
            .receive(on: DispatchQueue.main)
            .compactMap { $0 }
            .sink(receiveValue: showLoadingView)
            .store(in: &subscriptions)
        
        viewModel
            .tableViewShouldScrollToTop
            .receive(on: DispatchQueue.main)
            .sink { [tableView] in
                tableView.setContentOffset(.zero, animated: true)
            }
            .store(in: &subscriptions)
        
        viewModel
            .showRefreshSubject
            .receive(on: DispatchQueue.main)
            .filter { !$0 }
            .sink { [weak self] _ in
                self?.hideRefreshControl()
            }
            .store(in: &subscriptions)
    }
    
    private func updateGallery(cellViewModels: [GalleryItem]) {
        var snapshot = GalleryItemsSnapshot()
        
        let section = Section(id: UUID(), title: "")
        snapshot.appendSections([section])
        snapshot.appendItems(cellViewModels, toSection: section)
        galleryDataSource.apply(snapshot, animatingDifferences: false)
    }
    
    override func refreshTriggered() {
        viewModel.showRefreshSubject.send(true)
    }
    
    override func userScrolled(direction: UserScrollDirection) {
        // tell view model so it can control toast display
        viewModel.userScrolled(direction: direction)
        
        guard let tabBarController = tabBarController as? MainTabBarController else {
            return
        }
        
        let tabBarVisible: Bool
        switch direction {
        case .down:
            tabBarVisible = false
        default:
            tabBarVisible = true
        }
        
        tabBarController.setTabBarVisible(visible: tabBarVisible, tableView: tableView)
        
    }
}

extension GalleryTableViewController: UITableViewDelegate {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        galleryDataSource.numberOfSections(in: tableView)
    }
}
