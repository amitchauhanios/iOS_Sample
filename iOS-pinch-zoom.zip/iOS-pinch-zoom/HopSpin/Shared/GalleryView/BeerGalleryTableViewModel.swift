//
//  GalleryTableViewModel.swift
//  HopSpin
//
//  Created by Antonio Carella on 11/18/23.
//

import Combine
import Foundation
import UIKit

class BeerGalleryTableViewModel: GenericGalleryViewModel<Beer, BeerGalleryDataProcessor, BeerDataFetcher, BeerSortingOption> {
    
    private let imageRepository: ImageRepository
    let beerViewSegementStateFilterSubject: CurrentValueSubject<BeerViewSegmentState, Never>
    
    init(
        dataFetcher: BeerDataFetcher,
        searchTerm: CurrentValueSubject<String, Never>,
        filters: CurrentValueSubject<FiltersAndOperator, Never>,
        sorting: CurrentValueSubject<(OrderOption, BeerSortingOption), Never>,
        imageRepository: ImageRepository,
        activityIndicatorColor tintColor: UIColor,
        beerViewSegementStateFilterSubject: CurrentValueSubject<BeerViewSegmentState, Never>
    ) {
        self.imageRepository = imageRepository
        self.beerViewSegementStateFilterSubject = beerViewSegementStateFilterSubject
        super.init(
            dataFetcher: dataFetcher,
            searchTerm: searchTerm,
            filters: filters,
            sorting: sorting,
            imageRepository: imageRepository,
            activityIndicatorColor: tintColor
        )
    }
    
    override func itemSelected(with id: String) {
        if let beer = items.first(where: { UUIDHandler.compare(id: $0.id, salted: id) }) {
            delegate?.navigateToBeer(beer, shouldUpdate: nil, tintColor: nil)
        } else {
            let error = ErrorMessage.unknown
            errorMessageSubject.send(error)
        }
    }
    
}
