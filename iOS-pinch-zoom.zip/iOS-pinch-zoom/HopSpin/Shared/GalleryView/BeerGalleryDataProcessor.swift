//
//  BeerGalleryDataProcessor.swift
//  HopSpin
//
//  Created by Antonio Carella on 1/7/24.
//

import Foundation

protocol GalleryDataProcessorProtocol {
    associatedtype ItemType: Listable
    associatedtype SortingOption: Sortable
    static func process(
        items: [ItemType],
        orderOption: OrderOption,
        sortingOption: SortingOption
    ) -> [GalleryItem]
}


// Object responsible for transforming an array of beers into an array of GalleryItems
struct BeerGalleryDataProcessor: GalleryDataProcessorProtocol {
    typealias ItemType = Beer
    typealias SortingOption = BeerSortingOption
    
    static func process(
        items: [Beer],
        orderOption: OrderOption,
        sortingOption: SortingOption
    ) -> [GalleryItem] {
        
        // Sort items first.
        // We want the gallery sort to match the list view sort.
        // Reading left to right / top to bottom in the gallery should be the same
        // as reading top to bottom in the list.
        
        // Use the same object that groups/sorts for the list views.
        // This returns an ordered dictionary, which we can then flatten
        // to get the desired result.
        let grouped = BeerListDataSectionGrouper().group(items: items, sortingOption: sortingOption, orderOption: orderOption)
        
        let flattenedGrouped = grouped.values.flatMap { $0 }
        
        let count = flattenedGrouped.count
        
        return stride(from: 0, to: count, by: 5).map { startIndex in
            let endIndex = min(startIndex + 5, count)
            let chunk = Array(flattenedGrouped[startIndex..<endIndex])
            let labelURLsAndIds = chunk.map {                
                return GalleryItem.UrlAndId(url: $0.featuredAvatar, id: UUIDHandler.salt(id: "\($0.id)"))
            }
            return GalleryItem(labelURLsAndIds: labelURLsAndIds)
        }
    }
}
