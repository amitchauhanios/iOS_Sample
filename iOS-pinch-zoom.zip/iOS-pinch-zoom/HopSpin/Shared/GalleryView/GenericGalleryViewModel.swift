//
//  GenericGalleryViewModel.swift
//  HopSpin
//
//  Created by Antonio Carella on 11/20/23.
//

import Combine
import Foundation
import UIKit

protocol GalleryItemsViewModel {
    var galleryItems: AnyPublisher<[GalleryItem], Never> { get }
    var showLoadingViewSubject: PassthroughSubject<Bool, Never> { get }
    var showRefreshSubject: PassthroughSubject<Bool, Never> { get }
    var errorMessageSubject: PassthroughSubject<ErrorMessage?, Never> { get }
    var viewDidAppearSubject: PassthroughSubject<Void, Never> { get }
    var showCountSubject: PassthroughSubject<ToastPresentation, Never> { get }
    var tableViewShouldScrollToTop: PassthroughSubject<Void, Never> { get }
    var activityIndicatorColor: UIColor { get }
    
    func fetchResults()
    func fetchImage(urlPath: String?) async -> UIImage
    func itemSelected(with id: String)
    func userScrolled(direction: UserScrollDirection)
}

class GenericGalleryViewModel<
    ItemType: Listable,
    Processor: GalleryDataProcessorProtocol,
    Fetcher: DataFetcherProtocol,
    SortingOption: Sortable
>: GalleryItemsViewModel where Processor.ItemType == ItemType, 
                                Processor.SortingOption == SortingOption,
                                Fetcher.ItemType == ItemType,
                                Fetcher.SortingOption == SortingOption
{
    
    // State
    var items: [ItemType] = []
    let itemsSubject = CurrentValueSubject<[GalleryItem], Never>([])
    var galleryItems: AnyPublisher<[GalleryItem], Never> {
        itemsSubject.eraseToAnyPublisher()
    }
    let activityIndicatorColor: UIColor

    // Combine
    let showLoadingViewSubject = PassthroughSubject<Bool, Never>()
    let showRefreshSubject = PassthroughSubject<Bool, Never>()
    let errorMessageSubject = PassthroughSubject<ErrorMessage?, Never>()
    let viewDidAppearSubject = PassthroughSubject<Void, Never>()
    let tableViewShouldScrollToTop = PassthroughSubject<Void, Never>()
    let showCountSubject = PassthroughSubject<ToastPresentation, Never>()
    private var cancellables = Set<AnyCancellable>()

    // Dependencies
    let dataFetcher: Fetcher
    private let searchTerm: CurrentValueSubject<String, Never>
    private let filters: CurrentValueSubject<FiltersAndOperator, Never>
    private let sorting: CurrentValueSubject<(OrderOption, SortingOption), Never>
    private let imageRepository: ImageRepository
    weak var delegate: SearchResultSelectedHandler?

    init(
        dataFetcher: Fetcher,
        searchTerm: CurrentValueSubject<String, Never>,
        filters: CurrentValueSubject<FiltersAndOperator, Never>,
        sorting: CurrentValueSubject<(OrderOption, SortingOption), Never>,
        imageRepository: ImageRepository,
        activityIndicatorColor: UIColor
    ) {
        self.dataFetcher = dataFetcher
        self.searchTerm = searchTerm
        self.filters = filters
        self.sorting = sorting
        self.imageRepository = imageRepository
        self.activityIndicatorColor = activityIndicatorColor
        self.bind()
    }
    
    private func bind() {
        
        showRefreshSubject
            .filter { $0 }
            .sink { [weak self] _ in
                self?.fetchResults()
            }
            .store(in: &cancellables)
        
        Publishers
            .CombineLatest3(
                searchTerm,
                filters,
                viewDidAppearSubject.first()
            )
            .sink { [weak self] searchTerm, filters, _ in
                self?.fetchResults()
                self?.showLoadingViewSubject.send(true)
            }
            .store(in: &cancellables)
        
        // whenever we filter or sort, scroll the table view to the top
        filters
            .combineLatest(sorting)
            .sink { [weak self] _ in
                self?.tableViewShouldScrollToTop.send(())
            }
            .store(in: &cancellables)
        
        sorting
            .dropFirst()
            .sink { [weak self] sorting in
                guard let self else { return }
                self.fetchResults()
                self.showLoadingViewSubject.send(true)
            }
            .store(in: &cancellables)
        
         itemsSubject
            .map { $0.totalUniqueCount }
            .sink(receiveValue: { [weak self] count in
                self?.showCountSubject.send(.display(count))
            })
            .store(in: &cancellables)
    }

    var fetchedResult = 0
    
    func fetchResults() {
        Task {
            do {
                
                let filteredSearchTerm = searchTerm.value.replacingQuoteWithApostrophe
                
                print("\(fetchedResult): fetched results")
                fetchedResult += 1
                let fetchedItems = try await dataFetcher.fetchItems(
                    searchTerm: filteredSearchTerm,
                    filters: filters.value,
                    sorting: sorting.value
                )
                
                self.items = fetchedItems
                let processed = process(items: fetchedItems)
                print("Results processed \(Date().description)", processed.reduce(0, { partialResult, item in partialResult + item.labelURLsAndIds.count}))
                itemsSubject.send(processed)
                
                showLoadingViewSubject.send(false)
                showRefreshSubject.send(false)
            } catch {
                showLoadingViewSubject.send(false)
                showRefreshSubject.send(false)
                let errorMessage = ErrorMessage(
                    title: "Error",
                    subtitle: error.localizedDescription
                )
                errorMessageSubject.send(errorMessage)
                print("Error", error)
            }
        }
    }
    
    func process(items: [ItemType]) -> [GalleryItem] {
        Processor.process(
            items: items,
            orderOption: sorting.value.0,
            sortingOption: sorting.value.1
        )
    }
    
    func fetchImage(urlPath: String?) async -> UIImage {
        do {
            if
                let urlPath,
                let image = try await imageRepository.image(path: urlPath)
            {
                return image
            }
            
            return UIImage(named: "avatar")!
            
        } catch {
            
            // TODO: report error
            return UIImage(named: "avatar")!
            
        }
    }
    
    func userScrolled(direction: UserScrollDirection) {
        switch direction {
        case .down:            
            showCountSubject.send(.animateDown)
        default:
            let total = itemsSubject.value.totalUniqueCount
            showCountSubject.send(.animateUp(total))
        }
    }
    
    func itemSelected(with id: String) {
        assertionFailure("Subclasses should override")
    }
    
    func itemSelected(at indexPath: IndexPath) {
        assertionFailure("Subclasses should override")
    }
}
