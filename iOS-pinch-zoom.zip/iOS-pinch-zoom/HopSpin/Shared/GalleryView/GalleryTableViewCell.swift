//
//  GalleryTableViewCell.swift
//  HopSpin
//
//  Created by Antonio Carella on 8/23/23.
//

import Kingfisher
import UIKit

class GalleryTableViewCell: UITableViewCell {

    private(set) var labelImageViewTapRecognizers = [UITapGestureRecognizer]()
    
    var imageSelected: ((Int) -> Void)?
    
    private lazy var shelfImageView: UIImageView = {
        let imageView = UIImageView(image: .init(named: "shelf"))
        imageView.contentMode = .scaleAspectFit
        imageView.heightAnchor.constraint(equalToConstant: 33.0).isActive = true
        return imageView
    }()
    
    lazy var imageViews: [UIImageView] = {
        (1...5).map { _ in
            let view = UIImageView()
            view.contentMode = .scaleAspectFit
            view.translatesAutoresizingMaskIntoConstraints = false
            let height = view.heightAnchor.constraint(equalToConstant: 75.0)
            height.priority = .init(999.0)
            NSLayoutConstraint.activate([
                height,
                view.widthAnchor.constraint(equalToConstant: 50.0)
            ])
            
            view.isUserInteractionEnabled = true
            let gestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(tapRecognized(gestureRecongizer:)))
            view.addGestureRecognizer(gestureRecognizer)
            labelImageViewTapRecognizers.append(gestureRecognizer)
            return view
        }
    }()
    
    private lazy var hStack: UIStackView = {
        
        let leadingSpacer = UIView()
        let trailingSpacer = UIView()
        leadingSpacer.frame = CGRect(x: 0, y: 0, width: 8.0, height: 0.0)
        trailingSpacer.frame = CGRect(x: 0, y: 0, width: 8.0, height: 0.0)
        
        var views = [leadingSpacer]
        views.append(contentsOf: imageViews)
        views.append(trailingSpacer)
        
        let stack = UIStackView(arrangedSubviews: views)
        stack.distribution = .equalSpacing
        return stack
    }()
    
    private lazy var vStack: UIStackView = {
        let stack = UIStackView(arrangedSubviews: [
            hStack, shelfImageView
        ])
        stack.axis = .vertical
        stack.spacing = -12
        return stack
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        selectionStyle = .none
        layout()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        selectionStyle = .none
        layout()
    }
    
    private func layout() {
        contentView.addSubview(vStack)
        vStack.sendSubviewToBack(shelfImageView)
        vStack.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            vStack.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16.0),
            vStack.topAnchor.constraint(equalTo: contentView.layoutMarginsGuide.topAnchor),
            vStack.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16.0),
            vStack.bottomAnchor.constraint(equalTo: contentView.layoutMarginsGuide.bottomAnchor)
        ])
    }
    
    @objc private func tapRecognized(gestureRecongizer: UITapGestureRecognizer) {
        if let index = labelImageViewTapRecognizers.firstIndex(of: gestureRecongizer) {            
            imageSelected?(index)
        }
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        imageViews.forEach {
            $0.image = nil
            $0.isUserInteractionEnabled = false
        }
    }
}
