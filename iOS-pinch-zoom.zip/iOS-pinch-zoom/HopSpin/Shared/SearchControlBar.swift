//
//  ControlBar.swift
//  HopSpin
//
//  Created by Antonio Carella on 8/15/23.
//


import Combine
import UIKit
import BetterSegmentedControl

enum FilterSegmentTitles {
    case search
    case cellar
    
    var titlesArray: [String] {
        switch self {
        case .search:
            return ["Beers", "Breweries", "Artists"]
        case .cellar:
            return ["All", "Have", "Want", "Had"]
        }
    }
}

class SearchControlBar: UIView {
        
    private static let buttonDimensions = 36.0
    
    private let config: SearchControlBarConfig
    
    private let filterSegmentTapSubject = PassthroughSubject<Int, Never>()
    var filterSegmentTap: AnyPublisher<Int, Never> {
        filterSegmentTapSubject.eraseToAnyPublisher()
    }
    
    private let filterSortButtonTapSubject = PassthroughSubject<Void, Never>()
    var filterSortButtonTap: AnyPublisher<Void, Never> {
        filterSortButtonTapSubject.eraseToAnyPublisher()
    }
    
    private let sortButtonTapSubject = PassthroughSubject<Void, Never>()
    var sortButtonTap: AnyPublisher<Void, Never> {
        sortButtonTapSubject.eraseToAnyPublisher()
    }
    
    /// A segmented control meant to determine the top level filtering of the view
    ///  E.g.: Beer vs Brewery vs Artist
    var filterSegmentedControl: BetterSegmentedControl!
    
    /// A button meant to present the filter options ViewController
    private lazy var filterSortButton: UIButton = {
        let button = UIButton()
        button.backgroundColor = .white
        let symbolConfig = UIImage.SymbolConfiguration(pointSize: 17, weight: .bold, scale: .default)
        button.setImage(
            .init(
                systemName: "checklist",
                withConfiguration: symbolConfig
            )!
                .withRenderingMode(.alwaysTemplate),
                for: .normal
        )
        button.addTarget(self, action: #selector(filterSortButtonAction), for: .touchUpInside)
        button.tintColor = config.buttonTintColor
        return button
    }()
    
    private static let badgeViewHeight: CGFloat = 22.0
    private lazy var badgeView: UILabel = {
        let badge = UILabel()
        badge.backgroundColor = Colors.badgeRed
        badge.textColor = .white
        badge.font = .systemFont(ofSize: 15.0, weight: .semibold)
        badge.textAlignment = .center
        badge.layer.masksToBounds = true
        badge.layer.cornerRadius = Self.badgeViewHeight / 2
        badge.setContentHuggingPriority(.required, for: .vertical)
        badge.setContentHuggingPriority(.required, for: .horizontal)
        return badge
    }()
    
    private var badgeWidthConstraint: NSLayoutConstraint!
    
    private lazy var hStack: UIStackView = {
        let stack = UIStackView(arrangedSubviews: [
            filterSegmentedControl,
            filterSortButton
        ])
        
        stack.spacing = UIStackView.spacingUseSystem
        
        return stack
    }()
    
    private let overlayView = UIView()
    private lazy var background = createBlurView()
    
    private var subscriptions = Set<AnyCancellable>()

    init(
        config: SearchControlBarConfig
    ) {
        self.config = config
        super.init(frame: .zero)
        setupFilterSegmentedControl()
        style()
        layout()
        bind()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func style() {
        style(segmentedControl: filterSegmentedControl, config: config.filterControlConfig)
        backgroundColor = .white
        filterSortButton.layer.cornerRadius = StyleKit.cornerRadius
        if config.addsOverlay {
            overlayView.backgroundColor = UIColor(red: 0.46, green: 0.46, blue: 0.5, alpha: 0.12)
        } else {
            overlayView.isHidden = true
        }
        
        badgeView.isHidden = true
    }
    
    private func style(segmentedControl: BetterSegmentedControl, config: SegmentedControlConfig) {
        segmentedControl.cornerRadius = 15.0
        segmentedControl.indicatorViewInset = 3.0
        segmentedControl.backgroundColor = config.backgroundColor
        segmentedControl.indicatorViewBackgroundColor = config.selectedSegmentTintColor
    }
    
    private func setupFilterSegmentedControl() {
        let segments = config.filterTitles.map { title in
            let segment = LabelSegment(
                text: title,
                normalBackgroundColor: .white,
                normalFont: config.filterControlConfig.normalFont,
                normalTextColor: config.filterControlConfig.normalTextColor,
                selectedBackgroundColor: config.filterControlConfig.selectedSegmentTintColor,
                selectedFont: config.filterControlConfig.selectedFont,
                selectedTextColor: config.filterControlConfig.selectedTextColor,
                accessibilityIdentifier: nil
            )
            return segment
        }
        filterSegmentedControl = BetterSegmentedControl(frame: .zero, segments: segments)
        filterSegmentedControl.setIndex(0)
        filterSegmentedControl.animationDuration = 0.5
        filterSegmentedControl.animationSpringDamping = 1.0
        filterSegmentedControl.addTarget(self, action: #selector(filterSegmentedControlOnValueChanged), for: .valueChanged)
    }
    
    private func layout() {
        background.translatesAutoresizingMaskIntoConstraints = false
        addSubview(background)
        
        addSubview(overlayView)
        overlayView.translatesAutoresizingMaskIntoConstraints = false
        
        hStack.translatesAutoresizingMaskIntoConstraints = false
        addSubview(hStack)
        
        filterSortButton.addSubview(badgeView)
        badgeView.translatesAutoresizingMaskIntoConstraints = false
        
        badgeWidthConstraint = badgeView.widthAnchor.constraint(equalToConstant: badgeWidth(for: 0))
        
        NSLayoutConstraint.activate([
            background.leadingAnchor.constraint(equalTo: leadingAnchor),
            background.topAnchor.constraint(equalTo: topAnchor),
            background.trailingAnchor.constraint(equalTo: trailingAnchor),
            background.bottomAnchor.constraint(equalTo: bottomAnchor),
            
            overlayView.leadingAnchor.constraint(equalTo: leadingAnchor),
            overlayView.topAnchor.constraint(equalTo: topAnchor),
            overlayView.trailingAnchor.constraint(equalTo: trailingAnchor),
            overlayView.bottomAnchor.constraint(equalTo: bottomAnchor),
            
            filterSortButton.heightAnchor.constraint(equalToConstant: Self.buttonDimensions),
            filterSortButton.widthAnchor.constraint(equalToConstant: Self.buttonDimensions),
            
            hStack.leadingAnchor.constraint(equalTo: safeAreaLayoutGuide.leadingAnchor, constant: 16.0),
            hStack.topAnchor.constraint(equalTo: layoutMarginsGuide.topAnchor),
            hStack.trailingAnchor.constraint(equalTo: safeAreaLayoutGuide.trailingAnchor, constant: -16.0),
            hStack.bottomAnchor.constraint(equalTo: layoutMarginsGuide.bottomAnchor),
                        
            badgeView.topAnchor.constraint(equalTo: filterSortButton.topAnchor, constant: -4),
            badgeView.trailingAnchor.constraint(equalTo: filterSortButton.trailingAnchor, constant: 10),
            badgeView.heightAnchor.constraint(equalToConstant: Self.badgeViewHeight),
            badgeWidthConstraint
        ])
    }
    
    private func bind() {
        filterSegmentTap
            .sink { [weak self] index in
                guard let self = self else { return }
                self.handleFilterSegmentTap(
                    index: index
                )
            }.store(in: &subscriptions)
    }
    
    private func createBlurView() -> UIImageView {
        let imageView = UIImageView()
        let view = UIView()
        
        if let name = config.backgroundImageName, let image = UIImage(named: name) {
            imageView.image = image
            view.backgroundColor = .white
            view.alpha = 0.25
        } else {
            view.backgroundColor = config.backgroundColor
        }
                
        imageView.addSubview(view)
        view.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            view.leadingAnchor.constraint(equalTo: imageView.leadingAnchor),
            view.topAnchor.constraint(equalTo: imageView.topAnchor),
            view.trailingAnchor.constraint(equalTo: imageView.trailingAnchor),
            view.bottomAnchor.constraint(equalTo: imageView.bottomAnchor)
        ])
        return imageView
    }
    
    private func handleFilterSegmentTap(index: Int) {
        filterSegmentedControl.setIndex(index)
    }
    
    @objc private func filterSegmentedControlOnValueChanged() {
        filterSegmentTapSubject.send(filterSegmentedControl.index)
    }
    
    func setFilterAndSortButtons(enabled: Bool) {
        filterSortButton.isEnabled = enabled
        let tintColor = enabled ? config.buttonTintColor : Colors.greyText        
        filterSortButton.tintColor = tintColor
    }

    @objc private func filterSortButtonAction(sender: UIButton) {
        filterSortButtonTapSubject.send(())
    }

    @objc private func sortingButtonAction(sender: UIButton) {
        sortButtonTapSubject.send(())
    }
    
    func badgeFilterSortButton(withNumber number: Int) {
        if number == 0 {
            badgeView.isHidden = true
            return
        }
        
        let width = badgeWidth(for: number)
        if badgeWidthConstraint.constant != width {
            badgeWidthConstraint.constant = width
            badgeView.setNeedsUpdateConstraints()
        }
        
        badgeView.text = "\(number)"
        badgeView.isHidden = false
    }
    
    private func badgeWidth(for number: Int) -> CGFloat {
        switch number {
            case 0...9: return 22
            case 10...99: return 32
            default: return 42
        }
    }
}
