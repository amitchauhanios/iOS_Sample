//
//  NavigationBarAppearance.swift
//  HopSpin
//
//  Created by Antonio Carella on 11/24/23.
//

import UIKit

struct NavigationBarAppearance {
    let backgroundImage: UIImage?
    let backgroundColor: UIColor
    let statusBarStyle: UIStatusBarStyle
    let shadowColor: UIColor

    init(
        backgroundImage: UIImage? = nil,
        backgroundColor: UIColor,
        statusBarStyle: UIStatusBarStyle = .lightContent,
        shadowColor: UIColor = .clear
    ) {
        
        self.backgroundColor = backgroundColor
        self.backgroundImage = backgroundImage != nil ? backgroundImage : backgroundColor.image(CGSize(width: 500, height: 500))
        self.statusBarStyle = statusBarStyle
        self.shadowColor = shadowColor
    }
    
    var standardAppearance: UINavigationBarAppearance {
        let standardAppearance = UINavigationBarAppearance()
        standardAppearance.configureWithOpaqueBackground()
        standardAppearance.backgroundImage = self.backgroundImage
        standardAppearance.backgroundColor = self.backgroundColor
        standardAppearance.titleTextAttributes = [
            .foregroundColor: self.statusBarStyle.color,
            .font: UIFont.systemFont(ofSize: 20.0, weight: .semibold)
        ]
        standardAppearance.shadowColor = shadowColor
        
        return standardAppearance
    }
    
    var compactAppearance: UINavigationBarAppearance {
        let compactAppearance = standardAppearance.copy()
        compactAppearance.backgroundImage = self.backgroundImage
        compactAppearance.backgroundColor = self.backgroundColor
        compactAppearance.titleTextAttributes = [.foregroundColor: self.statusBarStyle.color]
        compactAppearance.shadowColor = shadowColor
        return compactAppearance
    }
}

extension NavigationBarAppearance {
    static let `default`: NavigationBarAppearance = .init(
        backgroundImage: .init(named: "navigation-header-background"),
        backgroundColor: .white,
        statusBarStyle: .lightContent,
        shadowColor: .clear
    )
    
    static let defaultDarkStatusBar: NavigationBarAppearance = .init(
        backgroundImage: .init(named: "navigation-header-background"),
        backgroundColor: .white,
        statusBarStyle: .darkContent,
        shadowColor: .clear
    )
}

extension UIColor {
    func image(_ size: CGSize = CGSize(width: 1, height: 1)) -> UIImage {
        return UIGraphicsImageRenderer(size: size).image { rendererContext in
            self.setFill()
            rendererContext.fill(CGRect(origin: .zero, size: size))
        }
    }
}

extension UIStatusBarStyle {
    
    var color: UIColor {
        switch self {
        case .lightContent: return .white
        case .darkContent: return .black
        case .default: return .white
        @unknown default: return .white
        }
    }
    
}
