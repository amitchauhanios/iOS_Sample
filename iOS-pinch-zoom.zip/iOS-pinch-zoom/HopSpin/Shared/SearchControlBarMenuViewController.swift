//
//  SearchControlBarMenuViewController.swift
//  HopSpin
//
//  Created by Antonio Carella on 4/28/24.
//

import UIKit
import Combine

struct SearchControlBarMenuContent {
    let sortTitle: String
    let sortValue: String
    let filterTitle: String
    let filterValue: String
    let tintColor: UIColor
    let tapColor: UIColor
}

class SearchControlBarMenuViewController: UITableViewController, UIPopoverPresentationControllerDelegate {
    private let content: SearchControlBarMenuContent
    private let menuItems = "menuItems"
    private let seperator = "seperator"
    private let refresh = "refresh"
    
    let sortTapped = PassthroughSubject<Void, Never>()
    let filterTapped = PassthroughSubject<Void, Never>()
    let resetTapped = PassthroughSubject<Void, Never>()
    
    init(content: SearchControlBarMenuContent) {
        self.content = content
        super.init(style: .plain)
        modalPresentationStyle = .popover
        preferredContentSize = CGSize(width: 300, height: 160.5)
        presentationController?.delegate = self
        popoverPresentationController?.permittedArrowDirections = UIPopoverArrowDirection(rawValue:0)
        popoverPresentationController?.popoverLayoutMargins = .init(top: 0, left: 0, bottom: 0, right: 16)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.register(SearchControlBarMenuCell.self, forCellReuseIdentifier: menuItems)
        tableView.register(SearchControlBarMenuRefreshCell.self, forCellReuseIdentifier: refresh)
        tableView.isScrollEnabled = false
        tableView.showsVerticalScrollIndicator = false
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 4
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        switch indexPath.row {
        case 0:
            let cell = SearchControlBarMenuCell(style: .subtitle, reuseIdentifier: menuItems)
            return setupMenuCell(
                cell: cell,
                titleText: content.sortTitle,
                subtitleText: content.sortValue,
                tintColor: content.tintColor,
                symbolName: "arrow.down",
                tapColor: content.tapColor
            )
        case 1:
            let cell = SearchControlBarMenuCell(style: .subtitle, reuseIdentifier: menuItems)
            return setupMenuCell(
                cell: cell,
                titleText: content.filterTitle,
                subtitleText: content.filterValue,
                tintColor: content.tintColor,
                symbolName: "line.3.horizontal.decrease",
                tapColor: content.tapColor
            )
        case 2:
            let cell = UITableViewCell(style: .default, reuseIdentifier: seperator)
            cell.contentView.backgroundColor = Colors.lightGrey
            let height = cell.contentView.heightAnchor.constraint(equalToConstant: 8.333)
            height.priority = .defaultHigh
            height.isActive = true
            cell.hideSeparator()
            return cell
        case 3:
            let cell = SearchControlBarMenuRefreshCell(style: .default, reuseIdentifier: refresh)
            cell.titleLabel.textColor = content.tintColor
            cell.accessoryImageView.tintColor = content.tintColor
            let backgroundView = UIView()
            backgroundView.backgroundColor = content.tapColor
            cell.selectedBackgroundView = backgroundView
            cell.separatorInset = .init(top: 0.0, left: 0.0, bottom: 0.0, right: view.bounds.width)
            return cell
        default:
            assertionFailure("Incorrect number of cells for menu")
            return UITableViewCell()
        }
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        switch indexPath.row {
        case 0, 1, 3: return 51.0
        default: return 8
        }
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        switch indexPath.row {
        case 0: sortTapped.send(())
        case 1: filterTapped.send(())
        case 3: resetTapped.send(())
        default: break
        }
    }

    func adaptivePresentationStyle(for controller: UIPresentationController, traitCollection: UITraitCollection) -> UIModalPresentationStyle {
        return .none
    }
}

extension SearchControlBarMenuViewController {
    
    private func setupMenuCell(
        cell: SearchControlBarMenuCell,
        titleText: String,
        subtitleText: String?,
        tintColor: UIColor,
        symbolName: String,
        pointSize: CGFloat = 15.0,
        tapColor: UIColor
    ) -> SearchControlBarMenuCell {
        cell.titleLabel.textColor = tintColor
        cell.titleLabel.text = titleText
        cell.subTitleLabel.text = subtitleText
        cell.showFullSeparator()
        let backgroundView = UIView()
        backgroundView.backgroundColor = tapColor
        cell.selectedBackgroundView = backgroundView
        let symbolConfig = UIImage.SymbolConfiguration(pointSize: pointSize, weight: .semibold, scale: .large)
        cell.accessoryImageView.image = .init(
            systemName: symbolName, withConfiguration: symbolConfig)?
            .withRenderingMode(.alwaysTemplate)
        cell.accessoryImageView.tintColor = tintColor
        return cell
    }
}

class SearchControlBarMenuCell: UITableViewCell {
    
    lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 15.0, weight: .semibold)
        return label
    }()
    
    lazy var subTitleLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 15.0)
        return label
    }()
    
    lazy var labelsStack: UIStackView = {
        let stack = UIStackView(arrangedSubviews: [titleLabel, subTitleLabel])
        stack.axis = .vertical
        return stack
    }()
    
    let accessoryImageView = UIImageView()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        layout()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func layout() {
        contentView.addSubview(labelsStack)
        labelsStack.translatesAutoresizingMaskIntoConstraints = false
        
        contentView.addSubview(accessoryImageView)
        accessoryImageView.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            labelsStack.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16.0),
            labelsStack.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 6.0),
            labelsStack.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -9.0),
            
            labelsStack.trailingAnchor.constraint(equalTo: accessoryImageView.leadingAnchor),
            accessoryImageView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16.0),
            accessoryImageView.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
            accessoryImageView.heightAnchor.constraint(equalToConstant: 16.0),
            accessoryImageView.widthAnchor.constraint(equalToConstant: 16.0)
        ])
    }
    
}

class SearchControlBarMenuRefreshCell: UITableViewCell {
    
    lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 15.0, weight: .semibold)
        label.text = "Reset Sort And Filters"
        return label
    }()
    
    lazy var accessoryImageView: UIImageView = {
        let symbolConfig = UIImage.SymbolConfiguration(pointSize: 12.0, weight: .semibold, scale: .large)
        return UIImageView(image: .init(
            systemName: "arrow.counterclockwise",
            withConfiguration: symbolConfig)!
            .withRenderingMode(.alwaysTemplate)
        )
    }()
    
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        layout()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func layout() {
        contentView.addSubview(titleLabel)
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        
        contentView.addSubview(accessoryImageView)
        accessoryImageView.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            titleLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16.0),
            titleLabel.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 6.0),
            titleLabel.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -7.0),
            
            titleLabel.trailingAnchor.constraint(equalTo: accessoryImageView.leadingAnchor),
            accessoryImageView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16.0),
            accessoryImageView.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
            accessoryImageView.heightAnchor.constraint(equalToConstant: 16.0),
            accessoryImageView.widthAnchor.constraint(equalToConstant: 16.0)
        ])
    }
    
}
