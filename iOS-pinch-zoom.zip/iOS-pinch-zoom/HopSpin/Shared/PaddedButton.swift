//
//  PaddedButton.swift
//  HopSpin
//
//  Created by Antonio Carella on 12/23/23.
//

import UIKit

class PaddedButton: UIButton {
    let horizontalPadding: CGFloat = 20
    let verticalPadding: CGFloat = 7.0
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        configureButton()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        configureButton()
    }
    
    private func configureButton() {
        // Set default configuration here if needed
        updateConfiguration(title: "Button", titleColor: .black, backgroundColor: .clear, font: UIFont.systemFont(ofSize: 17, weight: .semibold), cornerRadius: 10)
    }
    
    func updateConfiguration(title: String, titleColor: UIColor, backgroundColor: UIColor, font: UIFont, cornerRadius: CGFloat) {
        var config = UIButton.Configuration.filled()
        
        // Setting background properties
        var background = UIButton.Configuration.filled().background
        background.backgroundColor = backgroundColor
        background.cornerRadius = cornerRadius
        config.background = background
        
        // Setting title properties
        var attributedTitle = AttributedString(title)
        attributedTitle.font = font
        attributedTitle.foregroundColor = titleColor
        config.attributedTitle = attributedTitle
        
        // Setting content insets
        config.contentInsets = NSDirectionalEdgeInsets(top: verticalPadding, leading: horizontalPadding, bottom: verticalPadding, trailing: horizontalPadding)
        
        self.configuration = config
        self.invalidateIntrinsicContentSize()
    }
    
    func updateTitle(title: String,
                     font: UIFont = UIFont.systemFont(ofSize: 17.0, weight: .semibold),
                     foreGroundColor: UIColor = .white
    ) {
        var newAttributedTitle = AttributedString(title)
        newAttributedTitle.font = font
        newAttributedTitle.foregroundColor = foreGroundColor
        configuration?.attributedTitle = newAttributedTitle
    }
}



