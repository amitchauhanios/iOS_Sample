//
//  SVGImageProcessor.swift
//  HopSpin
//
//  Created by Antonio Carella on 9/7/23.
//

import UIKit
import Kingfisher
import SVGKitSwift
import SVGKit

public struct SVGImgProcessor:ImageProcessor {
    public var identifier: String = "com.appidentifier.webpprocessor"
    public func process(item: ImageProcessItem, options: KingfisherParsedOptionsInfo) -> KFCrossPlatformImage? {
        switch item {
        case .image(let image):            
            return image
        case .data(let data):
            let imsvg = SVGKImage(data: data)
            return imsvg?.uiImage
        }
    }
}
