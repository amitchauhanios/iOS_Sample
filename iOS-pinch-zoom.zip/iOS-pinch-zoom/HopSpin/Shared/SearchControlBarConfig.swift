//
//  SearchControlBarUIConfig.swift
//  HopSpin
//
//  Created by Antonio Carella on 11/11/23.
//

import UIKit

struct SearchControlBarConfig {
    
    let filterTitles: [String]
    let backgroundImageName: String?
    let backgroundColor: UIColor
    let buttonTintColor: UIColor
    let filterControlConfig: SegmentedControlConfig
    let addsOverlay: Bool

    init(
        filterTitles: [String],
        backgroundImageName: String?,
        backgroundColor: UIColor,
        buttonTintColor: UIColor,
        filterControlConfig: SegmentedControlConfig,
        addsOverlay: Bool
    ) {
        self.filterTitles = filterTitles
        self.backgroundImageName = backgroundImageName
        self.backgroundColor = backgroundColor
        self.buttonTintColor = buttonTintColor
        self.filterControlConfig = filterControlConfig
        self.addsOverlay = addsOverlay
    }
    
    static let discoverView: SearchControlBarConfig = .init(
        filterTitles: FilterSegmentTitles.search.titlesArray,
        backgroundImageName: "navigation-header-background",
        backgroundColor: Colors.hopspinGreen,
        buttonTintColor: Colors.hopspinGreen,
        filterControlConfig: .searchEnabled,
        addsOverlay: true
    )

    static func cellar(
        tint: UIColor,
        backgroundColor: UIColor
    ) -> SearchControlBarConfig {
        .init(
            filterTitles: FilterSegmentTitles.cellar.titlesArray,
            backgroundImageName: nil,
            backgroundColor: backgroundColor,
            buttonTintColor: tint,
            filterControlConfig: .init(tintColor: tint),
            addsOverlay: false
        )
    }
    
}

struct SegmentedControlConfig {
    
    let backgroundColor: UIColor
    let selectedSegmentTintColor: UIColor
    let normalFont: UIFont
    let normalTextColor: UIColor
    let selectedFont: UIFont
    let selectedTextColor: UIColor
    let enabled: Bool
    
    init(
        backgroundColor: UIColor,
        selectedSegmentTintColor: UIColor,
        normalFont: UIFont,
        normalTextColor: UIColor,
        selectedFont: UIFont,
        selectedTextColor: UIColor,
        enabled: Bool
    ) {
        self.backgroundColor = backgroundColor
        self.selectedSegmentTintColor = selectedSegmentTintColor
        self.normalFont = normalFont
        self.normalTextColor = normalTextColor
        self.selectedFont = selectedFont
        self.selectedTextColor = selectedTextColor
        self.enabled = enabled
    }
    
    init(tintColor: UIColor, enabled: Bool = true) {
        self.backgroundColor = .white
        self.selectedSegmentTintColor = tintColor
        self.normalFont = .systemFont(ofSize: 15, weight: .semibold)
        self.normalTextColor = tintColor
        self.selectedFont = .systemFont(ofSize: 15, weight: .semibold)
        self.selectedTextColor = UIColor.white
        self.enabled = enabled
    }
    
    static let searchEnabled: SegmentedControlConfig = .init(
        tintColor: Colors.hopspinGreen
    )
    
    static let searchDisabled: SegmentedControlConfig = .init(
        backgroundColor: .white,
        selectedSegmentTintColor: .white,
        normalFont: .systemFont(ofSize: 15, weight: .semibold),
        normalTextColor: Colors.disabledGrey,
        selectedFont: .systemFont(ofSize: 15, weight: .semibold),
        selectedTextColor: Colors.disabledGrey,
        enabled: false
    )
}
