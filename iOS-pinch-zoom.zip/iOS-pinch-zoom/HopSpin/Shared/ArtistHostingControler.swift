//
//  ArtistHostingControler.swift
//  HopSpin
//
//  Created by Antonio Carella on 12/10/23.
//

import UIKit
import SwiftUI

class ArtistHostingControler: UIHostingController<ArtistDetailView> {
    
    private let navBarAppearance: NavigationBarAppearance
    
    init(
        rootView: ArtistDetailView,
        navBarAppearance: NavigationBarAppearance
    ) {
        self.navBarAppearance = navBarAppearance
        super.init(rootView: rootView)
    }
    
    @MainActor required dynamic init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        adjustSafeAreasForMaxScreens()
        updateNavigationControllerAppearance(navBarAppearance)
    }
}
