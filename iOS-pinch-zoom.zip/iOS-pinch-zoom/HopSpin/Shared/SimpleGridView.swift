//
//  SimpleGridView.swift
//  HopSpin
//
//  Created by Antonio Carella on 12/10/23.
//

import SwiftUI

struct SimpleGridView<Item, ItemView>: View where Item: Identifiable & Hashable, ItemView: View {
    let items: [Item]
    let totalHorizontalInset: CGFloat
    var itemView: (Item) -> ItemView
    private let itemsPerRow = 6
    private let rowSpacing: CGFloat = 8
    private let itemWidth: CGFloat = 38
    
    
    private var screenWidth: CGFloat {
        UIScreen.main.bounds.width
    }
    
    private var horizontalSpacing: CGFloat {
        let totalItemWidth = CGFloat(itemsPerRow) * itemWidth
        let totalSpacingWidth = screenWidth - totalItemWidth - totalHorizontalInset
        let numberOfSpacings = CGFloat(itemsPerRow - 1)
        return max(0, totalSpacingWidth / numberOfSpacings)
    }
    
    private var numberOfRows: Int {
        (items.count + itemsPerRow - 1) / itemsPerRow
    }
    
    private func itemsInRow(_ rowIndex: Int) -> [Item] {
        let startIndex = rowIndex * itemsPerRow
        let endIndex = min(startIndex + itemsPerRow, items.count)
        return Array(items[startIndex..<endIndex])
    }
    
    var body: some View {
        VStack(spacing: rowSpacing) {
            ForEach(0..<numberOfRows, id: \.self) { rowIndex in
                HStack(spacing: horizontalSpacing) {
                    ForEach(itemsInRow(rowIndex), id: \.self) { item in
                        itemView(item)
                            .frame(width: itemWidth, height: itemWidth)
                    }
                    ForEach(0..<(itemsPerRow - itemsInRow(rowIndex).count), id: \.self) { _ in
                        Color.clear.frame(width: itemWidth, height: itemWidth)
                    }
                }
            }
        }
    }
}
