//
//  ThreeDViewPresentable.swift
//  HopSpin
//
//  Created by Antonio Carella on 9/8/23.
//

import Foundation
import Combine

protocol ThreeDViewPresentable: AnyObject {
    func presentThreeDView(data: MenuAnd3DData, shouldUpdate: PassthroughSubject<Void, Never>?)
}
