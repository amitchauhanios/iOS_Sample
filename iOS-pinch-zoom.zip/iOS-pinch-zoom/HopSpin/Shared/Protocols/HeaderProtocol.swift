//
//  HeaderProtocol.swift
//  HopSpin
//
//  Created by Antonio Carella on 23.08.2023.
//

import Foundation
import UIKit

public protocol HeaderItemProtocol {
    func preferredHeaderType() -> HeaderProtocol.Type
}

public extension HeaderProtocol where Self: UITableViewHeaderFooterView {
    static func nib() -> UINib {
        let bundle = Bundle(for: Self.self)
        return UINib(nibName: defaultNibName, bundle: bundle)
    }

    static func identifier() -> String {
        defaultNibName
    }
}

public protocol HeaderProtocol {
    func configure(with: HeaderItemProtocol)

    static func identifier() -> String
}
