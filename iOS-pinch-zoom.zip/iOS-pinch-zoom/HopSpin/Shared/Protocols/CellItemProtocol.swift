//
//  CellItemProtocol.swift
//  HopSpin
//
//  Created by Antonio Carella on 23.08.2023.
//

import Foundation

/// Item with mapping to ReusableCell
public protocol CellItemProtocol {
    func preferredCellType() -> ReusableCellProtocol.Type
}

/// Section with items
public protocol ItemsSectionProtocol {
    var items: [CellItemProtocol] { get }
}

