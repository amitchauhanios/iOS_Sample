//
//  CellProtocol.swift
//  HopSpin
//
//  Created by Antonio Carella on 23.08.2023.
//

import UIKit

public protocol ReusableCellProtocol {
    /// UINib to show cell in table
    ///
    /// - Returns: Nib file
    static func nib() -> UINib

    static func nibFromPackage() -> UINib

    /// Preffered cell identifier
    ///
    /// - Returns: String with preferred cell identifier
    static func identifier() -> String
}

public protocol ConfigurableCellProtocol {
    /// Configure cell with cellItem
    ///
    /// - Parameter cellItem: StoreDetails to be presented in cell
    func configure(with cellItem: CellItemProtocol)
}

public typealias CellProtocol = ReusableCellProtocol & ConfigurableCellProtocol

public extension ReusableCellProtocol where Self: UITableViewCell {
    static func nib() -> UINib {
        let bundle = Bundle(for: Self.self)
        return UINib(nibName: defaultNibName, bundle: bundle)
    }

    static func nibFromPackage() -> UINib {
        fatalError("Not implemented until it is a package!")
        // return UINib(nibName: defaultNibName, bundle: Bundle.compatModule)
    }

    static func identifier() -> String {
        defaultNibName
    }
}

public extension ReusableCellProtocol where Self: UICollectionViewCell {
    static func nib() -> UINib {
        let bundle = Bundle(for: Self.self)
        return UINib(nibName: defaultNibName, bundle: bundle)
    }

    static func nibFromPackage() -> UINib {
        fatalError("Not implemented until it is a package!")
        // return UINib(nibName: defaultNibName, bundle: Bundle.compatModule)
    }

    static func identifier() -> String {
        defaultNibName
    }
}
