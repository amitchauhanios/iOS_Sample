//
//  HopSpinAsyncImage.swift
//  HopSpin
//
//  Created by Antonio Carella on 8/28/23.
//

import Combine
import SwiftUI
import Kingfisher

struct HopSpinAsyncImage: View {
    @ObservedObject var viewModel: AsyncImageViewModel    
    
    var body: some View {
        AsyncImage(url: viewModel.url) { phase in
            switch phase {
            case .success(let image):
                image
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(maxHeight: 150)
                                                            
            case .empty:
                Color.clear
                    .frame(width: 200, height: 150)
            case .failure(let error):
                Text(error.localizedDescription)
            @unknown default:
                EmptyView()
            }
        }
    }
}

class AsyncImageViewModel: ObservableObject {
    var loadingCompleteSubject = PassthroughSubject<Bool, Never>()
    
    var url: URL?
    
    init(url: URL?) {
        self.url = url
    }
}

extension AsyncImageViewModel {
    @ViewBuilder
    func placeholderImage() -> some View {
        Image(systemName: "photo")
            .renderingMode(.template)
            .resizable()
            .aspectRatio(contentMode: .fit)
            .frame(width: 150, height: 150)
            .foregroundColor(.gray)
    }
}

extension AsyncImageViewModel {
    static let test: AsyncImageViewModel = .init(url: URL(string:"https://picsum.photos/200/300")!
    )
}
