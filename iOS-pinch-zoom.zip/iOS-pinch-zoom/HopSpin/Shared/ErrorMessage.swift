//
//  ErrorMessage.swift
//  BlockDirectory
//
//  Created by Antonio Carella on 8/6/23.
//

import Foundation

struct ErrorMessage: Equatable, Identifiable {
    let id = UUID().uuidString
    let title: String
    let subtitle: String
}

extension ErrorMessage {
    static let unknown: ErrorMessage = .init(title: "Something went wrong.", subtitle: "Please try again.")
}
