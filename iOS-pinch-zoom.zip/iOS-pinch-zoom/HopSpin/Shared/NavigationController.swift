//
//  NavigationController.swift
//  HopSpin
//
//  Created by Antonio Carella on 8/20/23.
//

import UIKit
import Combine

class NavigationController: UINavigationController {
    
    private var statusBarStyle: UIStatusBarStyle
    
    private var appearance: NavigationBarAppearance
    
    init(
        rootViewController: UIViewController,
        appearance: NavigationBarAppearance = .default
    ) {
        self.statusBarStyle = appearance.statusBarStyle
        self.appearance = appearance
        super.init(rootViewController: rootViewController)
        self.delegate = self
        self.setupUI(with: appearance)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return statusBarStyle
    }
}

extension NavigationController: UINavigationControllerDelegate {
    func navigationController(_ navigationController: UINavigationController, willShow viewController: UIViewController, animated: Bool) {
        if
            viewController is DiscoverViewController {
            setupUI(with: .default)
        }
        
        viewController.navigationItem.backButtonTitle = ""
    }
}

extension NavigationController: ThreeDViewPresentable {
    func presentThreeDView(
        data: MenuAnd3DData,
        shouldUpdate: PassthroughSubject<Void, Never>?
    ) {
        let viewModel = ThreeDWebViewModel(
            data: data,
            shouldUpdate: shouldUpdate
        )
        viewModel.menuPresenter = self
        let viewController = ThreeDWebView(viewModel: viewModel)
        viewModel.menuPresenter = viewController
        let navigationController = NavigationController(rootViewController: viewController, appearance: self.appearance)
        
        navigationController.isModalInPresentation = true
        self.present(navigationController, animated: true)
    }
}

extension NavigationController: MenuViewPresentable {
    func presentMenuView(data: MenuAnd3DData, shouldUpdate: PassthroughSubject<Void, Never>?) {
        let beerCellarPersister = BeerCellarPersistance()
        let menuViewController = MenuViewController(
            viewModel: MenuViewModel(
                data: data,
                persister: beerCellarPersister,
                shouldUpdate: shouldUpdate
            )
        )
        menuViewController.modalPresentationStyle = .pageSheet
        let nav = NavigationController(rootViewController: menuViewController)
        nav.modalPresentationStyle = .pageSheet
        if let sheet = nav.sheetPresentationController {
            let id = UISheetPresentationController.Detent.Identifier("detentId")
            let detent = UISheetPresentationController.Detent.custom(identifier: id) { context in
                return 342
            }
            
            sheet.detents = [
                detent
            ]
        }
        self.present(nav, animated: true, completion: nil)
    }
}

extension UIViewController {
    
    func updateNavigationControllerAppearance(_ appearance: NavigationBarAppearance) {
        (navigationController as? NavigationController)?.setupUI(with: appearance)
    }
}

extension NavigationController {
    
    func setupUI(with appearance: NavigationBarAppearance) {
        
        // Make sure this is not the BeerCellarViewController's NavigationController that is presenting a beer detail
        // B/c if that's the case, we want to preserve the appearance.
        guard !(viewControllers.first is BeerCellarViewController && viewControllers.count > 1) else {
            return
        }
        
        self.appearance = appearance
        
        let navBar = navigationBar
        
        navBar.tintColor = appearance.statusBarStyle.color
        
        navBar.standardAppearance = appearance.standardAppearance
        navBar.scrollEdgeAppearance = appearance.standardAppearance
        navBar.compactAppearance = appearance.compactAppearance
        navBar.compactScrollEdgeAppearance = appearance.compactAppearance
        
        self.statusBarStyle = appearance.statusBarStyle
        setNeedsStatusBarAppearanceUpdate()
    }
    
}
