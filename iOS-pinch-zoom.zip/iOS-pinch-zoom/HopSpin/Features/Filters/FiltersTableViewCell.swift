//
//  FiltersTableViewCell.swift
//  HopSpin
//
//  Created by Antonio Carella on 12/23/23.
//

import UIKit

class FiltersTableViewCell: UITableViewCell {
    
    private lazy var gestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(onTap))
    
    let countLabel = UILabel()
    let titleLabel = UILabel()
    let checkImageView = UIImageView()
    let disclosureImageView = UIImageView()
    
    var onImageViewTap: (() -> Void)?
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: .default, reuseIdentifier: reuseIdentifier)
        setup()
        layout()
    }
    
    private func setup() {
        checkImageView.addGestureRecognizer(gestureRecognizer)
        checkImageView.isUserInteractionEnabled = true
        
        titleLabel.font = UIFont.systemFont(ofSize: 17.0, weight: .semibold)
        countLabel.font = UIFont.systemFont(ofSize: 17.0, weight: .semibold)                
    }
    
    private func layout() {
        contentView.addSubview(checkImageView)
        checkImageView.translatesAutoresizingMaskIntoConstraints = false
        
        contentView.addSubview(titleLabel)
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        
        contentView.addSubview(countLabel)
        countLabel.translatesAutoresizingMaskIntoConstraints = false
        
        contentView.addSubview(disclosureImageView)
        disclosureImageView.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            
            checkImageView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16.0),
            checkImageView.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
            checkImageView.heightAnchor.constraint(equalToConstant: 22.0),
            checkImageView.widthAnchor.constraint(equalToConstant: 25.0),
            
            titleLabel.leadingAnchor.constraint(equalTo: checkImageView.trailingAnchor, constant: 12.0),
            titleLabel.trailingAnchor.constraint(lessThanOrEqualTo: countLabel.leadingAnchor),
            titleLabel.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 11.0),
            titleLabel.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -11.0),
            
            
            countLabel.trailingAnchor.constraint(equalTo: disclosureImageView.leadingAnchor, constant: -8.0),
            countLabel.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
            
            disclosureImageView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16.0),
            disclosureImageView.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
            
            disclosureImageView.heightAnchor.constraint(equalToConstant: 15.0),
            disclosureImageView.widthAnchor.constraint(equalToConstant: 11.0)
        ])
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc private func onTap() {
        onImageViewTap?()
    }
}


