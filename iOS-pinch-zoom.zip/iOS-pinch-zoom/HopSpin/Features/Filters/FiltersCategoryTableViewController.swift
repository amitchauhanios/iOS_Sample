//
//  FiltersCategoryTableViewController.swift
//  HopSpin
//
//  Created by Antonio Carella on 12/24/23.
//

import UIKit
import Combine

class FilterCategoryViewModel {
    @Published var data: FilterCategory
    
    let tintColor: UIColor
    let sectionTitleBackgroundColor: UIColor
    
    init(
        data: FilterCategory,
        tintColor: UIColor,
        sectionTitleBackgroundColor: UIColor
    ) {
        self.data = data
        self.tintColor = tintColor
        self.sectionTitleBackgroundColor = sectionTitleBackgroundColor
    }
    
    func filterSelected(title: String) {
        if title == FilterCategory.allTitle {
            data.togleSelectionStateForAll()
        } else {
            data.toggleSelectionState(for: title)
        }
    }
    
    func filterSelected(indexPath: IndexPath) {
        if indexPath.section == 0 {
            data.togleSelectionStateForAll()
        } else {
            let title = data.options[indexPath.row].title
            data.toggleSelectionState(for: title)
        }
    }
}

class FilterCategoryTableViewController: UITableViewController {
    
    enum Section {
        case all
        case filters
    }
    
    private let viewModel: FilterCategoryViewModel
    
    typealias ItemsSnapshot = NSDiffableDataSourceSnapshot<Section, FiltersRowViewModel>
    typealias ItemsDataSource = UITableViewDiffableDataSource<Section, FiltersRowViewModel>
    
    private let button = UIButton()
    
    private lazy var backButtonView: UIView = {
        let view = UIView()
        let button = UIButton()
        var config = UIButton.Configuration.filled()
        config.baseBackgroundColor = viewModel.sectionTitleBackgroundColor
        config.title = viewModel.data.title
        config.baseForegroundColor = .black  // Used for the text color
        config.image = UIImage(named: "back-chevron")?.withTintColor(viewModel.tintColor, renderingMode: .alwaysOriginal)
        config.imagePlacement = .leading
        config.contentInsets = NSDirectionalEdgeInsets(top: 0.0, leading: 0.0, bottom: 0.0, trailing: 0.0)
        config.imagePadding = 10  // Distance between the image and the text
        config.titleTextAttributesTransformer = UIConfigurationTextAttributesTransformer { incoming in
            var outgoing = incoming
            outgoing.font = UIFont.systemFont(ofSize: 20.0, weight: .semibold)
            return outgoing
        }

        button.configuration = config
        button.addTarget(self, action: #selector(backButtonTapped), for: .touchUpInside)
        button.sizeToFit()
        view.addSubview(button)
        view.frame = button.bounds
        return view
    }()
    
    var dataSource: ItemsDataSource!
    
    weak var applyButtonDelegate: ApplyButtonUpdater?
    
    private let cellId = "cellId"
    
    private var cancellables = Set<AnyCancellable>()

    init(viewModel: FilterCategoryViewModel) {
        self.viewModel = viewModel
        super.init(nibName: nil, bundle: nil)
        setupDataSource()
        
        viewModel.$data
            .receive(on: DispatchQueue.main)
            .sink { [weak self] data in
                self?.updateList(data: data)
                self?.applyButtonDelegate?.updateButtonText()
            }
            .store(in: &cancellables)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupTableView()
        navigationItem.leftBarButtonItem = UIBarButtonItem(customView: backButtonView)
    }
    
    private func setupDataSource() {
        dataSource = ItemsDataSource(tableView: self.tableView, cellProvider: { [weak self] tableView, indexPath, itemIdentifier in
            guard let self else { return UITableViewCell() }
            guard let cell = tableView.dequeueReusableCell(withIdentifier: self.cellId, for: indexPath) as? FiltersTableViewCell else {
                assertionFailure("Incorrect Cell Dequeue")
                return UITableViewCell()
            }
            
            cell.titleLabel.text = itemIdentifier.text
            
            cell.checkImageView.image = FilterStateImageProvider.image(for: itemIdentifier.selectionState, tintColor: self.viewModel.tintColor)
            cell.checkImageView.isUserInteractionEnabled = false
            cell.separatorInset = itemIdentifier.isFinalRow ? UIEdgeInsets(top: 0.0, left: .greatestFiniteMagnitude, bottom: 0.0, right: 0.0) : UIEdgeInsets(top: 0.0, left: 16.0, bottom: 0.0, right: 16.0)
            
            cell.selectionStyle = .none
            
            return cell
        })
    }
    
    private func updateList(data: FilterCategory) {
        var snapshot = ItemsSnapshot()
        
        snapshot.appendSections([.all])
        
        let item = FiltersRowViewModel(
            text: FilterCategory.allTitle,
            selectionState: data.selectionState,
            selectedCount: data.calculateSelectedCount(),
            isFinalRow: false
        )
        
        snapshot.appendItems([item], toSection: .all)
        
        let otherRows = data
            .options
            .enumerated()
            .map { option in
                FiltersRowViewModel(
                    text: option.element.title,
                    selectionState: option.element.selectionState,
                    selectedCount: 0,
                    isFinalRow: option.offset == data.options.count - 1
                )
            }
        
        if otherRows.count > 0 {
            snapshot.appendSections([.filters])
            snapshot.appendItems(otherRows, toSection: .filters)
        }
                
        dataSource.apply(snapshot, animatingDifferences: false)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupTableView() {
        tableView.register(FiltersTableViewCell.self, forCellReuseIdentifier: cellId)
        tableView.delegate = self
        tableView.contentInset.bottom = 44.0
        tableView.tableHeaderView = UIView() // remove top seperator
    }
    
    @objc private func backButtonTapped() {
        self.navigationController?.popViewController(animated: true)
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.viewModel.filterSelected(indexPath: indexPath)
    }
}
