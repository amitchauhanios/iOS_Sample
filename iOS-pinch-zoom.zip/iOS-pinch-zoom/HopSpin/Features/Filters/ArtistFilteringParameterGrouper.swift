//
//  ArtistFilteringParameterGrouper.swift
//  HopSpin
//
//  Created by Antonio Carella on 12/6/23.
//

import Foundation
import OrderedCollections

struct ArtistFilteringParameterGrouper {
    
    static func group(filterParams: [FilterParam]) -> OrderedDictionary<String, [FilterParam]> {
        // Step 1: Create a unique set of FilterParams
        let uniqueFilterParams = Dictionary(grouping: filterParams, by: { $0.value.title })
            .mapValues { $0.first! }
            .values

        // Step 2: Group and sort the unique array
        let grouped = Dictionary(grouping: uniqueFilterParams) { $0.key }
        
        // Step 3: Apply custom sorting logic
        let sortedGrouped = grouped.mapValues { values in
            
            var sorted = values.sorted {
                if values.first?.key == ArtistFilterType.yearFounded.title {
                    return $0.value.title.localizedStandardCompare($1.value.title) == .orderedDescending
                } else {
                    return $0.value.title.localizedStandardCompare($1.value.title) == .orderedAscending
                }
            }
            
            if let index = sorted.firstIndex(where: { $0.value.title == Artist.noYearFoundedTitle  }) {
                let moveToback = sorted.remove(at: index)
                sorted.append(moveToback)
            }
            
            return sorted
        }

        let sortOrder = [
            "Brewery Partner",
            "Classification",
            "Location State",
            "Year Founded"
        ]

        // Creating an empty OrderedDictionary
        var orderedDictionary = OrderedDictionary<String, [FilterParam]>()

        // Iterating through sortOrder and populating the orderedDictionary
        for key in sortOrder {
            if let values = sortedGrouped[key] {
                orderedDictionary[key] = values
            }
        }
        
        return orderedDictionary
    }
    
}
