//
//  FiltersTableViewController.swift
//  HopSpin
//
//  Created by Antonio Carella on 12/23/23.
//

import Combine
import UIKit

class FiltersTableViewController: UITableViewController {
    
    enum Section {
        case filters
        case all
    }
    
    private lazy var leftAlignedTitle: UIView = {
        let label = UILabel()
        label.textColor = UIColor.white
        label.text = viewModel.sectionTitle
        label.textColor = .black
        label.font = .systemFont(ofSize: 20.0, weight: .semibold)
        return label
    }()
    
    private let viewModel: FiltersViewModel
    
    typealias ItemsSnapshot = NSDiffableDataSourceSnapshot<Section, FiltersRowViewModel>
    typealias ItemsDataSource = UITableViewDiffableDataSource<Section, FiltersRowViewModel>
    
    var dataSource: ItemsDataSource!
    
    weak var applyButtonDelegate: ApplyButtonUpdater?
    
    private let cellId = "cellId"
    
    private var cancellables = Set<AnyCancellable>()

    init(filtersViewModel: FiltersViewModel) {
        self.viewModel = filtersViewModel
        super.init(nibName: nil, bundle: nil)
        
        setupTableView()
        setupDataSource()
        viewModel.$data
            .receive(on: DispatchQueue.main)
            .sink { [weak self] data in
                self?.updateList(data: data)
                self?.applyButtonDelegate?.updateButtonText()
            }
            .store(in: &cancellables)
        
        self.navigationItem.leftBarButtonItem = UIBarButtonItem.init(customView: leftAlignedTitle)        
    }
    
    private func setupDataSource() {
        
        dataSource = ItemsDataSource(tableView: self.tableView, cellProvider: { [weak self] tableView, indexPath, itemIdentifier in
            guard let self else { return UITableViewCell() }
            guard let cell = tableView.dequeueReusableCell(withIdentifier: self.cellId, for: indexPath) as? FiltersTableViewCell else {
                assertionFailure("Incorrect Cell Dequeue")
                return UITableViewCell()
            }
            
            cell.titleLabel.text = itemIdentifier.text
            
            cell.checkImageView.image = FilterStateImageProvider.image(for: itemIdentifier.selectionState, tintColor: self.viewModel.tintColor)
            if indexPath.section == 0 {
                cell.checkImageView.isUserInteractionEnabled = false
                cell.onImageViewTap = {}
            } else {
                cell.checkImageView.isUserInteractionEnabled = true
                cell.onImageViewTap = {
                    self.viewModel.filterSelected(title: itemIdentifier.text)
                }
            }
            
            if itemIdentifier.selectedCount > 0 && itemIdentifier.text != FilterCategory.allTitle {
                cell.countLabel.text = "\(itemIdentifier.selectedCount)"
                cell.countLabel.textColor = viewModel.tintColor
            } else {
                cell.countLabel.text = ""
            }
            
            let symbolConfig = UIImage.SymbolConfiguration(pointSize: 17, weight: .semibold, scale: .large)
            let symbolImage = UIImage(
                systemName: "chevron.right",
                withConfiguration: symbolConfig
            )?.withTintColor(viewModel.tintColor , renderingMode: .alwaysOriginal)
            
            cell.disclosureImageView.image = itemIdentifier.text == FilterCategory.allTitle ? nil : symbolImage

            itemIdentifier.isFinalRow ? cell.hideSeparator() : cell.showStandardSeparator()
            
            cell.selectionStyle = .none
            
            return cell
        })
        
    }
    
    private func updateList(data: FilterData) {
        var snapshot = ItemsSnapshot()
        
        snapshot.appendSections([.all])
        
        let item = FiltersRowViewModel(
            text: FilterCategory.allTitle,
            selectionState: data.selectionState,
            selectedCount: data.calculateSelectedCount(),
            isFinalRow: false
        )
        
        snapshot.appendItems([item], toSection: .all)
        
        
        snapshot.appendSections([.filters])
                
        let otherRows = data
            .categories
            .enumerated()
            .map { category in
                FiltersRowViewModel(
                    text: category.element.title,
                    selectionState: category.element.selectionState,
                    selectedCount: category.element.calculateSelectedCount(),
                    isFinalRow: category.offset == data.categories.count - 1
                )
        }
        
        if otherRows.count > 0 {
            snapshot.appendItems(otherRows, toSection: .filters)
        }
                
        dataSource.apply(snapshot, animatingDifferences: false)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupTableView() {
        tableView.register(FiltersTableViewCell.self, forCellReuseIdentifier: cellId)
        tableView.delegate = self
        tableView.contentInset.bottom = 44.0
        tableView.tableHeaderView = UIView() // remove top seperator
    }
    
    // TableView Delegate Methods
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {        
        if indexPath.section == 0 {
            self.viewModel.filterSelected(title: FilterCategory.allTitle)
            return
        }

        let viewModel = viewModel.viewModelForCategory(at: indexPath.row)
        let child = FilterCategoryTableViewController(viewModel: viewModel)
        child.applyButtonDelegate = navigationController?.parent as? ApplyButtonUpdater
        navigationController?.pushViewController(child, animated: true)
    }
}
