//
//  FilterStateImageProvider.swift
//  HopSpin
//
//  Created by Antonio Carella on 1/7/24.
//

import UIKit

struct FilterStateImageProvider {
    static func image(for state: FilterSelectionState, tintColor: UIColor) -> UIImage {
        let symbolConfig = UIImage.SymbolConfiguration(pointSize: 17, weight: .regular, scale: .large)
        let imageName: String
        
        switch state {
        case .selected:
            imageName = "checkmark.square.fill"
        case .unselected:
            imageName = "square"
        case .mixed:
            imageName = "minus.square.fill"
        }
        
        return UIImage(
            systemName: imageName,
            withConfiguration: symbolConfig)!
            .withTintColor(
                tintColor,
                renderingMode: .alwaysOriginal
            )
    }
}
