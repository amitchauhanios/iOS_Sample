//
//  BeerFilteringParameterGrouper.swift
//  HopSpin
//
//  Created by Antonio Carella on 12/6/23.
//

import Foundation
import OrderedCollections

struct BeerFilteringParameterGrouper {
    
    static func group(filterParams: [FilterParam]) -> OrderedDictionary<String, [FilterParam]> {
        // Step 1: Group and sort the unique array
        let grouped = Dictionary(grouping: filterParams) { $0.key }
        let uniquedGrouped = grouped.mapValues { array in
            Set(array)
        }

        let abvSort = ABVRange.allCases.map { $0.title }
        
        let ibuSort = IBURange.allCases.map { $0.title }
        
        // Step 2: Apply custom sorting logic
        let sortedGrouped = uniquedGrouped.mapValues { values in
            if values.first?.key == BeerFilterType.abv.title {
                return FilterParameterSorter.sort(filterParameters: Array(values), sortArray: abvSort, movingToBack: Beer.noABVTitle)
            } else if values.first?.key == BeerFilterType.adjunct.title {
                return FilterParameterSorter.sort(filterParameters: Array(values), movingToBack: Beer.noAdjunctsTitle)
            } else if values.first?.key == BeerFilterType.designer.title {
                return FilterParameterSorter.sort(filterParameters: Array(values), movingToBack: Beer.noArtistsTitle)
            } else if values.first?.key == BeerFilterType.awards.title {
                return FilterParameterSorter.sort(filterParameters: Array(values), movingToBack: Beer.noAwardsTitle)
            } else if values.first?.key == BeerFilterType.nonindustry.title {
                return FilterParameterSorter.sort(filterParameters: Array(values), movingToBack: Beer.noNonindustriesTitle)
            } else if values.first?.key == BeerFilterType.brewerySeries.title {
                return FilterParameterSorter.sort(filterParameters: Array(values), movingToBack: Beer.noBrewerySeriesTitle)
            } else if values.first?.key == BeerFilterType.ibu.title {
                return FilterParameterSorter.sort(filterParameters: Array(values), sortArray: ibuSort, movingToBack: Beer.noIBUTitle)
            } else if values.first?.key == BeerFilterType.pourColor.title {
                return FilterParameterSorter.sort(filterParameters: Array(values), sortArray: Beer.pourColorOrder, movingToBack: Beer.noPourColorTitle)
            } else if values.first?.key == BeerFilterType.primaryLabelColor.title {
                return FilterParameterSorter.sort(filterParameters: Array(values), sortArray: Beer.labelColorOrdering)
            } else if values.first?.key == BeerFilterType.hops.title {
                return FilterParameterSorter.sort(filterParameters: Array(values), movingToBack: Beer.noHopTitle)
            }
            else {
                return FilterParameterSorter.sort(filterParameters: Array(values))
            }
        }

        // Sort the section headers
        let sortOrder = [
            "ABV %",
            "Adjunct",
            "Artist",
            "Award",
            "Beer Style",
            "Brewery",
            "Brewery Series",
            "Hop",
            "IBU",
            "Label Style",
            "Nonindustry Collab",
            "Pour Color (SRM)",
            "Primary Label Color",
            "Year First Released",
            "Year Last Released",
            "Year Released"
        ]

        // Creating an empty OrderedDictionary
        var orderedDictionary = OrderedDictionary<String, [FilterParam]>()

        // Iterating through sortOrder and populating the orderedDictionary
        for key in sortOrder {
            if let values = sortedGrouped[key] {
                orderedDictionary[key] = values
            }
        }
        
        return orderedDictionary
    }
    
}

struct FilterParameterSorter {
    static func sort(filterParameters: [FilterParam], sortArray: [String]? = nil, movingToBack: String? = nil) -> [FilterParam] {
        var sorted = filterParameters.sorted {
            // if therels a sort array, use that
            if let sortArray,
               let firstIndex = sortArray.firstIndex(of: $0.value.title),
               let secondIndex = sortArray.firstIndex(of: $1.value.title) {
                return firstIndex < secondIndex
            }
            // otherwise, default to localized standard
            else {
                return $0.value.title.localizedStandardCompare($1.value.title) == .orderedAscending
            }
        }
        
        if let index = sorted.firstIndex(where: { $0.value.title == movingToBack }) {
            let moveToback = sorted.remove(at: index)
            sorted.append(moveToback)
        }
        return sorted
    }
}
