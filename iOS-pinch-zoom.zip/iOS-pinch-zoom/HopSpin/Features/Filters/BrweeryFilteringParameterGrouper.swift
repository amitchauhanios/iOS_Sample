//
//  BrweeryFilteringParameterGrouper.swift
//  HopSpin
//
//  Created by Antonio Carella on 12/6/23.
//

import Foundation
import OrderedCollections

struct BreweryFilteringParameterGrouper {
    
    static func group(filterParams: [FilterParam]) -> OrderedDictionary<String, [FilterParam]> {

        // Step 1: Group and sort the unique array
        let grouped = Dictionary(grouping: filterParams) { $0.key }
        let uniquedGrouped = grouped.mapValues { array in
            Set(array)
        }
        
        let classificationsSort = [
            "Macro Brewery",
            "Regional Brewery",
            "Micro Brewery",
            "Nano Brewery",
            "Pico Brewery",
            "Home Brewery"
        ]
        
        // Step 2: Apply custom sorting logic
        let sortedGrouped = uniquedGrouped.mapValues { values in
            if values.first?.key == BreweryFilterType.classifications.title {
                return values.sorted {
                    guard let firstIndex = classificationsSort.firstIndex(of: $0.value.title),
                          let secondIndex = classificationsSort.firstIndex(of: $1.value.title)
                    else {
                        return $0.value.title.localizedStandardCompare($1.value.title) == .orderedAscending
                    }
                    return firstIndex < secondIndex
                }
            } else if values.first?.key == BreweryFilterType.shippingStates.title {
                var sorted = values.sorted { $0.value.title.localizedStandardCompare($1.value.title) == .orderedAscending }
                if let index = sorted.firstIndex(where: { $0.value.title == Brewery.noShippingStatesTitle }) {
                    let noShipping = sorted.remove(at: index)
                    sorted.append(noShipping)
                }
                return sorted
            } else if values.first?.key == BreweryFilterType.yearFounded.title {
                return values.sorted { $0.value.title.localizedStandardCompare($1.value.title) == .orderedDescending }
            } else {
                return values.sorted { $0.value.title.localizedStandardCompare($1.value.title) == .orderedAscending }
            }
        }

        // Sort the section headers
        let sortOrder = ["Classification", "Distribution State", "Location State", "Shipping State", "Year Founded"]

        // Creating an empty OrderedDictionary
        var orderedDictionary = OrderedDictionary<String, [FilterParam]>()

        // Iterating through sortOrder and populating the orderedDictionary
        for key in sortOrder {
            if let values = sortedGrouped[key] {
                orderedDictionary[key] = values
            }
        }
        
        return orderedDictionary
    }
    
}
