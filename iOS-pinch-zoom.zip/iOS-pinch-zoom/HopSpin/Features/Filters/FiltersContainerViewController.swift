//
//  FiltersContainerViewController.swift
//  HopSpin
//
//  Created by Antonio Carella on 12/23/23.
//

import Combine
import UIKit

protocol ApplyButtonUpdater: AnyObject {
    func updateButtonText()
}

class FiltersContainerViewController: UIViewController {
    
    private let headerHeight: CGFloat = 44
    private let footerHeight: CGFloat = 56
    private var mainNavigationController: UINavigationController!
    
    private let optionHeaderLabel = UILabel()
    private let optionHeaderView = UIView()
    private let orButtonView = RadioButtonLabelView()
    private let andButtonView = RadioButtonLabelView()
    
    private lazy var operatorStack: UIStackView = {
        let stack = UIStackView(arrangedSubviews: [
            orButtonView, andButtonView
        ])
        stack.axis = .vertical
        return stack
    }()
    
    private lazy var cancelButton: PaddedButton = {
        let button = PaddedButton()
        button.updateConfiguration(title: "Cancel", titleColor: viewModel.tintColor, backgroundColor: .clear, font: UIFont.systemFont(ofSize: 17.0, weight: .semibold), cornerRadius: 0.0)
        button.setContentHuggingPriority(.defaultHigh, for: .horizontal)
        button.setContentHuggingPriority(.required, for: .vertical)
        return button
    }()
    
    private lazy var applyButton: PaddedButton = {
        let button = PaddedButton()
        button.updateConfiguration(title: "Apply: 0 Filters", titleColor: .white, backgroundColor: viewModel.tintColor, font: UIFont.systemFont(ofSize: 17.0, weight: .semibold), cornerRadius: 36/2)
        button.setContentHuggingPriority(.defaultHigh, for: .horizontal)
        button.setContentHuggingPriority(.required, for: .vertical)
        return button
    }()
    
    private lazy var footerView = UIView()
    private let footerBorder = UIView()
    
    private lazy var buttonsStack: UIStackView = {
        let stack = UIStackView(arrangedSubviews: [
            cancelButton, applyButton
        ])
        stack.distribution = .fillProportionally
        stack.spacing = 30.0
        return stack
    }()
    
    private var cancellables = Set<AnyCancellable>()
    
    private weak var applyButtonDelegate: ApplyButtonUpdater?
    
    private let viewModel: FiltersViewModel
    
    init(viewModel: FiltersViewModel) {
        self.viewModel = viewModel
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        layoutViews()
        styleViews()
        bindViewModel()
        setupNavigationController()
        applyButton.addTarget(self, action: #selector(applyButtonTapped), for: .touchUpInside)
        cancelButton.addTarget(self, action: #selector(cancelButtonTapped), for: .touchUpInside)
    }
    
    private func layoutViews() {
        view.addSubview(optionHeaderView)
        optionHeaderView.translatesAutoresizingMaskIntoConstraints = false
        
        optionHeaderView.addSubview(optionHeaderLabel)
        optionHeaderLabel.translatesAutoresizingMaskIntoConstraints = false
        
        let headerBorderView = makeBorderView()
        optionHeaderLabel.addSubview(headerBorderView)
        headerBorderView.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(operatorStack)
        operatorStack.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(footerView)
        footerView.translatesAutoresizingMaskIntoConstraints = false
                
        let orBorderView = makeBorderView()
        andButtonView.addSubview(orBorderView)
        orBorderView.translatesAutoresizingMaskIntoConstraints = false
        
        let andBorderView = makeBorderView()
        andButtonView.addSubview(andBorderView)
        andBorderView.translatesAutoresizingMaskIntoConstraints = false
        
        buttonsStack.translatesAutoresizingMaskIntoConstraints = false
        footerView.addSubview(buttonsStack)
                
        footerView.addSubview(footerBorder)
        footerBorder.translatesAutoresizingMaskIntoConstraints = false
                
        NSLayoutConstraint.activate([
            
            optionHeaderLabel.topAnchor.constraint(equalTo: optionHeaderView.topAnchor),
            optionHeaderLabel.bottomAnchor.constraint(equalTo: optionHeaderView.bottomAnchor),
            optionHeaderLabel.leadingAnchor.constraint(equalTo: optionHeaderView.leadingAnchor, constant: 16.0),
            optionHeaderLabel.trailingAnchor.constraint(equalTo: optionHeaderView.trailingAnchor),
            
            optionHeaderView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            optionHeaderView.heightAnchor.constraint(equalToConstant: headerHeight),
            optionHeaderView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            optionHeaderView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            
            headerBorderView.bottomAnchor.constraint(equalTo: optionHeaderLabel.bottomAnchor),
            headerBorderView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            headerBorderView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            headerBorderView.heightAnchor.constraint(equalToConstant: 0.5),
            
            operatorStack.topAnchor.constraint(equalTo: optionHeaderLabel.bottomAnchor),
            operatorStack.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            operatorStack.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            
            orBorderView.bottomAnchor.constraint(equalTo: orButtonView.bottomAnchor),
            orBorderView.heightAnchor.constraint(equalToConstant: 0.5),
            orBorderView.leadingAnchor.constraint(equalTo: orButtonView.leadingAnchor, constant: 16.0),
            orBorderView.trailingAnchor.constraint(equalTo: orButtonView.trailingAnchor, constant: -16.0),
            
            andBorderView.bottomAnchor.constraint(equalTo: andButtonView.bottomAnchor),
            andBorderView.heightAnchor.constraint(equalToConstant: 0.5),
            andBorderView.leadingAnchor.constraint(equalTo: andButtonView.leadingAnchor),
            andBorderView.trailingAnchor.constraint(equalTo: andButtonView.trailingAnchor),            
            
            footerView.heightAnchor.constraint(equalToConstant: footerHeight),
            footerView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            footerView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            footerView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: 7.0),
            
            buttonsStack.topAnchor.constraint(greaterThanOrEqualTo: footerView.topAnchor),
            buttonsStack.bottomAnchor.constraint(lessThanOrEqualTo: footerView.bottomAnchor),
            buttonsStack.centerXAnchor.constraint(equalTo: footerView.centerXAnchor),
            buttonsStack.centerYAnchor.constraint(equalTo: footerView.centerYAnchor),
            
            footerBorder.heightAnchor.constraint(equalToConstant: 0.5),
            footerBorder.leadingAnchor.constraint(equalTo: footerView.leadingAnchor),
            footerBorder.trailingAnchor.constraint(equalTo: footerView.trailingAnchor),
            footerBorder.topAnchor.constraint(equalTo: footerView.topAnchor)
        ])
        
        buttonsStack.setContentHuggingPriority(.required, for: .horizontal)
        applyButton.setContentHuggingPriority(.required, for: .horizontal)
        applyButton.setContentHuggingPriority(.required, for: .vertical)
        
    }
    
    private func styleViews() {
        view.backgroundColor = .white
        footerBorder.backgroundColor = .lightGray.withAlphaComponent(0.5)
        
        optionHeaderLabel.font = UIFont.systemFont(ofSize: 20.0, weight: .semibold)
        optionHeaderLabel.text = "Filter Results"
        optionHeaderView.backgroundColor = viewModel.sectionTitleBackgroundColor
        
        orButtonView.label.text = "Match Any Selected Below"
        orButtonView.backgroundColor = .white
        orButtonView.tintColor = viewModel.tintColor
        
        andButtonView.label.text = "Match All Selected Below"
        andButtonView.backgroundColor = .white
        andButtonView.tintColor = viewModel.tintColor
        
        view.backgroundColor = viewModel.sectionTitleBackgroundColor
    }
    
    private func bindViewModel() {
        orButtonView.onTap = { [weak self] in
            self?.viewModel.operatorSelected(filterOperator: .or)
        }
        
        andButtonView.onTap = { [weak self] in
            self?.viewModel.operatorSelected(filterOperator: .and)
        }
        
        viewModel
            .$filterOperator
            .receive(on: DispatchQueue.main)
            .sink { [weak self] filterOperator in
                self?.orButtonView.isSelected = filterOperator == .or
                self?.andButtonView.isSelected = filterOperator == .and
            }
            .store(in: &cancellables)
    }
    
    private func setupNavigationController() {
        // Initialize your root view controller for the navigation stack
        let rootViewController = FiltersTableViewController(filtersViewModel: viewModel)
        rootViewController.applyButtonDelegate = self
        mainNavigationController = UINavigationController(rootViewController: rootViewController)
        let appearance = UINavigationBarAppearance()
        appearance.configureWithOpaqueBackground()
        appearance.titleTextAttributes = [.foregroundColor: UIColor.black]
        appearance.backgroundColor = viewModel.sectionTitleBackgroundColor
        mainNavigationController.navigationBar.standardAppearance = appearance
        mainNavigationController.navigationBar.scrollEdgeAppearance = appearance
        
        // Add the navigation controller as a child
        addChild(mainNavigationController)
        view.addSubview(mainNavigationController.view)
        mainNavigationController.didMove(toParent: self)
        mainNavigationController.navigationBar.setBottomBorderColor(color: .lightGray, height: 0.5)
        
        // Set up navigation controller view constraints
        mainNavigationController.view.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            mainNavigationController.view.topAnchor.constraint(equalTo: operatorStack.bottomAnchor),
            mainNavigationController.view.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            mainNavigationController.view.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            mainNavigationController.view.bottomAnchor.constraint(equalTo: footerView.topAnchor)
        ])
    }
    
    @objc private func applyButtonTapped() {
        viewModel.applyButtonTapped()
        self.dismiss(animated: true)
    }
    
    @objc private func cancelButtonTapped() {
        self.dismiss(animated: true)
    }
}

extension FiltersContainerViewController: ApplyButtonUpdater {
    func updateButtonText() {
        let count = viewModel.data.calculateTotalSelected()
        let filterText: String
        if count == 1 {
            filterText = "Filter"
        } else {
            filterText = "Filters"
        }
        
        applyButton.updateTitle(title: "Apply: \(count) \(filterText)")
        footerView.setNeedsLayout()
        footerView.layoutIfNeeded()
    }
}
