//
//  FilterProtocols.swift
//  HopSpin
//
//  Created by Antonio Carella on 05.09.2023.
//

import Foundation

protocol FilteringParamsProtocol {
    var filteringParams: [FilterParam] { get }
}

// Wrap possibiliities to work with server filtering logic
// If we have all possible filter parameters, we should use a GET call
// If we have none of the filter parameters, we should not make a call, but instead wipe out existing data
// If we have some, call the filters as usual.
enum FilterParamOption: Equatable {
    case some(filters: [FilterParam])
    case all
    case none
    case initial
    
    var filters: [FilterParam] {
        switch self {
        case .some(let filters): return filters
        default: return []
        }
    }
}

struct FilterParam: Hashable {
    let key: String
    let value: FilterValue
}

struct FilterValue: FilterValueProtocol {
    var title: String
}

extension FilterValue: Equatable {
    
    static func == (lhs: Self, rhs: Self) -> Bool {
        lhs.title == rhs.title
    }
    
}

protocol FilterValueProtocol: Hashable {
    var title: String { get }
}
