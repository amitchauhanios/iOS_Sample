//
//  FilterTypes.swift
//  HopSpin
//
//  Created by Antonio Carella on 29.08.2023.
//

import Foundation

enum IBUFilterType: String {
    case from0to15 = "0 – 14.9"
    case from15to30 = "15 – 29.9"
    case from30to45 = "30 – 44.9"
    case from45to60 = "45 – 59.9"
    case from60to74 = "60 – 74.9"
    case from75to90 = "75 – 89.9"
    case from90 = "90 +"

    init?(_ value: Double?) {
        guard let value else { return nil }
        switch value {
        case 0...14.9:
            self = .from0to15
        case 15...29.9:
            self = .from15to30
        case 30...44.9:
            self = .from30to45
        case 45...59.9:
            self = .from45to60
        case 60...74.9:
            self = .from60to74
        case 75...89.9:
            self = .from75to90
        case 90...:
            self = .from90
        default:
            return nil
        }
    }

    var title: String {
        self.rawValue
    }
}
