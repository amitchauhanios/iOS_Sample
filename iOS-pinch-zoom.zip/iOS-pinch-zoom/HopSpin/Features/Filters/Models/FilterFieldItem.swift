//
//  FilterFieldItem.swift
//  HopSpin
//
//  Created by Antonio Carella on 29.08.2023.
//

import Foundation
import UIKit

struct FiltersSection: Hashable {
    var title: String
    var children: [FilterRow] = []
}

struct FilterRow: Hashable {
    let title: String
    let tintColor: UIColor

    init(title: String, tintColor: UIColor) {
        self.title = title
        self.tintColor = tintColor
    }
}

enum FilterFieldItem: Hashable {
    case section(FiltersSection)
    case row(FilterRow)
    
    var isSectionRow: Bool {
        if case .row = self {
            return true
        }
        return false
    }
}
