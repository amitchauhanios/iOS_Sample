//
//  FiltersDataNew.swift
//  HopSpin
//
//  Created by Antonio Carella on 12/24/23.
//

import UIKit
import OrderedCollections


protocol SelectionCountable {
    var selectionState: FilterSelectionState { get }
    func calculateSelectedCount() -> Int
}

extension SelectionCountable {
    func calculateSelectedCount<T: SelectionCountable>(from items: [T]) -> Int {
        items.reduce(0, { count, item in
            item.selectionState.isSelected ? count + 1 : count
        })
    }

    func calculateAllState<T: SelectionCountable>(from items: [T], totalCount: Int) -> FilterSelectionState {
        let selectedCount = calculateSelectedCount(from: items)
        switch selectedCount {
        case 0: return .unselected
        case totalCount: return .selected
        default: return .mixed
        }
    }
}

struct FilterOption {
    let title: String
    var selectionState: FilterSelectionState
}

extension FilterOption: SelectionCountable {
    func calculateSelectedCount() -> Int {
        return selectionState.isSelected ? 1 : 0
    }
    
    var allState: FilterSelectionState {
        return selectionState
    }
}

struct FilterCategory: SelectionCountable {
    let title: String
    var options: [FilterOption]
    
    var selectionState: FilterSelectionState {
        calculateAllState(from: options, totalCount: options.count)
    }
    
    func calculateSelectedCount() -> Int {
        calculateSelectedCount(from: options)
    }
    
    mutating func toggleSelectionState(for title: String) {
        if let optionIndex = options.firstIndex(where: { $0.title == title }) {
            var option = options[optionIndex]
            option.selectionState = option.selectionState.toggle()
            options[optionIndex] = option
        }
    }
    
    mutating func togleSelectionStateForAll() {
        let newState = selectionState.toggle()
        
        options = options.map {
            var mutable = $0
            mutable.selectionState = newState
            return mutable
        }
    }
}

extension FilterCategory {
    static func all() -> FilterCategory {
        FilterCategory(title: Self.allTitle, options: [])
    }
    
    static var allTitle: String = "(All)"
}

extension FilterCategory {
    
    /// Toggle the selection state of all child options
    mutating func toggleSelectionState() {
        options = options.map { option in
            var updatedOption = option
            updatedOption.selectionState = option.selectionState.toggle()
            return updatedOption
        }
    }
    
    /// Update the selection state of all child options to selectionState
    mutating func update(selectionState: FilterSelectionState) {
        options = options.map { option in
            var updatedOption = option
            updatedOption.selectionState = selectionState
            return updatedOption
        }
    }
}


struct FilterData: SelectionCountable {
    var categories: [FilterCategory]
    
    var selectionState: FilterSelectionState {
        let allCategorySelectionStates = categories.map { $0.selectionState }
        if allCategorySelectionStates.allSatisfy({ $0 == .selected }) { return .selected }
        if allCategorySelectionStates.allSatisfy({ $0 == .unselected }) { return .unselected }
        return .mixed
    }
    
    func calculateSelectedCount() -> Int {
        calculateSelectedCount(from: categories)
    }
    
    func calculateTotalSelected() -> Int {
        categories.reduce(0) { count, category in
            let categoryCount = category.calculateSelectedCount()
            let total = count + categoryCount            
            return total
        }
    }
    
    mutating func toggleSelectionState(for title: String) {
        if let categoryIndex = categories.firstIndex(where: { $0.title == title }) {
            var category = categories[categoryIndex]
            let newState = category.selectionState.toggle()
            category.update(selectionState: newState)            
            categories[categoryIndex] = category
        }
    }
    
    mutating func togleSelectionStateForAll() {
        let newState = selectionState.toggle()
        
        categories = categories.map {
            var mutable = $0
            mutable.update(selectionState: newState)
            return mutable
        }
    }
}

extension FilterData {
    func selectedFilters() -> [FilterParam] {        
        categories.reduce(into: [FilterParam](), { array, category in
            let newParams = category.options
                .filter { $0.selectionState == .selected }
                .map { selectedOption in
                    FilterParam(key: category.title, value: FilterValue(title: selectedOption.title))
                }
            
            return array.append(contentsOf: newParams)
        })
    }
}

enum FilterSelectionState {
    case selected
    case unselected
    case mixed
    
    var isSelected: Bool {
        switch self {
        case .selected:
            true
        case .unselected, .mixed:
            false
        }
    }
}

extension FilterSelectionState {
    func toggle() -> FilterSelectionState {
        switch self {
        case .selected: .unselected
        case .unselected, .mixed: .selected
        }
    }
}
