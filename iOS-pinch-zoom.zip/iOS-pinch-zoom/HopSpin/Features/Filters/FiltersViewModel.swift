//
//  FiltersViewModelNew.swift
//  HopSpin
//
//  Created by Antonio Carella on 12/24/23.
//

import Combine
import OrderedCollections
import UIKit

enum FilterOperator: String {
    case or
    case and
}

class FiltersViewModel {
    
    @Published var data: FilterData
    @Published var filterOperator: FilterOperator
    let sectionTitle: String
    let sectionTitleBackgroundColor: UIColor
    
    let tintColor: UIColor
    
    private var cancellables = Set<AnyCancellable>()
    private var applyFiltersHandler: ((FiltersAndOperator) -> Void)?
    // Store these to compare against the filters the user selects
    private let filteringParams: OrderedDictionary<String, [FilterParam]>
    
    init(
        tintColor: UIColor,
        filteringParams: OrderedDictionary<String, [FilterParam]>,
        selectedFilters: FiltersAndOperator,
        applyFiltersHandler: ((FiltersAndOperator) -> Void)?,
        sectionTitleItem: FilterSectionItem
    ) {
        
        filteringParams.keys.forEach {
            print("*** key", $0)
        }
        
        self.tintColor = tintColor
        self.filteringParams = filteringParams
        self.filterOperator = selectedFilters.filterOperator
        // Loop throuth the filtering parameters ordered dictionary and create the filterData object
        // for all the filtering sections
        let categories = filteringParams.map { key, values in
            
            let options: [FilterOption]
            
            options = values.map { filterParam in
                let state: FilterSelectionState = selectedFilters.filterParams.contains(where: {
                    $0.key == filterParam.key &&
                    $0.value.title == filterParam.value.title
                 }) ? FilterSelectionState.selected : FilterSelectionState.unselected
                
                return FilterOption(title: filterParam.value.title, selectionState: state)
            }
            
            return FilterCategory(title: key, options: options)
        }
        
        self.applyFiltersHandler = applyFiltersHandler
        
        data = FilterData(categories: categories)
        
        self.sectionTitle = sectionTitleItem.sectionTitle
        self.sectionTitleBackgroundColor = sectionTitleItem.color
    }
    
    func filterSelected(title: String) {
        if title == FilterCategory.allTitle {
            data.togleSelectionStateForAll()
        } else {
            data.toggleSelectionState(for: title)
        }
    }
    
    func viewModelForCategory(at index: Int) -> FilterCategoryViewModel {
        let category = data.categories[index]
        
        let viewModel = FilterCategoryViewModel(
            data: category,
            tintColor: tintColor,
            sectionTitleBackgroundColor: sectionTitleBackgroundColor
        )
        
        // Subscribe to get updates when the category is mutated
        viewModel
            .$data
            .sink { [weak self] category in
                self?.data.categories[index] = category
            }
            .store(in: &cancellables)
        
        return viewModel
    }
    
    func operatorSelected(filterOperator: FilterOperator) {
        self.filterOperator = filterOperator
    }
    
    func applyButtonTapped() {
        let selected = data.selectedFilters()                        
        let filtersAndOperator = FiltersAndOperator(filterParams: selected, filterOperator: filterOperator)
        applyFiltersHandler?(filtersAndOperator)
    }
}

struct FiltersRowViewModel: Hashable {
    let text: String
    let selectionState: FilterSelectionState
    let selectedCount: Int
    let isFinalRow: Bool
}

struct FiltersAndOperator {
    let filterParams: [FilterParam]
    let filterOperator: FilterOperator
}

extension FiltersAndOperator {
    static let initial: FiltersAndOperator = .init(filterParams: [], filterOperator: .or)
}

enum FilterSectionItem {
    case beer(UIColor)
    case brewery(UIColor)
    case artist(UIColor)
    
    var sectionTitle: String {
        switch self {
        case .beer:
            "Filter Beers By"
        case .brewery:
            "Filter Breweries By"
        case .artist:
            "Filter Artists By"
        }
    }
    
    var color: UIColor {
        switch self {
        case .beer(let color):
            return color
        case .brewery(let color):
            return color
        case .artist(let color):
            return color
        }
    }
}
