//
//  ArtistDetailView.swift
//  HopSpin
//
//  Created by Antonio Carella on 12/10/23.
//

import SwiftUI
import ExpandableText
import Kingfisher

struct ArtistDetailView: View {
    @ObservedObject var viewModel: ArtistDetailViewModel
    @State private var tabBarOffset: CGFloat = 0  // Initial offset at zero
    
    var body: some View {
        ZStack {
            VStack(spacing: 0) {
                ArtistDetailScrollView(viewModel: viewModel, tabBarOffset: $tabBarOffset)
                ArtistDetailTabBar(viewModel: viewModel)
                    .offset(y: tabBarOffset)
                    .animation(.linear(duration: 0.1), value: tabBarOffset)
            }
            
            if viewModel.showLoadingIndicator {
                ZStack {
                    Color.white
                        .edgesIgnoringSafeArea(.all)
                    LoadingViewSUI(
                        shouldAnimate: viewModel.showLoadingIndicator,
                        strokeColor: viewModel.tintColor
                    )
                        .frame(width: 120, height: 120)
                        .offset(x: 0, y: 21)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
        }
    }
}

struct ArtistDetailScrollView: View {
    @ObservedObject var viewModel: ArtistDetailViewModel
    private static let hPadding = 40.0
    private static let sectionVPadding = 40.0
    @Binding var tabBarOffset: CGFloat
    @State var lastOffset: CGFloat = 0.0
    
    var body: some View {
        ScrollView(.vertical) {
            VStack(alignment: .leading) {
                if let url = viewModel.logoImage?.url {
                    KFImage(url)
                        .setProcessor(viewModel.processor)
                        .resizable()
                        .placeholder {
                            Color
                                .clear
                                .frame(height: 150)
                        }
                        .retry(maxCount: 3, interval: .seconds(1))
                        .onSuccess { r in
                            viewModel.imageReadySubject.send(true)
                        }
                        .onFailure { e in
                            viewModel.imageReadySubject.send(true)
                        }
                        .scaledToFit()
                        .frame(maxHeight: 150.0)
                        .padding([.top, .bottom], 20.0)
                } else {
                    Color.clear.frame(height: Self.hPadding)
                }
                if let bioText = viewModel.bioText {
                    ExpandableText(bioText)
                        .font(Font.system(size: 17.0))
                        .foregroundColor(.black)
                        .lineLimit(9)
                        .moreButtonText("more")
                        .moreButtonFont(Font.system(size: 17.0))
                        .moreButtonColor(Color(viewModel.tintColor))
                        .expandAnimation(.easeInOut(duration: 0.33))
                        .trimMultipleNewlinesWhenTruncated(false)
                        .padding([.bottom], 20.0)
                }
                if let webPageURL = URL(string: viewModel.webpageLink ?? "") {
                    Link(
                        viewModel.webpageDispay ?? "",
                        destination: webPageURL
                    )
                    .foregroundColor(Color(viewModel.tintColor))
                }
                
                if let email = URL(string: viewModel.emailLink ?? "") {
                    Link(
                        viewModel.emailDispay ?? "",
                        destination: email
                    )
                    .foregroundColor(Color(viewModel.tintColor))
                }
                
                if let phoneNumber = viewModel.phoneNumberLink,
                   let url = URL(string:phoneNumber) {
                    Link(
                        viewModel.phoneNumberDisplay?.phoneDisplayFormat ?? "",
                        destination: url
                    )
                    .foregroundColor(Color(viewModel.tintColor))
                }
                
                if !viewModel.socials.isEmpty {
                    SimpleGridView(
                        items: viewModel.socials,
                        totalHorizontalInset: viewModel.defaultContentMargins * 2,
                        itemView: { viewModel in
                            KFImage(viewModel.imageURL)
                                .setProcessor(SVGImgProcessor())
                                .resizable()
                                .frame(width: 38, height: 38)
                                .onTapGesture {
                                    UIApplication.shared.open(viewModel.linkURL)
                                }
                        }
                    )
                    .padding([.top, .bottom], Self.sectionVPadding)
                    .frame(maxWidth: .infinity, alignment: .center)
                }
                LazyVGrid(columns: [GridItem(.flexible(), alignment: .leading)],
                          spacing: 8
                ) {
                    ForEach(
                        viewModel.topLevelDataPairs, id: \.self) { viewModel in
                            if !viewModel.isEmpty {
                                HopSpinDataPair(viewModel: viewModel)
                            }
                        }
                }
                .padding([.bottom], Self.sectionVPadding)
                
                Group {
                    ForEach(
                        viewModel.rolesDataPairViewModel, id: \.self) { viewModel in
                            if !viewModel.isEmpty {
                                HopSpinDataPair(viewModel: viewModel)
                                    .padding([.bottom], 10.0)
                            }
                        }
                }
            }
            .background(
                GeometryReader { proxy in
                    Color.clear.preference(
                        key: ScrollOffsetPreferenceKey.self,
                        value: .init(
                            offset: proxy.frame(in: .global).minY,
                            height: proxy.frame(in: .global).height
                        )
                    )
                }
            )
            .padding([.bottom], Self.sectionVPadding)
        }
        .onPreferenceChange(ScrollOffsetPreferenceKey.self) { offsetPreference in
            // Control the tab bar's offset based on scroll direction
            let offset = offsetPreference.offset
            let height = offsetPreference.height                        
            
            if height < UIScreen.main.bounds.height * 0.8 {
                tabBarOffset = 0
                lastOffset = offset
                return
            }
            
            // if were at the top
            if offset > 80 {
                // alway show
                tabBarOffset = 0
                lastOffset = offset
                return
            }
            
            // if we're not at the top
            if offset < 25 {
                // and we're moving down, hide the bar
                if lastOffset > offset {
                    tabBarOffset = 110
                } else { // or show it
                    tabBarOffset = 0
                }
            }
            
            if (offset * -1) + UIScreen.main.bounds.height > height {
                tabBarOffset = 110
                lastOffset = offset
                return
            }
            
            lastOffset = offset
        }
        .defaultContentMargins(margins: viewModel.defaultContentMargins)
    }
}

struct ArtistDetailTabBar: View {
    @ObservedObject var viewModel: ArtistDetailViewModel
    
    var body: some View {
        HStack {
            Spacer() // Spacer before the first button

            Button {
                viewModel.presentLocationDetail()
            } label: {
                VStack(spacing: 8.0){
                    Image(systemName: "map")
                        .font(Font.system(size: 18, weight: .medium))
                    Text("Locations")
                        .font(Font.system(size: 10, weight: .medium))
                }
                .foregroundColor(.white)
            }
            .padding(.top, 8)

            Spacer() // Spacer between the buttons

            Button {
                viewModel.presentBeers()
            } label: {
                VStack(spacing: 8.0){
                    Image(systemName: "homepod")
                        .renderingMode(.original)
                        .font(Font.system(size: 18, weight: .medium))
                    Text("Beers")
                        .font(Font.system(size: 10, weight: .medium))
                }
                .foregroundColor(.white)
            }
            .padding(.top, 8)

            Spacer() // Spacer after the second button
        }
        .background(Color(viewModel.tintColor))
        .alert(item: $viewModel.errorMessage) { message in
            Alert(
                title: Text(message.title),
                message: Text(message.subtitle),
                dismissButton: .cancel()
            )
        }
    }
}
