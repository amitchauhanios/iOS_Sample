//
//  ArtistDetailViewModel.swift
//  HopSpin
//
//  Created by Antonio Carella on 12/10/23.
//

import Combine
import SwiftUI
import Kingfisher

@MainActor
class ArtistDetailViewModel: ObservableObject {
            
    let imageReadySubject = PassthroughSubject<Bool, Never>()
    let dataReadySubject = PassthroughSubject<Bool, Never>()
    
    private var artistDetail: ArtistDetail!
    
    var delegate: DetailsPresenter!
    
    // Data
    @Published var name: String = ""
    @Published var logoImage: AsyncImageViewModel? = nil
    var processor: ImageProcessor = DefaultImageProcessor.default
    @Published var bioText: String? = nil
    @Published var webpageDispay: String?
    @Published var webpageLink: String?
    @Published var emailDispay: String?
    @Published var emailLink: String?
    @Published var phoneNumberDisplay: String?
    @Published var phoneNumberLink: String?
    @Published var socials: [SocialMediaViewModel] = []
    @Published var statusBarStyle: UIStatusBarStyle = .lightContent
    @Published var tintColor: UIColor
    
    // Top level data pairs
    @Published var topLevelDataPairs: [HopSpinDataPairViewModel] = []    
    @Published var rolesDataPairViewModel: [HopSpinDataPairViewModel] = []
    
    // Error handling, etc
    @Published var errorMessage: ErrorMessage? = nil
    @Published var showLoadingIndicator = true
    
    var locationsViewModel: LocationViewModel? = nil
    let defaultContentMargins: CGFloat
    
    init(
        artistFetch: @escaping (Int) async throws -> ArtistDetail,
        artist: Artist
    ) {
        self.tintColor = StyleKit.parseUIColor(
            string: artist.iosHeaderTextColor.coallesceToEmpty,
            fallback: Colors.hopspinGreen
        )
        
        self.defaultContentMargins = shouldAdjustSafeAreasForMaxScreens() ? 20.0 : 16.0
        
        Task {
            do {
                async let detail = try artistFetch(artist.id)
                self.artistDetail = try await detail
                await update(with: try detail)
                dataReadySubject.send(true)
            } catch {
                let errorMessage = ErrorMessage(title: "Error", subtitle: error.localizedDescription)
                self.errorMessage = errorMessage
                dataReadySubject.send(true)
            }
        }
        
        Publishers
            .CombineLatest(imageReadySubject, dataReadySubject)
            .filter {
                return $0 && $1
            }
            .map { _ in
                return false
            }
            .assign(to: &$showLoadingIndicator)
    }
    
    private func update(with detail: ArtistDetail) {
        
        self.name = detail.name
        
        if let urlString = detail.branding.logo2d {
            self.logoImage = AsyncImageViewModel(
                url: Endpoint.image(path: urlString).url
            )
            self.processor = self.logoImage?.url?.pathExtension == "svg" ? SVGImgProcessor() : DefaultImageProcessor.default
        } else {
            self.logoImage = nil
            imageReadySubject.send(true)
        }
        
        self.bioText = detail.about
        self.webpageDispay = detail.website?.webpageDisplayFormat
        self.webpageLink = detail.website
        self.emailDispay = detail.email
        self.emailLink = detail.email?.emailFormat
        self.phoneNumberDisplay = detail.locations.first?.phoneNumber
        self.phoneNumberLink = detail.locations.first?.phoneNumber?.phoneLinkFormat
        self.socials = detail.socialMedia
            .compactMap {
                if let linkURL = URL(string: $0.profileAddress),
                   let imageURL = Endpoint.image(path: $0.channelIcon).url {
                    return SocialMediaViewModel(
                        id: UUID().uuidString,
                        name: $0.channel,
                        linkURL: linkURL,
                        imageURL: imageURL
                    )
                }
                return nil
            }
        let cityState = HopSpinDataPairViewModel(
            title: "Home Location",
            value: "\(detail.homeCity), \(detail.homeState)".dashIfEmpty
        )
        
        let yearFoundedValue = {
            if let yearFounded = detail.yearFounded {
               return "\(yearFounded)"
            } else {
                return "".dashIfEmpty
            }
        }
        
        let yearFounded = HopSpinDataPairViewModel(
            title: "Founded",
            value: yearFoundedValue()
        )
        
        let classification = HopSpinDataPairViewModel(
            title: "Classification",
            value: "\(detail.classification)".dashIfEmpty
        )
        
        var allRoleDataPairs = TeamMemberFormatter.formatDataPairs(teamMembers: detail.team)
        
        var founder: HopSpinDataPairViewModel = .empty
        let founderDescription = TeamMemberFormatter.parseFounderDescription(from: detail.team)
        if let index = allRoleDataPairs.firstIndex(where: { $0.title == founderDescription }) {
            founder = allRoleDataPairs.remove(at: index)
        }
        
        self.rolesDataPairViewModel = allRoleDataPairs
        
        self.topLevelDataPairs = [
            cityState,            
            classification,
            yearFounded,
            founder
        ]
        
        let refresh: (Int) async throws -> [LocationDisplayable] = { id in
            let detail = try await ApiClient.live.artist(id)
            return detail.locations.map {
                ArtistLocationDisplayable(location: $0)
            }
        }
        
        self.locationsViewModel = LocationViewModel(
            locations: detail.locations.map { ArtistLocationDisplayable(location: $0) },
            name: detail.name,
            tintColor: self.tintColor,
            refresh: refresh,
            id: artistDetail.ID,
            contentMargins: shouldAdjustSafeAreasForMaxScreens() ? 20.0 : 16.0
        )
    }
    
    func presentLocationDetail() {
        guard let viewModel = self.locationsViewModel else {
            self.errorMessage = .unknown
            return
        }
        
        delegate.presentLocations(viewModel: viewModel)
    }
    
    func presentBeers() {
        delegate.presentBeers(artistDetail: artistDetail)
    }
    
    func presentArtists() {
        delegate.presentArtists(name: artistDetail.name, tint: self.tintColor)
    }
}

protocol LocationDisplayable {
    var isHome: Bool { get }
    var type: [String] { get }
    var locationID: Int { get }
    var name: String { get }
    var address1: String { get }
    var address2: String? { get }
    var address3: String? { get }
    var zipCode: String { get }
    var city: String { get }
    var state: String { get }
    var country: String { get }
    var phoneCallingCode: Int? { get }
    var phoneNumber: String? { get }
    var latitude: Double? { get }
    var longitude: Double? { get }
    var placeID: String? { get }
    var openingHours: [String: OpeningHour]? { get }
}

struct ArtistLocationDisplayable: LocationDisplayable {
    var isHome: Bool
    var type: [String]
    var locationID: Int
    var name: String
    var address1: String
    var address2: String?
    var address3: String?
    var zipCode: String
    var city: String
    var state: String
    var country: String
    var phoneCallingCode: Int?
    var phoneNumber: String?
    var latitude: Double?
    var longitude: Double?
    var placeID: String?
    var openingHours: [String : OpeningHour]?
    
    init(location: ArtistDetail.Location) {
        self.isHome = true
        self.type = []
        self.locationID = location.locationID
        self.name = location.name.coallesceToEmpty
        self.address1 = location.address1.coallesceToEmpty
        self.address2 = location.address2
        self.address3 = location.address3
        self.zipCode = location.zipCode.coallesceToEmpty
        self.city = location.city
        self.state = location.state
        self.country = location.country.coallesceToEmpty
        self.phoneCallingCode = location.phoneCallingCode
        self.phoneNumber = location.phoneNumber
        self.latitude = location.latitude
        self.longitude = location.longitude
        self.placeID = location.place
        self.openingHours = [:]
    }
}

