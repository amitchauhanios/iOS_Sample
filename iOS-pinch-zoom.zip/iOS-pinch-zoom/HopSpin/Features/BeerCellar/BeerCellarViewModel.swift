//
//  BeerCellarViewModel.swift
//  HopSpin
//
//  Created by Antonio Carella on 9/3/23.
//

import Combine
import CombineExt
import Foundation
import OrderedCollections
import UIKit

enum ViewSegementState {
    case beer, brewery, artist
}

enum BeerViewSegmentState {
    case gallery, list
}

class BeerCellarViewModel {
    
    var delegate: SearchResultSelectedHandler? {
        willSet {
            allListViewModel.delegate = newValue
            haveListViewModel.delegate = newValue
            hadListViewModel.delegate = newValue
            wantListViewModel.delegate = newValue
            
            allGalleryViewModel.delegate = newValue
            haveGalleryViewModel.delegate = newValue
            hadGalleryViewModel.delegate = newValue
            wantGalleryViewModel.delegate = newValue
        }
    }
    
    private let countDisplayDelay: Double = 0.125
    
    private var subscriptions = Set<AnyCancellable>()
    
    @Published private(set) var errorMessage: ErrorMessage?
    
    private let shouldUpdate = PassthroughSubject<Void, Never>()
    
    private(set) var allListViewModel: BeerCellarListViewModel!
    private(set) var haveListViewModel: BeerCellarListViewModel!
    private(set) var hadListViewModel: BeerCellarListViewModel!
    private(set) var wantListViewModel: BeerCellarListViewModel!
    
    private(set) var allGalleryViewModel: BeerCellarGalleryViewModel!
    private(set) var haveGalleryViewModel: BeerCellarGalleryViewModel!
    private(set) var hadGalleryViewModel: BeerCellarGalleryViewModel!
    private(set) var wantGalleryViewModel: BeerCellarGalleryViewModel!
    
    let searchControlBarOffset = CurrentValueSubject<CGFloat, Never>(100.0)
    
    let tintColor: UIColor
    let secondaryTintColor: UIColor
    let searchControlBarBackground: UIColor
    let name: String
    
    var resultsViewPublisher: AnyPublisher<BeerGalleryView, Never> {
        resultsViewSubject.eraseToAnyPublisher()
    }
    
    let beerViewSegementStateFilterSubject = PassthroughSubject<CellarSegmentState, Never>()
    let filtersSortButtonTapped = PassthroughSubject<Void, Never>()
    let showFilterSortMenu = PassthroughSubject<SearchControlBarMenuContent, Never>()
    let filtersTappedSubject = PassthroughSubject<Void, Never>()
    let resetTappedSubject = PassthroughSubject<Void, Never>()
    let filterSortBadge = PassthroughSubject<Int, Never>()
    let sortTappedSubject = PassthroughSubject<Void, Never>()
    let fetchResultsSubject = PassthroughSubject<Void, Never>()
    private var resultsViewSubject = CurrentValueSubject<BeerGalleryView, Never>(.allGallery)
    private let viewSegementStateFilterSubject = CurrentValueSubject<BeerViewSegmentState, Never>(.gallery)
    
    private let searchTermSubject = CurrentValueSubject<String, Never>("")
    
    // Pass these to ViewModels to observe filter changes
    // We have one per model type (ie, not per view) on purpose.
    // We want the beers filters to apply to both gallery and list views
    private let allFilters = CurrentValueSubject<FiltersAndOperator, Never>(.initial)
    private let wantFilters = CurrentValueSubject<FiltersAndOperator, Never>(.initial)
    private let haveFilters = CurrentValueSubject<FiltersAndOperator, Never>(.initial)
    private let hadFilters = CurrentValueSubject<FiltersAndOperator, Never>(.initial)
    
    private let allSorting = CurrentValueSubject<(OrderOption, BeerSortingOption), Never>((.ascending, .name))
    private let wantSorting = CurrentValueSubject<(OrderOption, BeerSortingOption), Never>((.ascending, .name))
    private let haveSorting = CurrentValueSubject<(OrderOption, BeerSortingOption), Never>((.ascending, .name))
    private let hadSorting = CurrentValueSubject<(OrderOption, BeerSortingOption), Never>((.ascending, .name))
    
    private let sharedNetworkProvider: BeerCellarNetWorkProviderProtocol
    private let imageRepository: ImageRepository
    
    init(
        sharedNetworkProvider: BeerCellarNetWorkProviderProtocol,
        name: String,
        imageRepository: ImageRepository,
        tintColor: UIColor,
        secondaryTintColor: UIColor,
        searchControlBarBackground: UIColor
    ) {
        self.sharedNetworkProvider = sharedNetworkProvider
        self.imageRepository = imageRepository
        self.tintColor = tintColor
        self.secondaryTintColor = secondaryTintColor
        self.searchControlBarBackground = searchControlBarBackground
        self.name = name
        
        self.allListViewModel = .init(
            dataFetcher: .init(
                networkProvider: sharedNetworkProvider,
                cellar: .all,
                persistence: .live),
            searchTerm: searchTermSubject,
            filters: allFilters,
            sorting: allSorting,
            imageRepository: imageRepository,
            breweryTintColor: tintColor,
            shouldUpdate: shouldUpdate,
            cellBackgroundColor: secondaryTintColor,
            beerViewSegementStateFilterSubject: viewSegementStateFilterSubject
        )
        
        self.haveListViewModel = .init(
            dataFetcher: .init(
                networkProvider: sharedNetworkProvider,
                cellar: .have,
                persistence: .live),
            searchTerm: searchTermSubject,
            filters: haveFilters,
            sorting: haveSorting,
            imageRepository: imageRepository,
            breweryTintColor: tintColor,
            shouldUpdate: shouldUpdate,
            cellBackgroundColor: secondaryTintColor,
            beerViewSegementStateFilterSubject: viewSegementStateFilterSubject
        )
        self.hadListViewModel = .init(
            dataFetcher: .init(
                networkProvider: sharedNetworkProvider,
                cellar: .had,
                persistence: .live),
            searchTerm: searchTermSubject,
            filters: hadFilters,
            sorting: hadSorting,
            imageRepository: imageRepository,
            breweryTintColor: tintColor,
            shouldUpdate: shouldUpdate,
            cellBackgroundColor: secondaryTintColor,
            beerViewSegementStateFilterSubject: viewSegementStateFilterSubject
        )
        self.wantListViewModel = .init(
            dataFetcher: .init(
                networkProvider: sharedNetworkProvider,
                cellar: .want,
                persistence: .live),
            searchTerm: searchTermSubject,
            filters: wantFilters,
            sorting: wantSorting,
            imageRepository: imageRepository,
            breweryTintColor: tintColor,
            shouldUpdate: shouldUpdate,
            cellBackgroundColor: secondaryTintColor,
            beerViewSegementStateFilterSubject: viewSegementStateFilterSubject
        )
        
        self.allGalleryViewModel = .init(
            dataFetcher: .init(
                networkProvider: sharedNetworkProvider,
                cellar: .all,
                persistence: .live),
            searchTerm: searchTermSubject,
            filters: allFilters,
            sorting: allSorting,
            imageRepository: imageRepository,
            shouldUpdate: shouldUpdate,
            tintColor: tintColor,
            cellSelectionColor: tintColor,
            beerViewSegementStateFilterSubject: viewSegementStateFilterSubject
        )
        
        self.haveGalleryViewModel = .init(
            dataFetcher: .init(
                networkProvider: sharedNetworkProvider,
                cellar: .have,
                persistence: .live),
            searchTerm: searchTermSubject,
            filters: haveFilters,
            sorting: haveSorting,
            imageRepository: imageRepository,
            shouldUpdate: shouldUpdate,
            tintColor: tintColor,
            cellSelectionColor: tintColor,
            beerViewSegementStateFilterSubject: viewSegementStateFilterSubject
        )
        
        self.hadGalleryViewModel = .init(
            dataFetcher: .init(
                networkProvider: sharedNetworkProvider,
                cellar: .had,
                persistence: .live),
            searchTerm: searchTermSubject,
            filters: hadFilters,
            sorting: hadSorting,
            imageRepository: imageRepository,
            shouldUpdate: shouldUpdate,
            tintColor: tintColor,
            cellSelectionColor: tintColor,
            beerViewSegementStateFilterSubject: viewSegementStateFilterSubject
        )
        
        self.wantGalleryViewModel = .init(
            dataFetcher: .init(
                networkProvider: sharedNetworkProvider,
                cellar: .want,
                persistence: .live),
            searchTerm: searchTermSubject,
            filters: wantFilters,
            sorting: wantSorting,
            imageRepository: imageRepository,
            shouldUpdate: shouldUpdate,
            tintColor: tintColor,
            cellSelectionColor: tintColor,
            beerViewSegementStateFilterSubject: viewSegementStateFilterSubject
        )
            
            bind()
    }
    
    func bind() {
        Publishers
            .CombineLatest(
                beerViewSegementStateFilterSubject, viewSegementStateFilterSubject
            )
            .map { viewSegment, beerViewSegment -> BeerGalleryView in
                switch (viewSegment, beerViewSegment) {
                case (.all, .list): return .allList
                case (.all, .gallery): return .allGallery
                case (.have, .list): return .haveList
                case (.have, .gallery): return .haveGallery
                case (.want, .list): return .wantList
                case (.want, .gallery): return .wantGallery
                case (.had, .list): return .hadList
                case (.had, .gallery): return .hadGallery
                }
            }
            .removeDuplicates()
            .sink { [weak self] in
                self?.resultsViewSubject.send($0)
            }
            .store(in: &subscriptions)
        
        filtersSortButtonTapped
            .withLatestFrom(beerViewSegementStateFilterSubject)
            .sink(receiveValue: { [weak self] state in
                guard let self else  { return }
                let sortTitle: String
                let sortValue: String
                let filterTitle: String
                let filterCount: Int
                switch state {
                case .all:
                    sortTitle = "Sort All By"
                    filterTitle = "Filter All By"
                    sortValue = self.allSorting.value.1.title
                    filterCount = self.allFilters.value.filterParams.count
                case .have:
                    sortTitle = "Sort Have By"
                    filterTitle = "Filter Have By"
                    sortValue = self.haveSorting.value.1.title
                    filterCount = self.haveFilters.value.filterParams.count
                case .had:
                    sortTitle = "Sort Had By"
                    filterTitle = "Filter Had By"
                    sortValue = self.hadSorting.value.1.title
                    filterCount = self.hadFilters.value.filterParams.count
                case .want:
                    sortTitle = "Sort Want By"
                    filterTitle = "Filter Want By"
                    sortValue = self.wantSorting.value.1.title
                    filterCount = self.wantFilters.value.filterParams.count
                }
                
                let noun = filterCount == 1 ? "Filter" : "Filters"
                let filterValue = "\(filterCount) \(noun)"
                
                showFilterSortMenu.send(
                    .init(
                        sortTitle: sortTitle,
                        sortValue: sortValue,
                        filterTitle: filterTitle,
                        filterValue: filterValue,
                        tintColor: tintColor,
                        tapColor: secondaryTintColor
                    )
                )
            })
            .store(in: &subscriptions)
        
        filtersTappedSubject
            .withLatestFrom(beerViewSegementStateFilterSubject)
            .sink(receiveValue: { [weak self] state in
                let flattenedFilteringParams: [FilterParam]
                let selectedFiltersSubject: CurrentValueSubject<FiltersAndOperator, Never>
                guard let self else { return }
                switch state {
                case .all:
                    flattenedFilteringParams = self.allListViewModel.filteringParamsSnapshot.value
                    selectedFiltersSubject = allFilters
                case .have:
                    flattenedFilteringParams = self.haveListViewModel.filteringParamsSnapshot.value
                    selectedFiltersSubject = haveFilters
                case .want:
                    flattenedFilteringParams = self.wantListViewModel.filteringParamsSnapshot.value
                    selectedFiltersSubject = wantFilters
                case .had:
                    flattenedFilteringParams = self.hadListViewModel.filteringParamsSnapshot.value
                    selectedFiltersSubject = hadFilters
                }
                
                let filterSnapshot = BeerFilteringParameterGrouper.group(filterParams: flattenedFilteringParams)
                self.delegate?.navigateToFilters(
                    filterSnapshot,
                    selected: selectedFiltersSubject.value,
                    tintColor: tintColor,
                    offset: searchControlBarOffset.value, 
                    sectionTitleItem: .beer(secondaryTintColor),
                    applyFiltersHandler: { [selectedFiltersSubject, filterSortBadge] filtersAndOperator      in 
                        selectedFiltersSubject.send(filtersAndOperator)
                        filterSortBadge.send(filtersAndOperator.filterParams.count)
                    })
            })
            .store(in: &subscriptions)
        
        sortTappedSubject
            .withLatestFrom(beerViewSegementStateFilterSubject)
            .sink(receiveValue: { [weak self] state in
                guard let self else { return }
                let sortingOptions = BeerSortingOption.sortedTitles
                let selectedSorting: (OrderOption, String)
                switch state {
                case .all:
                    let selectSortingOption = self.allSorting.value.1
                    selectedSorting = (self.allSorting.value.0, (selectSortingOption).title)
                case .want:
                    let selectSortingOption = self.wantSorting.value.1
                    selectedSorting = (self.wantSorting.value.0, (selectSortingOption).title)
                case .have:
                    let selectSortingOption = self.haveSorting.value.1
                    selectedSorting = (self.haveSorting.value.0, (selectSortingOption).title)
                case .had:
                    let selectSortingOption = self.hadSorting.value.1
                    selectedSorting = (self.hadSorting.value.0, (selectSortingOption).title)
                }
                
                delegate?.navigateToSorting(
                    sortingOptions,
                    selected: selectedSorting,
                    applySortingHandler: { [weak self] sortingOptions in
                        guard let self else { return }
                        let sortOption = BeerSortingOption(title: sortingOptions.1)
                        switch state {
                        case .all:
                            self.allSorting.send((sortingOptions.0, sortOption))
                        case .want:
                            self.wantSorting.send((sortingOptions.0, sortOption))
                        case .have:
                            self.haveSorting.send((sortingOptions.0, sortOption))
                        case .had:
                            self.hadSorting.send((sortingOptions.0, sortOption))
                        }
                    },
                    tintColor: tintColor,
                    offset: searchControlBarOffset.value, 
                    sectionTitleItem: .beer(secondaryTintColor)
                )})
            .store(in: &subscriptions)
        
        resetTappedSubject
            .withLatestFrom(beerViewSegementStateFilterSubject)
            .sink(receiveValue: { [weak self] state in
                guard let self else { return }
                switch state {
                case .all:
                    self.allFilters.send(.initial)
                    self.allSorting.send((.ascending, .name))
                    
                case .want:
                    self.wantFilters.send(.initial)
                    self.wantSorting.send((.ascending, .name))
                    
                case .have:
                    self.haveFilters.send(.initial)
                    self.haveSorting.send((.ascending, .name))
                    
                case .had:
                    self.hadFilters.send(.initial)
                    self.hadSorting.send((.ascending, .name))
                }
                
                filterSortBadge.send(0)
            })
            .store(in: &subscriptions)
        
        resultsViewSubject
            .map({ [weak self] view -> Int in
                guard let self else { return 0 }
                switch view {
                case .allList, .allGallery:
                    return allFilters.value.filterParams.count
                case .hadList, .hadGallery:
                    return hadFilters.value.filterParams.count
                case .haveList, .haveGallery:
                    return haveFilters.value.filterParams.count
                case .wantList, .wantGallery:
                    return wantFilters.value.filterParams.count
                }
            })
            .sink(receiveValue: { [weak self] count in
                self?.filterSortBadge.send(count)
            })
            .store(in: &subscriptions)
        
        shouldUpdate.sink { [weak self] _ in
            [
                self?.allListViewModel,
                self?.haveListViewModel,
                self?.hadListViewModel,
                self?.wantListViewModel
            ].forEach { viewModel in
                viewModel?.fetchResults()
            }
            
            [
                self?.allGalleryViewModel,
                self?.haveGalleryViewModel,
                self?.hadGalleryViewModel,
                self?.wantGalleryViewModel
            ].forEach { viewModel in
                viewModel?.fetchResults()
            }
        }
        .store(in: &subscriptions)
    }
    
    func filterOn(filterTerm: String) {
        self.searchTermSubject.send(filterTerm)
    }
    
    func gallerySegmentTapped() {
        viewSegementStateFilterSubject.send(.gallery)
    }
    
    func listSegmentTapped() {
        viewSegementStateFilterSubject.send(.list)
    }
}

enum BeerGalleryView {
    case allGallery
    case allList
    case haveGallery
    case haveList
    case wantGallery
    case wantList
    case hadGallery
    case hadList
}

enum CellarSegmentState {
    case all, have, want, had
}
