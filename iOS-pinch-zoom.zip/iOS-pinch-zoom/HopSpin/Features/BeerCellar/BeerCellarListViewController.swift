//
//  BeerCellarListViewController.swift
//  HopSpin
//
//  Created by Antonio Carella on 11/20/23.
//

import UIKit

class BeerCellarListViewController: ListViewController {
    
    override var bottomToastBottomConstaintConstant: CGFloat {
        24.0
    }
        
    init(viewModel: BeerCellarListViewModel) {
        super.init(
            viewModel: viewModel,
            hidesGallerOrListButton: false
        )
        
        addRefreshControl(color: viewModel.activityIndicatorColor)
        
        galleryOrListButton
            .valueChanged
            .receive(on: DispatchQueue.main)
            .sink { state in
                viewModel.beerViewSegementStateFilterSubject.send(state)
            }
            .store(in: &subscriptions)
        
        galleryOrListButton.style(view: .list)
        
        self.listDataSource = ListItemsDataSource(tableView: self.tableView) { tableView, indexPath, listItem in

            guard let cell = tableView.dequeueReusableCell(withIdentifier: Self.cellId, for: indexPath) as? SearchResultsTableViewCell else {
                assertionFailure("Error dequeueing SearchResultsTableViewCell.")
                return UITableViewCell()
            }
            
            let backgroundView = UIView()
            backgroundView.backgroundColor = viewModel.cellSelectionColor
            cell.selectedBackgroundView = backgroundView
            
            Task {
                cell.labelImageView.image = await viewModel.fetchImage(urlPath: listItem.labelImageURLPath)
            }
            
            if let attributedText = listItem.attributedTitleText {
                cell.titleLabel.attributedText = attributedText
            } else {
                cell.titleLabel.text = listItem.titleText
            }
            
            let symbolConfig = UIImage.SymbolConfiguration(pointSize: 15, weight: .semibold, scale: .large)
            let symbolImage = UIImage(systemName: "chevron.right",
                                      withConfiguration: symbolConfig)
            cell.disclosureButton.setImage(symbolImage?.withTintColor(viewModel.breweryTintColor , renderingMode: .alwaysOriginal), for: .normal)
            
            cell.subTitleLabel.text = listItem.subtitleText
            listItem.isFinalRow ? cell.hideSeparator() : cell.showStandardSeparator()
            
            return cell
        }
    }
    
    override func constrainTableView() {
        NSLayoutConstraint.activate([
            tableView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor),
            tableView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
    }
    
    override func constrainBottomStack() {
        
        NSLayoutConstraint.activate([
            bottomToast.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            bottomToast.bottomAnchor.constraint(
                equalTo: view.bottomAnchor,
                constant: -bottomToastBottomConstaintConstant
            ),
            bottomToast.heightAnchor.constraint(equalToConstant: 48)
            ]
        )
    }
    
    override var bottomToastVOffset: CGFloat {
        bottomToast.frame.size.height + bottomToastBottomConstaintConstant
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
