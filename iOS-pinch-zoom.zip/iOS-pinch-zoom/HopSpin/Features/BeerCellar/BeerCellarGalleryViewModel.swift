//
//  BeerCellarGalleryViewModel.swift
//  HopSpin
//
//  Created by Antonio Carella on 11/20/23.
//

import Combine
import Foundation
import UIKit

class BeerCellarGalleryViewModel: GenericGalleryViewModel<Beer, BeerGalleryDataProcessor, BeerCellarDataFetcher, BeerSortingOption>{
    
    private let shouldUpdate: PassthroughSubject<Void, Never>
    private let tintColor: UIColor
    let cellSelectionColor: UIColor
    let beerViewSegementStateFilterSubject: CurrentValueSubject<BeerViewSegmentState, Never>
    
    init(
        dataFetcher: BeerCellarDataFetcher,
        searchTerm: CurrentValueSubject<String, Never>,
        filters: CurrentValueSubject<FiltersAndOperator, Never>,
        sorting: CurrentValueSubject<(OrderOption, BeerSortingOption), Never>,
        imageRepository: ImageRepository,
        shouldUpdate: PassthroughSubject<Void, Never>,
        tintColor: UIColor,
        cellSelectionColor: UIColor,
        beerViewSegementStateFilterSubject: CurrentValueSubject<BeerViewSegmentState, Never>
    ) {
        self.shouldUpdate = shouldUpdate
        self.cellSelectionColor = cellSelectionColor
        self.beerViewSegementStateFilterSubject = beerViewSegementStateFilterSubject
        self.tintColor = tintColor
        super.init(
            dataFetcher: dataFetcher,
            searchTerm: searchTerm,
            filters: filters,
            sorting: sorting,
            imageRepository: imageRepository,
            activityIndicatorColor: tintColor
        )
    }
    
    override func itemSelected(with id: String) {
        if let beer = items.first(where: { UUIDHandler.compare(id: $0.id, salted: id) }) {
            delegate?.navigateToBeer(beer, shouldUpdate: shouldUpdate, tintColor: tintColor)
        } else {
            let error = ErrorMessage.unknown
            errorMessageSubject.send(error)
        }
    }
    
}
