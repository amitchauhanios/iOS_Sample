//
//  BeerCellarNetWorkProvider.swift
//  HopSpin
//
//  Created by Antonio Carella on 12/12/23.
//

import Foundation

// An object responsible for provideing beer data from the server
// to a beer cellar
protocol BeerCellarNetWorkProviderProtocol {
    
    func fetchItems(
        searchTerm: String,
        filters: FiltersAndOperator,
        sorting: (OrderOption, BeerSortingOption)
    ) async throws -> [Beer]
    
}

class BreweryBeerCellarNetworkProvider: BeerCellarNetWorkProviderProtocol {
    
    private var isFetching = false
    private var fetchTask: Task<[Beer], Error>? = nil
    private let apiClient: ApiClient
    private let breweryId: Int
    
    init(
        breweryId: Int,
        apiClient: ApiClient
    ) {
        self.breweryId = breweryId
        self.apiClient = apiClient
    }
    
    func fetchItems(
        searchTerm: String,
        filters: FiltersAndOperator,
        sorting: (OrderOption, BeerSortingOption)
    ) async throws -> [Beer] {
        
        defer {
            isFetching = false
        }
                
        if isFetching {
            // If a fetch is already in progress, await its result
            return try await fetchTask?.value ?? []
        }

        let sortOption = sorting.1
        isFetching = true
        fetchTask = Task {
            do {
                let search = BeerSearch(
                    name: searchTerm,
                    filters: filters,
                    sortOption: sortOption,
                    sortDirection: sorting.0.sortDirection
                )
                return try await apiClient.beersAtBrewerySearch(breweryId, search)
            } catch {
                throw error
            }
        }
        
        return try await fetchTask?.value ?? []
    }
    
}

class ArtistBeerCellarNetworkProvider: BeerCellarNetWorkProviderProtocol {
    
    private var isFetching = false
    private var fetchTask: Task<[Beer], Error>? = nil
    private let apiClient: ApiClient
    private let artistId: Int
    
    init(
        artistId: Int,
        apiClient: ApiClient
    ) {
        self.artistId = artistId
        self.apiClient = apiClient
    }
    
    func fetchItems(
        searchTerm: String,
        filters: FiltersAndOperator,
        sorting: (OrderOption, BeerSortingOption)
    ) async throws -> [Beer] {
        
        defer {
            isFetching = false
        }
                
        if isFetching {
            // If a fetch is already in progress, await its result
            return try await fetchTask?.value ?? []
        }

        let sortOption = sorting.1
        isFetching = true
        fetchTask = Task {
            do {
                let search = BeerSearch(
                    name: searchTerm,
                    filters: filters,
                    sortOption: sortOption,
                    sortDirection: sorting.0.sortDirection
                )
                return try await apiClient.beersAtArtistSearch(artistId, search)
            } catch {
                throw error
            }
        }
        
        return try await fetchTask?.value ?? []
    }
    
}
