//
//  BeerCellarListViewModel.swift
//  HopSpin
//
//  Created by Antonio Carella on 11/20/23.
//

import Combine
import UIKit

class BeerCellarListViewModel: GenericListViewModel<Beer, BeerCellarListDataHandler, BeerCellarDataFetcher, BeerSortingOption>{
    
    private let shouldUpdate: PassthroughSubject<Void, Never>
    
    private let imageRepository: ImageRepository
    
    let breweryTintColor: UIColor
    
    let beerViewSegementStateFilterSubject: CurrentValueSubject<BeerViewSegmentState, Never>
    
    init(
        dataFetcher: BeerCellarDataFetcher,
        searchTerm: CurrentValueSubject<String, Never>,
        filters: CurrentValueSubject<FiltersAndOperator, Never>,
        sorting: CurrentValueSubject<(OrderOption, BeerSortingOption), Never>,
        imageRepository: ImageRepository,
        breweryTintColor: UIColor,
        shouldUpdate: PassthroughSubject<Void, Never>,
        cellBackgroundColor: UIColor,
        beerViewSegementStateFilterSubject: CurrentValueSubject<BeerViewSegmentState, Never>
    ) {
        self.imageRepository = imageRepository
        self.breweryTintColor = breweryTintColor
        self.shouldUpdate = shouldUpdate
        self.beerViewSegementStateFilterSubject = beerViewSegementStateFilterSubject
        super.init(
            dataFetcher: dataFetcher,
            searchTerm: searchTerm,
            filters: filters,
            sorting: sorting,
            tintColor: cellBackgroundColor,
            cellSelectionColor: cellBackgroundColor, 
            activityIndicatorColor: breweryTintColor
        )
    }
    
    func fetchImage(urlPath: String?) async -> UIImage {
        do {
            if
                let urlPath,
                let image = try await imageRepository.image(path: urlPath)
            {
                return image
            }
            
            return UIImage(named: "avatar")!
            
        } catch {
            
            // TODO: report error
            return UIImage(named: "avatar")!
            
        }
    }
    
    override func itemSelected(at indexPath: IndexPath) {
        let key = itemsSubject.value.orderedDict.keys[indexPath.section]
        if let array = itemsSubject.value.orderedDict[key],
           let beer = items.first(where: { UUIDHandler.compare(id: $0.id, salted: array[indexPath.row].id) }) {
            delegate?.navigateToBeer(beer, shouldUpdate: shouldUpdate, tintColor: breweryTintColor)
        } else {
            let error = ErrorMessage.unknown
            errorMessageSubject.send(error)
        }
    }    
}

class BeerCellarDataFetcher: DataFetcherProtocol {
    typealias SortingOption = BeerSortingOption
    typealias ItemType = Beer
    
    private let networkProvider: BeerCellarNetWorkProviderProtocol
    private let cellar: BeerCellar
    private let persistence: BeerCellarResultsPersistence
    
    init(networkProvider: BeerCellarNetWorkProviderProtocol, cellar: BeerCellar, persistence: BeerCellarResultsPersistence) {
        self.networkProvider = networkProvider
        self.cellar = cellar
        self.persistence = persistence
    }
    
    func fetchItems(
        searchTerm: String,
        filters: FiltersAndOperator,
        sorting: (OrderOption, SortingOption)
    ) async throws -> [Beer] {
        let beers = try await networkProvider.fetchItems(searchTerm: searchTerm, filters: filters, sorting: sorting)
        return try filterByCellar(beers: beers, cellar: self.cellar)
    }
    
    private func filterByCellar(beers: [Beer], cellar: BeerCellar) throws -> [Beer] {
        switch cellar {
        case .all:
            return beers
        case .have:
            let haveIds = try persistence.have()
            return beers.filter { haveIds.contains("\($0.id)") }
        case .had:
            let hadIds = try persistence.had()
            return beers.filter { hadIds.contains("\($0.id)") }
        case .want:
            let wantIds = try persistence.want()
            return beers.filter { wantIds.contains("\($0.id)") }
        }
    }
}
