//
//  BeerCellarGalleryViewController.swift
//  HopSpin
//
//  Created by Antonio Carella on 11/30/23.
//

import UIKit

class BeerCellarGalleryViewController: GalleryTableViewController {
    
    override var bottomToastBottomConstaintConstant: CGFloat {
        24.0
    }
    
    init(viewModel: BeerCellarGalleryViewModel) {
        super.init(viewModel: viewModel)
        
        galleryOrListButton
            .valueChanged
            .receive(on: DispatchQueue.main)
            .sink { state in
                viewModel.beerViewSegementStateFilterSubject.send(state)
            }
            .store(in: &subscriptions)
        
        galleryOrListButton.style(view: .gallery)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func constrainBottomStack() {

        NSLayoutConstraint.activate([
            bottomToast.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            bottomToast.bottomAnchor.constraint(
                equalTo: view.bottomAnchor,
                constant: -bottomToastBottomConstaintConstant
            ),
            bottomToast.heightAnchor.constraint(equalToConstant: 48)
            ]
        )
    }
    
    override func constrainLoadingViewBackground() {
        NSLayoutConstraint.activate([
            loadingViewBackground.leadingAnchor.constraint(equalTo: tableView.leadingAnchor),
            loadingViewBackground.topAnchor.constraint(equalTo: tableView.topAnchor),
            loadingViewBackground.trailingAnchor.constraint(equalTo: tableView.trailingAnchor),
            loadingViewBackground.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
    }
    
    override func constrainTableView() {
        NSLayoutConstraint.activate([
            tableView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor),
            tableView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
    }
    
    override var bottomToastVOffset: CGFloat {
        bottomToast.frame.size.height + bottomToastBottomConstaintConstant
    }
}
