//
//  BeerGalleryViewController.swift
//  HopSpin
//
//  Created by Antonio Carella on 9/3/23.
//

import Combine
import OrderedCollections
import UIKit

class BeerCellarViewController: UIViewController {

    private var allListView: UIView!
    private var haveListView: UIView!
    private var hadListView: UIView!
    private var wantListView: UIView!
    private var allGalleryView: UIView!
    private var haveGalleryView: UIView!
    private var hadGalleryView: UIView!
    private var wantGalleryView: UIView!
    
    private lazy var allChildViews: [UIView] = [
        allListView,
        haveListView,
        hadListView,
        wantListView,
        allGalleryView,
        haveGalleryView,
        hadGalleryView,
        wantGalleryView
    ]
    
    private let backGroundView = DarkenedBackgroundView()
    
    // MARK: Combine
    private let searchBarTextPublisher = PassthroughSubject<String, Never>()
    private var subscriptions = Set<AnyCancellable>()
    
    // MARK: Dependencies
    private let viewModel: BeerCellarViewModel
        
    // MARK: UI Elements
    private lazy var searchController: UISearchController = {
        let searchController = UISearchController(searchResultsController: nil)
        searchController.searchBar.autocapitalizationType = .none
        searchController.searchBar.delegate = self
        searchController.searchBar.tintColor = .white
        searchController.searchBar.searchTextField.backgroundColor = .white.withAlphaComponent(0.25)
        searchController.searchBar.searchTextField.layer.cornerRadius = StyleKit.cornerRadius
        searchController.searchBar.searchTextField.clipsToBounds = true
        searchController.obscuresBackgroundDuringPresentation = false
        searchController.hidesNavigationBarDuringPresentation = false
        searchController.showsSearchResultsController = false
        
        return searchController
    }()
    
    private lazy var closeButton: UIBarButtonItem = {
        UIBarButtonItem(
            image: UIImage(
                systemName: "xmark",
                withConfiguration: UIImage.SymbolConfiguration(pointSize: 17, weight: .semibold)
            ),
            style: .plain,
            target: self,
            action: #selector(closeTapped)
        )
    }()
    
    private let searchControlBar: SearchControlBar
    
    // MARK: Lifecycle
    init(viewModel: BeerCellarViewModel) {
        self.viewModel = viewModel
        
        self.searchControlBar = SearchControlBar(
            config: SearchControlBarConfig.cellar(
                tint: viewModel.tintColor,
                backgroundColor: viewModel.searchControlBarBackground
            )
        )
        
        viewModel.beerViewSegementStateFilterSubject.send(.all)
        
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        lockModal()
        allListView = addChildViewController(
            BeerCellarListViewController(
                viewModel: viewModel.allListViewModel
            )
        )
        
        haveListView = addChildViewController(
            BeerCellarListViewController(
                viewModel: viewModel.haveListViewModel
            )
        )
        
        hadListView = addChildViewController(
            BeerCellarListViewController(
                viewModel: viewModel.hadListViewModel
            )
        )
        
        wantListView = addChildViewController(
            BeerCellarListViewController(
                viewModel: viewModel.wantListViewModel
            )
        )
        
        allGalleryView = addChildViewController(
            BeerCellarGalleryViewController(
                viewModel: viewModel.allGalleryViewModel
            )
        )
        
        haveGalleryView = addChildViewController(
            BeerCellarGalleryViewController(
                viewModel: viewModel.haveGalleryViewModel
            )
        )
        
        hadGalleryView = addChildViewController(
            BeerCellarGalleryViewController(
                viewModel: viewModel.hadGalleryViewModel
            )
        )
        
        wantGalleryView = addChildViewController(
            BeerCellarGalleryViewController(
                viewModel: viewModel.wantGalleryViewModel
            )
        )
        
        adjustSafeAreasForMaxScreens()
        setupViews()
        constrainViews()
        bindViewModel()
        bindSelf()
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        let frame = self.view.convert(searchController.searchBar.frame, from: self.view)
        viewModel.searchControlBarOffset.send(frame.maxY)
    }
    
    private func bindViewModel() {
        viewModel
            .showFilterSortMenu
            .receive(on: DispatchQueue.main)
            .sink(receiveValue: showFilterSortMenu)
            .store(in: &subscriptions)
        
        viewModel
            .filterSortBadge
            .receive(on: DispatchQueue.main)
            .sink(receiveValue: badgeFilterIcon)
            .store(in: &subscriptions)
        
        viewModel
            .$errorMessage
            .receive(on: DispatchQueue.main)
            .compactMap { $0 }
            .sink { [weak self] in
                self?.present(errorMessage: $0)
            }
            .store(in: &subscriptions)
        
        viewModel
            .resultsViewPublisher
            .receive(on: DispatchQueue.main)
            .sink(receiveValue: updateView(for:))
            .store(in: &subscriptions)
    }
    
    private func bindSelf() {
        searchControlBar
            .filterSegmentTap
            .receive(on: DispatchQueue.main)
            .sink { [weak self] index in
                let cellarState: CellarSegmentState
                switch index {
                case 0: cellarState = .all
                case 1: cellarState = .have
                case 2: cellarState = .want
                case 3: cellarState = .had
                default: cellarState = .all
                }
                self?.viewModel.beerViewSegementStateFilterSubject.send(cellarState)
            }
            .store(in: &subscriptions)
        
        searchControlBar
            .filterSortButtonTap
            .receive(on: DispatchQueue.main)
            .sink { [weak self] in
                self?.viewModel.filtersSortButtonTapped.send()
            }
            .store(in: &subscriptions)
        
        searchControlBar
            .sortButtonTap
            .receive(on: DispatchQueue.main)
            .sink { [weak self] in
                self?.viewModel.sortTappedSubject.send()
            }
            .store(in: &subscriptions)
        
        searchBarTextPublisher
            .debounce(for: .seconds(0.3), scheduler: RunLoop.main)
            .sink { [weak self] output in
                self?.viewModel.filterOn(filterTerm: output)
            }
            .store(in: &subscriptions)
    }
    
    private func constrainViews() {
        view.addSubview(backGroundView)
        backGroundView.translatesAutoresizingMaskIntoConstraints = false
                        
        view.addSubview(searchControlBar)
        searchControlBar.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate {
            
            searchControlBar.leadingAnchor.constraint(equalTo: view.leadingAnchor)
            searchControlBar.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor)
            searchControlBar.trailingAnchor.constraint(equalTo: view.trailingAnchor)
            
            
            backGroundView.leadingAnchor.constraint(equalTo: view.leadingAnchor)
            backGroundView.topAnchor.constraint(equalTo: view.topAnchor)
            backGroundView.trailingAnchor.constraint(equalTo: view.trailingAnchor)
            backGroundView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
            
            }
        
        allChildViews
            .forEach { tableView in
            tableView.translatesAutoresizingMaskIntoConstraints = false
            view.addSubview(tableView)
            NSLayoutConstraint.activate([
                tableView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor),
                tableView.topAnchor.constraint(equalTo: searchControlBar.bottomAnchor),
                tableView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor),
                tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
            ])
        }
    }
    
    private func updateView(for resultsView: BeerGalleryView) {
        let view: UIView
        switch resultsView {
        case .allGallery: view = allGalleryView
        case .allList: view = allListView
        case .hadGallery: view = hadGalleryView
        case .hadList: view = hadListView
        case .haveGallery: view = haveGalleryView
        case .haveList: view = haveListView
        case .wantGallery: view = wantGalleryView
        case .wantList: view = wantListView
        }
        
        self.view.bringSubviewToFront(view)
    }
    
    private func setupViews() {
        
        self.title = viewModel.name
        navigationItem.searchController = searchController
        view.backgroundColor = .white
        navigationItem.setLeftBarButton(closeButton, animated: false)
                
        // These need to be set here, else they won't get applied, b/c... UIKit
        searchController.searchBar.searchTextField.leftView?.tintColor = .white
        searchController.searchBar.searchTextField.rightView?.tintColor = .white
        searchController.searchBar.searchTextField.textColor = .white
        searchController.searchBar.searchTextField.attributedPlaceholder = NSMutableAttributedString(string: "Search", attributes: [.font: UIFont.systemFont(ofSize: 17.0), .foregroundColor: UIColor.white])

        if let searchTextField = searchController.searchBar.value(forKey: "searchField") as? UITextField, let clearButton = searchTextField.value(forKey: "clearButton") as? UIButton {
            let templateImage = clearButton.imageView?.image?.withRenderingMode(.alwaysTemplate)
            clearButton.setImage(templateImage, for: .normal)
            clearButton.tintColor = Colors.dimmedWhite
        }
        
        backGroundView.isHidden = true
    }
    
    @objc private func closeTapped() {
        navigationController?.dismiss(animated: true)
    }
    
    private func showFilterSortMenu(content: SearchControlBarMenuContent) {
        presentMenu(content: content)
    }
    
    private func badgeFilterIcon(count: Int) {
        searchControlBar.badgeFilterSortButton(withNumber: count)
    }
}

extension BeerCellarViewController: UISearchBarDelegate {
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        guard let text = searchBar.text else {
            return
        }
        viewModel.filterOn(filterTerm: text)
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        viewModel.filterOn(filterTerm: "")
    }
    
    func searchBarShouldBeginEditing(_ searchBar: UISearchBar) -> Bool {
        backGroundView.isHidden = false
        searchBar.placeholder = ""
        view.bringSubviewToFront(backGroundView)
        return true
    }
    
    func searchBarShouldEndEditing(_ searchBar: UISearchBar) -> Bool {
        view.sendSubviewToBack(backGroundView)
        // Hide so we don't see this view during the navigation controller's push transition
        backGroundView.isHidden = true
        return true
    }
    
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
        searchBar.placeholder = "Search"
    }
    
}

extension BeerCellarViewController {
    
    func presentMenu(content: SearchControlBarMenuContent) {
        
        let x = shouldAdjustSafeAreasForMaxScreens() ?
        searchControlBar.bounds.maxX - 170.0 : searchControlBar.bounds.maxX
        
        let menuViewController = SearchControlBarMenuViewController(content: content)
        menuViewController.popoverPresentationController?.canOverlapSourceViewRect = true
        menuViewController.popoverPresentationController?.sourceView = searchControlBar
        menuViewController.popoverPresentationController?.sourceRect = CGRect(
            origin: .init(
                x: x,
                y: searchControlBar.bounds.midY + 153.5/2 + 6
            ),
            size: .zero
        )
        
        menuViewController
            .sortTapped
            .receive(on: DispatchQueue.main)
            .sink(receiveValue: { [weak self] in
                self?.dismiss(animated: true, completion: {
                    self?.viewModel.sortTappedSubject.send(())
                })
            })
            .store(in: &subscriptions)
        
        menuViewController
            .filterTapped
            .receive(on: DispatchQueue.main)
            .sink(receiveValue: { [weak self] in
                self?.dismiss(animated: true, completion: {
                    self?.viewModel.filtersTappedSubject.send(())
                })
            })
            .store(in: &subscriptions)
        
        menuViewController
            .resetTapped
            .receive(on: DispatchQueue.main)
            .sink { [weak self] in
                self?.dismiss(animated: true, completion: {
                    self?.viewModel.resetTappedSubject.send(())
                })
            }
            .store(in: &subscriptions)
                        
        present(menuViewController, animated: true)
    }
    
}

