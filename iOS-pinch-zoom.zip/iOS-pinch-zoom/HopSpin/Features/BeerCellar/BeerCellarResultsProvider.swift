//
//  BeerCellarResultsProvider.swift
//  HopSpin
//
//  Created by Antonio Carella on 11/21/23.
//

import Foundation

struct BeerCellarResultsPersistence {
    private static let beerPersister = BeerCellarPersistance()
    var have: () throws -> [String]
    var want: () throws -> [String]
    var had: () throws -> [String]
}

extension BeerCellarResultsPersistence {
    
    static let live: BeerCellarResultsPersistence = .init {
        try beerPersister.fetch(cellar: .have)
    } want: {
        try beerPersister.fetch(cellar: .want)
    } had: {
        try beerPersister.fetch(cellar: .had)
    }
}
