//
//  BeerCellarPersistance.swift
//  HopSpin
//
//  Created by Antonio Carella on 9/4/23.
//

import Foundation

enum BeerCellar: String {
    case all, want, have, had
}

protocol BeerCellarPersistable {
    func save(beerId: String, cellar: BeerCellar) throws
    func fetch(cellar: BeerCellar) throws -> [String]
    func removeBeerId(_ id: String, cellar: BeerCellar) throws
}

class BeerCellarPersistance: BeerCellarPersistable {
    
    private func fileURL(for cellar: BeerCellar) -> URL {
        let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        return documentsDirectory.appendingPathComponent("\(cellar.rawValue).txt")
    }
    
    func save(beerId: String, cellar: BeerCellar) throws {
        var existingIds = try fetch(cellar: cellar)
        if !existingIds.contains(beerId) {
            existingIds.append(beerId)
            let combinedString = existingIds.joined(separator: "\n")
            try combinedString.write(to: fileURL(for: cellar), atomically: true, encoding: .utf8)
        }
    }
    
    func fetch(cellar: BeerCellar) throws -> [String] {
        guard FileManager.default.fileExists(atPath: fileURL(for: cellar).path) else {
            return []
        }
        let savedIds = try String(contentsOf: fileURL(for: cellar), encoding: .utf8)
        return savedIds.split(separator: "\n").map(String.init)
    }
    
    func removeBeerId(_ id: String, cellar: BeerCellar) throws {
        var ids = try fetch(cellar: cellar)
        ids.removeAll { $0 == id }
        let updatedString = ids.joined(separator: "\n")
        try updatedString.write(to: fileURL(for: cellar), atomically: true, encoding: .utf8)
    }
}
