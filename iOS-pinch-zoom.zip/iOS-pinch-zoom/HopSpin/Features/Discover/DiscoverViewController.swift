//
//  DiscoverViewController.swift
//  HopSpin
//
//  Created by Antonio Carella on 8/20/23.
//

import UIKit
import Combine
import OrderedCollections

enum DiscoveryView {
    case beerGallery
    case beerList
    case brewery
    case artist
}

class DiscoverViewController: UIViewController {
    
    private var beerListView: UIView!
    private var beerGalleryView: UIView!
    private var breweryView: UIView!
    private var artistView: UIView!
    
    private let backGroundView = DarkenedBackgroundView()
    
    // MARK: Combine
    private var subscriptions = Set<AnyCancellable>()
    
    // MARK: Dependencies
    private let viewModel: DiscoverViewModel
    
    // MARK: UI Elements
    private lazy var searchController: UISearchController = {
        let searchController = UISearchController(searchResultsController: nil)
        searchController.searchBar.autocapitalizationType = .none
        searchController.searchBar.delegate = self
        searchController.searchBar.searchTextField.backgroundColor = .white.withAlphaComponent(0.25)
        searchController.searchBar.searchTextField.layer.cornerRadius = StyleKit.cornerRadius
        searchController.searchBar.searchTextField.clipsToBounds = true
        searchController.obscuresBackgroundDuringPresentation = false
        searchController.hidesNavigationBarDuringPresentation = false
        searchController.showsSearchResultsController = false
        
        return searchController
    }()
    
    private let searchControlBar: SearchControlBar
    
    // MARK: Lifecycle
    init(viewModel: DiscoverViewModel) {
        self.viewModel = viewModel
        
        self.searchControlBar = SearchControlBar(
            config: .discoverView
        )
        
        super.init(nibName: nil, bundle: nil)
        adjustSafeAreasForMaxScreens()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.beerListView = addChildViewController(
            BeerListViewController(
                viewModel: viewModel.beerListViewModel
            )
        )
        
        self.beerGalleryView = addChildViewController(
            BeerGalleryTableViewController(
                viewModel: viewModel.beerGalleryViewModel
            )
        )
        
        self.breweryView = addChildViewController(
            BrewerySearchResultsViewController(
                viewModel: viewModel.breweryListViewModel
            )
        )
        
        self.artistView = addChildViewController(
            ArtistSearchResultsViewController(
                viewModel: viewModel.artistListViewModel
            )
        )
        
        setupViews()
        constrainViews()
        bindViewModel()
        bindSelf()
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        let frame = self.view.convert(searchController.searchBar.frame, from: searchController.searchBar.superview)
        viewModel.searchControlBarOffset.send(frame.minY)
    }
    
    private func bindViewModel() {
        
        viewModel
            .resultsViewPublisher
            .receive(on: DispatchQueue.main)
            .sink(receiveValue: updateView(for:))
            .store(in: &subscriptions)
        
        viewModel
            .showFilterSortMenu
            .receive(on: DispatchQueue.main)
            .sink(receiveValue: showFilterSortMenu)
            .store(in: &subscriptions)
        
        viewModel
            .filterSortBadge
            .receive(on: DispatchQueue.main)
            .sink(receiveValue: badgeFilterIcon)
            .store(in: &subscriptions)
    }
    
    private func bindSelf() {
        searchControlBar
            .filterSegmentTap
            .receive(on: DispatchQueue.main)
            .sink { [weak self] index in
                switch index {
                case 0:
                    self?.viewModel.beerSegmentedTapped()
                case 1:
                    self?.viewModel.brewerySegmentedTapped()
                case 2:
                    self?.viewModel.artistSegmentedTapped()
                default:
                    assertionFailure("Case not handled")
                }
            }
            .store(in: &subscriptions)
        
        searchControlBar
            .filterSortButtonTap
            .receive(on: DispatchQueue.main)
            .sink { [weak self] in
                self?.viewModel.filterSortTapped()
            }
            .store(in: &subscriptions)
        
        searchControlBar
            .sortButtonTap
            .receive(on: DispatchQueue.main)
            .sink { [weak self] in
                self?.viewModel.sortingTapped()
            }
            .store(in: &subscriptions)
    }
    
    private func constrainViews() {
        view.addSubview(backGroundView)
        backGroundView.translatesAutoresizingMaskIntoConstraints = false
        
        searchControlBar.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(searchControlBar)
        
        let allSubViews = [
            beerListView,
            beerGalleryView,
            breweryView,
            artistView
        ]
            
        allSubViews.forEach { tableView in
            tableView?.translatesAutoresizingMaskIntoConstraints = false
            view.addSubview(tableView!)
        }
        
        NSLayoutConstraint.activate {
            allSubViews.map { tableView in
                [
                    tableView!.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor),
                    tableView!.topAnchor.constraint(equalTo: searchControlBar.bottomAnchor),
                    tableView!.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor),
                    tableView!.bottomAnchor.constraint(equalTo: view.bottomAnchor)
                ]
            }.flatMap { $0 }
            
            searchControlBar.leadingAnchor.constraint(equalTo: view.leadingAnchor)
            searchControlBar.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor)
            searchControlBar.trailingAnchor.constraint(equalTo: view.trailingAnchor)
            
            backGroundView.leadingAnchor.constraint(equalTo: view.leadingAnchor)
            backGroundView.topAnchor.constraint(equalTo: view.topAnchor)
            backGroundView.trailingAnchor.constraint(equalTo: view.trailingAnchor)
            backGroundView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor)
        }
    }
    
    private func updateView(for resultsView: DiscoveryView) {
        let view: UIView
        switch resultsView {
        case .beerList: view = beerListView
        case .beerGallery: view = beerGalleryView
        case .brewery: view = breweryView
        case .artist: view = artistView
        }
        
        self.view.bringSubviewToFront(view)
    }
    
    private func showFilterSortMenu(content: SearchControlBarMenuContent) {
        presentMenu(content: content)
    }
    
    @objc private func filtersTapped() {
        viewModel.filtersTapped()
    }
    
    private func badgeFilterIcon(count: Int) {
        searchControlBar.badgeFilterSortButton(withNumber: count)
    }
    
    private func setupViews() {
        
        self.title = "Discover"
        navigationItem.searchController = searchController
        view.backgroundColor = .white
        
        placeLogoInNavBar()
        // These need to be set here, else they won't get applied, b/c... UIKit
        searchController.searchBar.searchTextField.leftView?.tintColor = .white
        searchController.searchBar.searchTextField.rightView?.tintColor = .white
        searchController.searchBar.searchTextField.textColor = .white
        searchController.searchBar.searchTextField.attributedPlaceholder = NSMutableAttributedString(string: "Search", attributes: [.font: UIFont.systemFont(ofSize: 17.0), .foregroundColor: UIColor.white])
        
        if let searchTextField = searchController.searchBar.value(forKey: "searchField") as? UITextField, let clearButton = searchTextField.value(forKey: "clearButton") as? UIButton {
            let templateImage = clearButton.imageView?.image?.withRenderingMode(.alwaysTemplate)
            clearButton.setImage(templateImage, for: .normal)
            clearButton.tintColor = Colors.dimmedWhite
        }
        
        backGroundView.isHidden = true
    }
}

extension DiscoverViewController: UISearchBarDelegate {
    
    func searchBarShouldBeginEditing(_ searchBar: UISearchBar) -> Bool {
        backGroundView.isHidden = false
        searchBar.placeholder = ""
        view.bringSubviewToFront(backGroundView)
        return true
    }
    
    func searchBarShouldEndEditing(_ searchBar: UISearchBar) -> Bool {
        view.sendSubviewToBack(backGroundView)
        // Hide so we don't see this view during the navigation controller's push transition
        backGroundView.isHidden = true
        return true
    }
    
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
        searchBar.placeholder = "Search"
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        guard let text = searchBar.text else {
            return
        }
        viewModel.searchTermSubject.send(text)
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        viewModel.searchTermSubject.send("")
    }
}

extension DiscoverViewController {

    func presentMenu(content: SearchControlBarMenuContent) {
        
        let x = shouldAdjustSafeAreasForMaxScreens() ? 
        searchControlBar.bounds.maxX - 170.0 : searchControlBar.bounds.maxX
        
        let menuViewController = SearchControlBarMenuViewController(content: content)
        menuViewController.popoverPresentationController?.canOverlapSourceViewRect = true
        menuViewController.popoverPresentationController?.sourceView = searchControlBar
        menuViewController.popoverPresentationController?.sourceRect = CGRect(
            origin: .init(
                x: x,
                y: searchControlBar.bounds.midY + 153.5/2 + 6
            ),
            size: .zero
        )
        
        menuViewController
            .sortTapped
            .receive(on: DispatchQueue.main)
            .sink { [weak self] in
                self?.dismiss(animated: true) {
                    self?.viewModel.sortingTapped()
                }
            }
            .store(in: &subscriptions)
        
        menuViewController
            .filterTapped
            .receive(on: DispatchQueue.main)
            .sink { [weak self] in
                self?.dismiss(animated: true, completion: {
                    self?.viewModel.filtersTapped()
                })
            }
            .store(in: &subscriptions)

        menuViewController
            .resetTapped
            .receive(on: DispatchQueue.main)
            .sink { [weak self] in
                self?.dismiss(animated: true, completion: {
                    self?.viewModel.resetTapped()
                })
            }
            .store(in: &subscriptions)
        
        present(menuViewController, animated: true)
    }

}
