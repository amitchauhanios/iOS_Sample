//
//  DiscoverViewModel.swift
//  HopSpin
//
//  Created by Antonio Carella on 12/17/23.
//

import Combine
import OrderedCollections
import UIKit


class DiscoverViewModel {
    
    var delegate: SearchResultSelectedHandler? {
        willSet {
            beerListViewModel.delegate = newValue
            beerGalleryViewModel.delegate = newValue
            breweryListViewModel.delegate = newValue
            artistListViewModel.delegate = newValue
        }
    }
    
    private static let countDisplayDelay: Double = 0.125
    private var subscriptions = Set<AnyCancellable>()
    
    let beerListViewModel: BeerListViewModel
    let beerGalleryViewModel: BeerGalleryTableViewModel
    let breweryListViewModel: BrewerySearchResultsListViewModel
    let artistListViewModel: ArtistSearchResultsListViewModel
    
    // Pass these to ViewModels to observe filter changes
    // We have one per model type (ie, not per view) on purpose.
    // We want the beers filters to apply to both gallery and list views
    private let beerFilters = CurrentValueSubject<FiltersAndOperator, Never>(.initial)
    private let breweryFilters = CurrentValueSubject<FiltersAndOperator, Never>(.initial)
    private let artistFilters = CurrentValueSubject<FiltersAndOperator, Never>(.initial)
    
    private let beerSorting = CurrentValueSubject<(OrderOption, BeerSortingOption), Never>((.ascending, .name))
    private let brewerySorting = CurrentValueSubject<(OrderOption, BrewerySortingOption), Never>((.ascending, .name))
    private let artistSorting = CurrentValueSubject<(OrderOption, ArtistSortingOption), Never>((.ascending, .name))
    
    let searchTermSubject: CurrentValueSubject<String, Never>
    let searchControlBarOffset = CurrentValueSubject<CGFloat, Never>(100.0)    
    let showFilterSortMenu = PassthroughSubject<SearchControlBarMenuContent, Never>()
    let filterSortBadge = PassthroughSubject<Int, Never>()
    
    var resultsViewPublisher: AnyPublisher<DiscoveryView, Never> {
        resultsViewSubject.eraseToAnyPublisher()
    }
        
    private var resultsViewSubject = CurrentValueSubject<DiscoveryView, Never>(.beerList)
    private let viewSegementStateFilterSubject: CurrentValueSubject<ViewSegementState, Never>
    private let beerViewSegementStateFilterSubject = CurrentValueSubject<BeerViewSegmentState, Never>(BeerViewSegmentState.gallery)
    
    init(
        imageRepository: ImageRepository
    ) {
        self.searchTermSubject = CurrentValueSubject<String, Never>("")
        
        self.viewSegementStateFilterSubject = CurrentValueSubject<ViewSegementState, Never>(.beer)
        let sharedBeerDataFetcher = BeerDataFetcher(apiClient: .live)
        
        self.beerListViewModel = .init(
            dataFetcher: sharedBeerDataFetcher,
            searchTerm: searchTermSubject,
            filters: beerFilters,
            sorting: beerSorting,
            imageRepository: imageRepository, 
            tintColor: Colors.hopSpinLightGreen,
            cellSelectionColor: Colors.pressAndHoldGreen,
            activityIndicatorColor: Colors.hopspinGreen,
            beerViewSegementStateFilterSubject: beerViewSegementStateFilterSubject
        )
        
        self.beerGalleryViewModel = .init(
            dataFetcher: sharedBeerDataFetcher,
            searchTerm: searchTermSubject,
            filters: beerFilters,
            sorting: beerSorting,
            imageRepository: imageRepository,
            activityIndicatorColor: Colors.hopspinGreen,
            beerViewSegementStateFilterSubject: beerViewSegementStateFilterSubject
        )
        
        self.breweryListViewModel = .init(
            dataFetcher: .init(),
            searchTerm: searchTermSubject,
            filters: breweryFilters,
            sorting: brewerySorting,
            tintColor: Colors.hopSpinLightGreen,
            cellSelectionColor: Colors.pressAndHoldGreen,
            activityIndicatorColor: Colors.hopspinGreen
        )
        
        self.artistListViewModel = .init(
            dataFetcher: .init(),
            searchTerm: searchTermSubject,
            filters: artistFilters,
            sorting: artistSorting,
            tintColor: Colors.hopSpinLightGreen,
            cellSelectionColor: Colors.pressAndHoldGreen,
            activityIndicatorColor: Colors.hopspinGreen
        )
        
        bind()
    }
    
    private func bind() {
        Publishers
            .CombineLatest(
                viewSegementStateFilterSubject,
                beerViewSegementStateFilterSubject
            )
            .map { viewSegment, beerViewSegment -> DiscoveryView in
                switch viewSegment {
                case .beer:
                    switch beerViewSegment {
                    case .list:
                        return .beerList
                    case .gallery:
                        return .beerGallery
                    }
                case .brewery:
                    return .brewery
                case .artist:
                    return .artist
                }
            }
            .removeDuplicates()
            .sink { [weak self] in
                self?.resultsViewSubject.send($0)
            }
            .store(in: &subscriptions)
        
        resultsViewSubject
            .map { [weak self] view in
                guard let self else { return 0 }
                switch view {
                case .beerGallery, .beerList:
                    return self.beerFilters.value.filterParams.count
                case .brewery:
                    return self.breweryFilters.value.filterParams.count
                case .artist:
                    return self.artistFilters.value.filterParams.count
                }
            }
            .sink(receiveValue: { [weak self] count in
                self?.filterSortBadge.send(count)
            })
            .store(in: &subscriptions)
        
    }
    
    func beerSegmentedTapped() {
        viewSegementStateFilterSubject.send(.beer)
    }
    
    func brewerySegmentedTapped() {
        viewSegementStateFilterSubject.send(.brewery)
    }
    
    func artistSegmentedTapped() {
        viewSegementStateFilterSubject.send(.artist)
    }
    
    func gallerySegmentTapped() {
        beerViewSegementStateFilterSubject.send(.gallery)
    }
    
    func listSegmentTapped() {
        beerViewSegementStateFilterSubject.send(.list)
    }
    
    func filterSortTapped() {
        let sortTitle: String
        let sortValue: String
        let filterTitle: String
        let filterCount: Int
        let view = viewSegementStateFilterSubject.value
        switch view {
        case .beer:
            sortTitle = "Sort Beers By"
            filterTitle = "Filter Beers By"
            sortValue = beerSorting.value.1.title
            filterCount = beerFilters.value.filterParams.count
        case .brewery:
            sortTitle = "Sort Breweries By"
            filterTitle = "Filter Breweries By"
            sortValue = brewerySorting.value.1.title
            filterCount = breweryFilters.value.filterParams.count
        case .artist:
            sortTitle = "Sort Artists By"
            filterTitle = "Filter Artists By"
            sortValue = artistSorting.value.1.title
            filterCount = artistFilters.value.filterParams.count
        }
        
        let noun = filterCount == 1 ? "Filter" : "Filters"
        let filterValue = "\(filterCount) \(noun)"
        
        showFilterSortMenu.send(
            .init(
                sortTitle: sortTitle,
                sortValue: sortValue,
                filterTitle: filterTitle,
                filterValue: filterValue,
                tintColor: Colors.hopspinGreen,
                tapColor: Colors.pressAndHoldGreen
            )
        )
    }
    
    func filtersTapped() {
        let filterSnapshot: OrderedDictionary<String, [FilterParam]>
        let selectedFiltersSubject: CurrentValueSubject<FiltersAndOperator, Never>
        let flattenedFilteringParams: [FilterParam]
        let sectionTitleItem: FilterSectionItem
        switch viewSegementStateFilterSubject.value {
        case .beer:
            flattenedFilteringParams = beerListViewModel.filteringParamsSnapshot.value
            filterSnapshot = BeerFilteringParameterGrouper.group(filterParams: flattenedFilteringParams)
            selectedFiltersSubject = beerFilters
            sectionTitleItem = .beer(Colors.pressAndHoldGreen)
        case .brewery:
            selectedFiltersSubject = breweryFilters
            flattenedFilteringParams = breweryListViewModel.filteringParamsSnapshot.value
            filterSnapshot = BreweryFilteringParameterGrouper.group(filterParams: flattenedFilteringParams)
            sectionTitleItem = .brewery(Colors.pressAndHoldGreen)
        case .artist:
            flattenedFilteringParams = artistListViewModel.filteringParamsSnapshot.value
            filterSnapshot = ArtistFilteringParameterGrouper.group(filterParams: flattenedFilteringParams)
            selectedFiltersSubject = artistFilters
            sectionTitleItem = .artist(Colors.pressAndHoldGreen)
        }
        
        delegate?.navigateToFilters(
            filterSnapshot,
            selected: selectedFiltersSubject.value,
            tintColor: Colors.hopspinGreen,
            offset: searchControlBarOffset.value, 
            sectionTitleItem: sectionTitleItem,
            applyFiltersHandler: { [weak self] filterAndOperator in
                selectedFiltersSubject.send(filterAndOperator)
                self?.filterSortBadge.send(filterAndOperator.filterParams.count)
            }
        )
    }
    
    func sortingTapped() {
        let sortingOptions: [String]
        let selectedSorting: (OrderOption, String)
        let view = viewSegementStateFilterSubject.value
        let sectionTitleItem: SortSectionTitleItem
        switch view {
        case .beer:
            sortingOptions = BeerSortingOption.sortedTitles
            let selectSortingOption = beerSorting.value.1
            selectedSorting = (beerSorting.value.0, (selectSortingOption).title)
            sectionTitleItem = .beer(Colors.pressAndHoldGreen)
        case .brewery:
            sortingOptions = BrewerySortingOption.sortedTitles
            let selectSortingOption = brewerySorting.value.1
            selectedSorting = (brewerySorting.value.0, (selectSortingOption).title)
            sectionTitleItem = .brewery(Colors.pressAndHoldGreen)
        case .artist:
            sortingOptions = ArtistSortingOption.allCases.map { $0.title }
            let selectSortingOption = artistSorting.value.1
            selectedSorting = (artistSorting.value.0, (selectSortingOption).title)
            sectionTitleItem = .artist(Colors.pressAndHoldGreen)
        }
        
        delegate?.navigateToSorting(
            sortingOptions,
            selected: selectedSorting,
            applySortingHandler: { [weak self] sortingOptions in
                guard let self else { return }
                switch view {
                case .beer:
                    let sortOption = BeerSortingOption(title: sortingOptions.1)
                    self.beerSorting.send((sortingOptions.0, sortOption))
                case .brewery:
                    let sortOption = BrewerySortingOption(title: sortingOptions.1)
                    self.brewerySorting.send((sortingOptions.0, sortOption))
                case .artist:
                    let sortOption = ArtistSortingOption(title: sortingOptions.1)
                    self.artistSorting.send((sortingOptions.0, sortOption))
                }
            },
            tintColor: Colors.hopspinGreen,
            offset: searchControlBarOffset.value, 
            sectionTitleItem: sectionTitleItem
        )
    }
    
    func resetTapped() {
        let view = viewSegementStateFilterSubject.value
        switch view {
        case .beer:
            beerFilters.send(.initial)
            beerSorting.send((.ascending, .name))
        case .brewery:
            breweryFilters.send(.initial)
            brewerySorting.send((.ascending, .name))
        case .artist:
            artistFilters.send(.initial)
            artistSorting.send((.ascending, .name))
        }
        
        filterSortBadge.send(0)
    }
}
