//
//  ArtistListViewModel.swift
//  HopSpin
//
//  Created by Antonio Carella on 11/14/23.
//

import Combine
import OrderedCollections
import Foundation

class ArtistSearchResultsListViewModel: GenericListViewModel<Artist, ArtistListDataProcessor, ArtistDataFetcher, ArtistSortingOption>{
    
    override func itemSelected(at indexPath: IndexPath) {
        let key = itemsSubject.value.orderedDict.keys[indexPath.section]
        
        if let array = itemsSubject.value.orderedDict[key],
           let item = array.first(where: { $0.id == array[indexPath.row].id }),
           let brewery = items.first(where: { UUIDHandler.compare(id: $0.id, salted: item.id) }) {
            delegate?.navigateToArtist(brewery)
        } else {
            self.errorMessageSubject.send(
                .unknown
            )
        }
    }
    
}

class ArtistDataFetcher: DataFetcherProtocol {
    
    typealias SortingOption = ArtistSortingOption
    typealias ItemType = Artist
    
    private let apiClient: ApiClient
        
    init(apiClient: ApiClient = .live) {
        self.apiClient = apiClient
    }
    
    func fetchItems(
        searchTerm: String,
        filters: FiltersAndOperator,
        sorting: (OrderOption, ArtistSortingOption)
    ) async throws -> [Artist] {
            
        let search = ArtistSearch(
            name: searchTerm,
            filters: filters,
            sortOption:  sorting.1,
            sortDirection: sorting.0.sortDirection
        )
        return try await apiClient.artistsSearch(search)
    }
}

struct ArtistListDataProcessor: ListDataProcessorProtocol {
    typealias SortingOption = ArtistSortingOption
    typealias ItemType = Artist
    
    static func process(
        items: [Artist],
        searchTerm: String,
        orderOption: OrderOption,
        sortingOption: ArtistSortingOption
    ) -> OrderedCollections.OrderedDictionary<String, [SearchListItem]> {
        
        let grouped = ArtistListDataGrouper.group(items: items, sortingOption: sortingOption , orderOption: orderOption)
        
        return grouped.mapValues { array in
            array.enumerated().map { artist in
                SearchListItem
                    .artistListItem(
                        artist: artist.element,
                        searchTerm: searchTerm,
                        isFinalRow: artist.offset == array.count - 1
                    )
            }
        }
    }
}

struct ArtistListDataGrouper {
    
    static func group(items: [Artist], sortingOption: ArtistSortingOption, orderOption: OrderOption) -> OrderedCollections.OrderedDictionary<String, [Artist]> {
        switch sortingOption {
        case .breweries:
            return GenericGrouper.groupItems(items: items, by: \.breweries, orderOption: orderOption)
        case .classification:
            return GenericGrouper.groupItems(items: items, by: \.classification, orderOption: orderOption)
        case .distinctBreweries:
            let grouped = GenericGrouper.groupItems(items: items, by: \.distinctBreweries, orderOption: orderOption)
            return GenericGrouper.groupNumericResult(grouped: grouped, orderOption: orderOption) { key in
                if key == "0" {
                    return "(Not Listed)"
                } else if key == "1" {
                    return "\(key) Brewery Partner"
                } else {
                    return "\(key) Brewery Partners"
                }
            }
        case .distinctBrandings:
                let grouped = GenericGrouper.groupItems(items: items, by: \.distinctBeers, orderOption: orderOption)
                return GenericGrouper.groupNumericResult(grouped: grouped, orderOption: orderOption) { key in
                    if key == "0" {
                        return "(Not Listed)"
                    } else if key == "1" {
                        return "\(key) Label"
                    } else {
                        return "\(key) Labels"
                    }
                }
        case .datePubliclyViewable:
            return DatePubliclyViewableGrouper<Artist>.group(items: items, by: orderOption)
        case .locationState:
            return GenericGrouper.groupItems(items: items, by: \.locationState, orderOption: orderOption)
        case .name:
            return NameGrouper<Artist>.group(items: items, by: orderOption)
        case .yearFounded:
            return GenericGrouper.groupItems(items: items, by: \.yearFounded, orderOption: orderOption)
        }
    }
    
    private static func groupArtists<T: Hashable>(
        artists: [Artist],
        by keyPath: KeyPath<Artist, T>,
        orderOption: OrderOption,
        customSorting: (([String]) -> [String])? = nil
    ) -> OrderedDictionary<String, [Artist]> {
        var grouped: [String: [Artist]] = [:]

        for artist in artists {
            if let array = artist[keyPath: keyPath] as? [String] {
                // If the keyPath is an array of strings, group under each element
                for element in array {
                    grouped[element, default: []].append(artist)
                }
            } else {
                // Otherwise, treat it as a single string
                let key = "\(artist[keyPath: keyPath])"
                grouped[key, default: []].append(artist)
            }
        }

        
        let orderedKeys: [String]
        // If there's a custom sort from the calling code, then us it
        if let customSorting {
            orderedKeys = customSorting(Array(grouped.keys))
        } else {
            // If not, just sort by alpha
           orderedKeys = grouped.keys.sorted {
                if orderOption == .ascending {
                    $0.localizedStandardCompare($1) == .orderedAscending
                } else {
                    $0.localizedStandardCompare($1) == .orderedDescending
                }
            }
        }
        var orderedDict = OrderedDictionary<String, [Artist]>()

        for key in orderedKeys {
            orderedDict[key] = grouped[key]
        }

        return orderedDict
    }
}
