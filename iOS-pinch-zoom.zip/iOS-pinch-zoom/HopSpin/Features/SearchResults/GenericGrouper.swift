//
//  GenericGrouper.swift
//  HopSpin
//
//  Created by Antonio Carella on 11/30/23.
//

import Foundation
import OrderedCollections

struct GenericGrouper {
    static func groupNumericResult<Item>(grouped: OrderedDictionary<String, [Item]>, orderOption: OrderOption, keepsZeroOptionAtBottom: Bool = false, keyModifier: (String) -> (String)) -> OrderedDictionary<String, [Item]> {
        // Sort the keys in descending order
        var sortedKeys = grouped.keys.sorted { first, second in
            if let first = Int(first), let second = Int(second) {
                if orderOption == .descending {
                    return first > second
                } else {
                    return first < second
                }
            } else {
                if orderOption == .descending {
                    return first > second
                } else {
                    return first < second
                }
            }
        }
        
        // Always place the 0 key at the end of the array, if asked
        if keepsZeroOptionAtBottom, let index = sortedKeys.firstIndex(of: "0") {
            sortedKeys.append(sortedKeys.remove(at: index))
        }
        
        // Create a new OrderedDictionary with the sorted keys
        var sortedBeersDict = OrderedDictionary<String, [Item]>()
        for key in sortedKeys {
            // Modify the keys in the process
            let modified = keyModifier(key)
            sortedBeersDict[modified] = grouped[key]
        }
        
        return sortedBeersDict
    }
    
    static func groupItems<Item: Nameable, T: Hashable>(
        items: [Item],
        by keyPath: KeyPath<Item, T>,
        shouldSortResultsAlpha: Bool = true,
        orderOption: OrderOption,
        replaceNilKeyWith: String = "(Not Listed)",
        keepsNullOptionAtBottom: Bool = true,
        customSorting: (([String]) -> [String])? = nil
    ) -> OrderedDictionary<String, [Item]> {
        var grouped: [String: [Item]] = [:]
        
        for item in items {
            if let array = item[keyPath: keyPath] as? [String] {
                // If the keyPath is an array of strings, group under each element
                if array.isEmpty {
                    grouped[replaceNilKeyWith, default: []].append(item)
                }
                
                for element in array {
                    let corrected = Self.correctKey(str: element, nilReplacement: replaceNilKeyWith)
                    grouped[corrected, default: []].append(item)
                }
            } else if let array = item[keyPath: keyPath] as? [Int] {
                // If the keyPath is an array of Ints, 
                // transform to strings then group under each element
                
                let transformed = array.map { "\($0)" }
                
                if transformed.isEmpty {
                    grouped[replaceNilKeyWith, default: []].append(item)
                }
                
                for element in transformed {
                    let corrected = Self.correctKey(str: element, nilReplacement: replaceNilKeyWith)
                    grouped[corrected, default: []].append(item)
                }
            } else {
                // Otherwise, treat it as a single string
                let key = "\(item[keyPath: keyPath])"
                let corrected = Self.correctKey(str: key, nilReplacement: replaceNilKeyWith)
                grouped[corrected, default: []].append(item)
            }
        }
        
        // Sort the Items alphabetically within their secions,
        // if asked to
        if shouldSortResultsAlpha {
            grouped = grouped.mapValues { itemArray in
                itemArray.sorted {
                    $0.name.localizedStandardCompare($1.name) == .orderedAscending
                }
            }
        }
        
        var orderedKeys: [String]
        // If there's a custom sort from the calling code, then us it
        if let customSorting {
            orderedKeys = customSorting(Array(grouped.keys))
        } else {
            // If not, just sort by alpha
            orderedKeys = grouped.keys.sorted {
                if orderOption == .ascending {
                    $0.localizedStandardCompare($1) == .orderedAscending
                } else {
                    $0.localizedStandardCompare($1) == .orderedDescending
                }
            }
        }
        
        var orderedDict = OrderedDictionary<String, [Item]>()
        
        // Always place the nil key at the end of the array, if asked
        if keepsNullOptionAtBottom, let index = orderedKeys.firstIndex(of: replaceNilKeyWith) {
            orderedKeys.append(orderedKeys.remove(at: index))
        }
        
        // Reset the keys in order
        for key in orderedKeys {
            orderedDict[key] = grouped[key]
        }
        
        return orderedDict
    }
    
    static func groupItems<Item: Nameable>(
        items: [Item],
        by keyPaths: [PartialKeyPath<Item>],
        shouldSortResultsAlpha: Bool = true,
        orderOption: OrderOption,
        replaceNilKeyWith: String? = "(Not Listed)",
        customSorting: (([String]) -> [String])? = nil
    ) -> OrderedDictionary<String, [Item]> {
        var grouped: [String: [Item]] = [:]

        for item in items {
            for keyPath in keyPaths {
                if let array = item[keyPath: keyPath] as? [String] {
                    for element in array {
                        let corrected = Self.correctKey(str: element, nilReplacement: replaceNilKeyWith)
                        grouped[corrected, default: []].append(item)
                    }
                } else {
                    let key = "\(item[keyPath: keyPath])"
                    let corrected = Self.correctKey(str: key, nilReplacement: replaceNilKeyWith)
                    grouped[corrected, default: []].append(item)
                }
            }
        }

        if shouldSortResultsAlpha {
            grouped = grouped.mapValues { itemArray in
                itemArray.sorted {
                    $0.name.localizedStandardCompare($1.name) == .orderedAscending
                }
            }
        }

        let orderedKeys: [String]
        if let customSorting {
            orderedKeys = customSorting(Array(grouped.keys))
        } else {
            orderedKeys = grouped.keys.sorted {
                if orderOption == .ascending {
                    $0.localizedStandardCompare($1) == .orderedAscending
                } else {
                    $0.localizedStandardCompare($1) == .orderedDescending
                }
            }
        }

        var orderedDict = OrderedDictionary<String, [Item]>()
        for key in orderedKeys {
            orderedDict[key] = grouped[key]
        }

        return orderedDict
    }

    
    private static func correctKey(str: String, nilReplacement: String?) -> String {
        var stripped = Self.stripOptionalFromString(str)
        stripped = Self.replaceNil(key: stripped, nilReplacement: nilReplacement)
        return stripped
    }
    
    private static func stripOptionalFromString(_ input: String) -> String {
        var stripped = input.trimmingCharacters(in: .whitespacesAndNewlines)

        // Remove 'Optional(' prefix and the matching closing ')' if present
        let optionalPrefix = "Optional("
        if stripped.hasPrefix(optionalPrefix) {
            stripped.removeFirst(optionalPrefix.count)
            var parenthesisCount = 1 // Start with 1 to match the opening parenthesis in 'Optional('
            
            // Look for the matching closing parenthesis
            for (index, char) in stripped.enumerated() {
                if char == "(" {
                    parenthesisCount += 1
                } else if char == ")" {
                    parenthesisCount -= 1
                }
                
                // When the count goes back to zero, we've found our matching parenthesis
                if parenthesisCount == 0 {
                    stripped = String(stripped.prefix(index))
                    break
                }
            }
        }

        // Remove the leading and trailing quotes if they are both present
        if stripped.hasPrefix("\"") && stripped.hasSuffix("\"") {
            stripped = stripped.dropFirst().dropLast().replacingOccurrences(of: "\\\"", with: "\"")
        }

        return stripped
    }

    private static func replaceNil(key: String, nilReplacement: String?) -> String {
        if key == "nil", let nilReplacement {
            return nilReplacement
        }
            return key
    }
    
}
