//
//  NameGrouper.swift
//  HopSpin
//
//  Created by Antonio Carella on 11/29/23.
//

import Foundation
import OrderedCollections

struct NameGrouper<Item: Nameable> {
    static func group(items: [Item], by orderOption: OrderOption) -> OrderedDictionary<String, [Item]> {
        let groupedItems = Dictionary(grouping: items) { item -> String in
            let initialCharacter = item.name.uppercased().first ?? "#"
            let initialString = String(initialCharacter).folding(options: .diacriticInsensitive, locale: .current)
            
            let isNumeric = Int(initialString) != nil
            return isNumeric ? "#" : initialString
        }
        
        let sortedKeys = groupedItems.keys.sorted {
            if orderOption == .ascending {
                $0.localizedStandardCompare($1) == .orderedAscending
            } else {
                $0.localizedStandardCompare($1) == .orderedDescending
            }
            
        }
        
        return OrderedDictionary(uniqueKeysWithValues: sortedKeys.map { key in (key, groupedItems[key]!) })
    }
}
