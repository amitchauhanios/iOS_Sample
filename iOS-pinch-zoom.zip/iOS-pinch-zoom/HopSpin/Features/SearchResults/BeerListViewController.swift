//
//  BeerListSearchResultsViewController.swift
//  HopSpin
//
//  Created by Antonio Carella on 11/14/23.
//

import Combine
import UIKit

class BeerListViewController: ListViewController {
        
    init(viewModel: BeerListViewModel) {
        super.init(
            viewModel: viewModel, 
            hidesGallerOrListButton: false
        )
        
        addRefreshControl(color: viewModel.activityIndicatorColor)
        
        self.listDataSource = ListItemsDataSource(tableView: self.tableView) { tableView, indexPath, listItem in

            guard let cell = tableView.dequeueReusableCell(withIdentifier: Self.cellId, for: indexPath) as? SearchResultsTableViewCell else {
                assertionFailure("Error dequeueing SearchResultsTableViewCell.")
                return UITableViewCell()
            }
            
            cell.tintColor = viewModel.cellSelectionColor
            
            let backgroundView = UIView()
            backgroundView.backgroundColor = viewModel.cellSelectionColor
            cell.selectedBackgroundView = backgroundView
            
            Task {
                cell.labelImageView.image = await viewModel.fetchImage(urlPath: listItem.labelImageURLPath)
            }
            
            if let attributedText = listItem.attributedTitleText {
                cell.titleLabel.attributedText = attributedText
            } else {
                cell.titleLabel.text = listItem.titleText
            }
            
            cell.subTitleLabel.text = listItem.subtitleText
            
            listItem.isFinalRow ? cell.hideSeparator() : cell.showStandardSeparator()
            
            return cell
        }
        
        galleryOrListButton.style(view: .list)
        
        galleryOrListButton
            .valueChanged
            .receive(on: DispatchQueue.main)
            .sink { state in
                viewModel.beerViewSegementStateFilterSubject.send(state)
            }
            .store(in: &subscriptions)
    }
    
    override func constrainLoadingViewBackground() {    
        NSLayoutConstraint.activate([
            loadingViewBackground.leadingAnchor.constraint(equalTo: tableView.leadingAnchor),
            loadingViewBackground.topAnchor.constraint(equalTo: tableView.topAnchor),
            loadingViewBackground.trailingAnchor.constraint(equalTo: tableView.trailingAnchor),
            loadingViewBackground.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
    }
    
    override func constrainLoadingView() {
        NSLayoutConstraint.activate([
            loadingView.centerXAnchor.constraint(equalTo: loadingViewBackground.centerXAnchor),
            loadingView.centerYAnchor.constraint(equalTo: loadingViewBackground.centerYAnchor),
            loadingView.widthAnchor.constraint(greaterThanOrEqualToConstant: 50.0),
            loadingView.heightAnchor.constraint(greaterThanOrEqualToConstant: 50.0)
        ])
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
