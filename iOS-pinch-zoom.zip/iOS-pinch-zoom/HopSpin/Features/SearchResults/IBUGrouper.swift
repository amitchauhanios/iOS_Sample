//
//  IBUGrouper.swift
//  HopSpin
//
//  Created by Antonio Carella on 2/29/24.
//

import Foundation
import OrderedCollections

struct IBUGrouper {

    static func groupBeersByIBU(beers: [Beer], order: OrderOption) -> OrderedDictionary<String, [Beer]> {
        let ranges: OrderedDictionary<String, ClosedRange<Double>?> = [
                "0.0 – 14.9 IBU": 0.0...14.9,
                "15.0 – 29.9 IBU": 15.0...29.9,
                "30.0 – 44.9 IBU": 30.0...44.9,
                "45.0 – 59.9 IBU": 45.0...59.9,
                "60.0 – 74.9 IBU": 60.0...74.9,
                "75.0 – 89.9 IBU": 75.0...89.9,
                "90.0+ IBU": 90.0...Double.infinity,
                "(Not Listed)": nil
            ]
            
            var groupedBeers = OrderedDictionary<String, [Beer]>()
            
            for beer in beers {
                if let unwrapped = beer.ibu {
                    let ibu = Double(unwrapped)
                    var matched = false
                    for (rangeLabel, range) in ranges {
                        if range?.contains(ibu) ?? false {
                            groupedBeers[rangeLabel, default: []].append(beer)
                            matched = true
                            break
                        }
                    }
                    if !matched {
                        groupedBeers["Other IBU", default: []].append(beer)
                    }
                } else {
                    groupedBeers["(Not Listed)", default: []].append(beer)
                }
            }
        
        // alphabetize the arrays
        groupedBeers = groupedBeers.mapValues { itemArray in
            itemArray.sorted {
                $0.name.localizedStandardCompare($1.name) == .orderedAscending
            }
        }
        
        // Define the order of the keys based on the ranges dictionary
        let orderedKeys = Array(ranges.keys)

        // Sorting the dictionary based on the order option
        var sortedKeys: [String] = []
        if order.sortDirection == .ascending {
            sortedKeys = orderedKeys
        } else {
            sortedKeys = orderedKeys.reversed()
        }

        if let index = sortedKeys.firstIndex(of: "(Not Listed)") {
            sortedKeys.append(sortedKeys.remove(at: index))
        }
        
        var sortedGroupedBeers = OrderedDictionary<String, [Beer]>()
        for key in sortedKeys {
            sortedGroupedBeers[key] = groupedBeers[key]
        }
        
        return sortedGroupedBeers
    }
}
