//
//  BrewerySearchResultsViewController.swift
//  HopSpin
//
//  Created by Antonio Carella on 11/14/23.
//

import Combine
import OrderedCollections
import UIKit

class BrewerySearchResultsViewController: ListViewController {
    
    init(viewModel: BrewerySearchResultsListViewModel) {
        super.init(viewModel: viewModel)
        
        addRefreshControl(color: viewModel.activityIndicatorColor)
        
        self.listDataSource = ListItemsDataSource(tableView: self.tableView) { tableView, indexPath, listItem in

            guard let cell = tableView.dequeueReusableCell(withIdentifier: Self.cellId, for: indexPath) as? SearchResultsTableViewCell else {
                assertionFailure("Error dequeueing SearchResultsTableViewCell.")
                return UITableViewCell()
            }                        
            
            let backgroundView = UIView()
            backgroundView.backgroundColor = viewModel.cellSelectionColor
            cell.selectedBackgroundView = backgroundView
            
            cell.labelImageView.isHidden = true
            
            if let attributedText = listItem.attributedTitleText {
                cell.titleLabel.attributedText = attributedText
            } else {
                cell.titleLabel.text = listItem.titleText
            }
            
            cell.subTitleLabel.text = listItem.subtitleText
            listItem.isFinalRow ? cell.hideSeparator() : cell.showStandardSeparator()
            
            return cell
        }
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

