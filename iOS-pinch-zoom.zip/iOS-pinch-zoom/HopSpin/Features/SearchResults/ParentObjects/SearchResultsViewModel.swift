//
//  SearchResultsViewModel.swift
//  HopSpin
//
//  Created by Antonio Carella on 8/20/23.
//

import Combine
import Foundation
import OrderedCollections
import UIKit

class SearchResultsViewModel {
    
    var delegate: SearchResultSelectedHandler? {
        willSet {
            beerListViewModel.delegate = newValue
            beerGalleryViewModel.delegate = newValue
            breweryListViewModel.delegate = newValue
            artistListViewModel.delegate = newValue
        }
    }
    
    private static let countDisplayDelay: Double = 0.125
    private var subscriptions = Set<AnyCancellable>()
    private(set) var selectedIndex: Int
    
    let beerListViewModel: BeerListViewModel
    let beerGalleryViewModel: BeerGalleryTableViewModel
    let breweryListViewModel: BrewerySearchResultsListViewModel
    let artistListViewModel: ArtistSearchResultsListViewModel
    
    // Pass these to ViewModels to observe filter changes
    // We have one per model type (ie, not per view) on purpose.
    // We want the beers filters to apply to both gallery and list views
    private let beerFilters = CurrentValueSubject<FilterParamOption, Never>(.initial)
    private let breweryFilters = CurrentValueSubject<FilterParamOption, Never>(.initial)
    private let artistFilters = CurrentValueSubject<FilterParamOption, Never>(.initial)
    
    private let beerSorting = CurrentValueSubject<(OrderOption, BeerSortingOption), Never>((.ascending, .name))
    private let brewerySorting = CurrentValueSubject<(OrderOption, BrewerySortingOption), Never>((.ascending, .name))
    private let artistSorting = CurrentValueSubject<(OrderOption, ArtistSortingOption), Never>((.ascending, .name))
    
    let searchTermSubject: CurrentValueSubject<String, Never>
    
    var resultsViewPublisher: AnyPublisher<DiscoveryView, Never> {
        resultsViewSubject.eraseToAnyPublisher()
    }
    
    private var resultsViewSubject = CurrentValueSubject<DiscoveryView, Never>(.beerList)
    private let viewSegementStateFilterSubject: CurrentValueSubject<ViewSegementState, Never>
    private let beerViewSegementStateFilterSubject = CurrentValueSubject<BeerViewSegmentState, Never>(BeerViewSegmentState.gallery)
    
    init(
        searchResultsProvider: SearchResultsProvider,
        searchTerm: String,
        imageRepository: ImageRepository,
        selectedIndex: Int
    ) {
        self.searchTermSubject = CurrentValueSubject<String, Never>(searchTerm)
        self.selectedIndex = selectedIndex
        
        let view: ViewSegementState
        switch selectedIndex {
        case 0: view = .beer
        case 1: view = .brewery
        case 2: view = .artist
        default: view = .beer
        }
        
        self.viewSegementStateFilterSubject = CurrentValueSubject<ViewSegementState, Never>(view)
        let sharedBeerDataFetcher = BeerDataFetcher(apiClient: .live)
        
        self.beerListViewModel = .init(
            dataFetcher: sharedBeerDataFetcher,
            searchTerm: searchTermSubject,
            filters: beerFilters,
            sorting: beerSorting,
            imageRepository: imageRepository
        )
        
        self.beerGalleryViewModel = .init(
            dataFetcher: sharedBeerDataFetcher,
            searchTerm: searchTermSubject,
            filters: beerFilters,
            sorting: beerSorting,
            imageRepository: imageRepository
        )
        
        self.breweryListViewModel = .init(
            dataFetcher: .init(),
            searchTerm: searchTermSubject,
            filters: breweryFilters,
            sorting: brewerySorting
        )
        
        self.artistListViewModel = .init(
            dataFetcher: .init(),
            searchTerm: searchTermSubject,
            filters: artistFilters,
            sorting: artistSorting
        )
        
        bind()
    }
    
    private func bind() {
        Publishers
            .CombineLatest(
                viewSegementStateFilterSubject,
                beerViewSegementStateFilterSubject
            )
            .map { viewSegment, beerViewSegment -> DiscoveryView in
                switch viewSegment {
                case .beer:
                    switch beerViewSegment {
                    case .list:
                        return .beerList
                    case .gallery:
                        return .beerGallery
                    }
                case .brewery:
                    return .brewery
                case .artist:
                    return .artist
                }
            }
            .removeDuplicates()
            .sink { [weak self] in
                self?.resultsViewSubject.send($0)
            }
            .store(in: &subscriptions)
        
        viewSegementStateFilterSubject
            .receive(on: DispatchQueue.main)
            .removeDuplicates()
            .sink { [weak self] _ in
                //self?.selectedFilters.send([])
            }
            .store(in: &subscriptions)
    }
    
    func beerSegmentedTapped() {
        viewSegementStateFilterSubject.send(.beer)
    }
    
    func brewerySegmentedTapped() {
        viewSegementStateFilterSubject.send(.brewery)
    }
    
    func artistSegmentedTapped() {
        viewSegementStateFilterSubject.send(.artist)
    }
    
    func gallerySegmentTapped() {
        beerViewSegementStateFilterSubject.send(.gallery)
    }
    
    func listSegmentTapped() {
        beerViewSegementStateFilterSubject.send(.list)
    }
    
    func filtersTapped() {
        let filterSnapshot: OrderedDictionary<String, [FilterParam]>
        let selectedFiltersSubject: CurrentValueSubject<FilterParamOption, Never>
        let flattenedFilteringParams: [FilterParam]
        switch viewSegementStateFilterSubject.value {
        case .beer:
            flattenedFilteringParams = beerListViewModel.filteringParamsSnapshot.value
            filterSnapshot = BeerFilteringParameterGrouper.group(filterParams: flattenedFilteringParams)
            selectedFiltersSubject = beerFilters
        case .brewery:
            selectedFiltersSubject = breweryFilters
            flattenedFilteringParams = breweryListViewModel.filteringParamsSnapshot.value
            filterSnapshot = BreweryFilteringParameterGrouper.group(filterParams: flattenedFilteringParams)
        case .artist:
            flattenedFilteringParams = artistListViewModel.filteringParamsSnapshot.value
            filterSnapshot = ArtistFilteringParameterGrouper.group(filterParams: flattenedFilteringParams)
            selectedFiltersSubject = artistFilters
        }
        
        delegate?.navigateToFilters(
            filterSnapshot,
            selected: selectedFiltersSubject.value,
            tintColor: Colors.darkGreen,
            offset: 100.0,
            applyFiltersHandler: { filters in
            if filters.isEmpty {
                selectedFiltersSubject.send(.none)
            } else if filters.count == filterSnapshot.reduce(0, { $0 + $1.value.count }) {
                selectedFiltersSubject.send(.all)
            } else {
                selectedFiltersSubject.send(.some(filters))
            }
        })
    }
    
    func sortingTapped() {
        let sortingOptions: [String]
        let selectedSorting: (OrderOption, String)
        let view = viewSegementStateFilterSubject.value
        switch view {
        case .beer:
            sortingOptions = BeerSortingOption.sortedTitles
            let selectSortingOption = beerSorting.value.1
            selectedSorting = (beerSorting.value.0, (selectSortingOption).title)
        case .brewery:
            sortingOptions = BrewerySortingOption.sortedTitles
            let selectSortingOption = brewerySorting.value.1
            selectedSorting = (brewerySorting.value.0, (selectSortingOption).title)
        case .artist:
            sortingOptions = ArtistSortingOption.allCases.map { $0.title }
            let selectSortingOption = artistSorting.value.1
            selectedSorting = (artistSorting.value.0, (selectSortingOption).title)
        }
        
        delegate?.navigateToSorting(
            sortingOptions,
            selected: selectedSorting,
            applySortingHandler: { [weak self] sortingOptions in
                guard let self else { return }
                switch view {
                case .beer:
                    let sortOption = BeerSortingOption(title: sortingOptions.1)
                    self.beerSorting.send((sortingOptions.0, sortOption))
                case .brewery:
                    let sortOption = BrewerySortingOption(title: sortingOptions.1)
                    self.brewerySorting.send((sortingOptions.0, sortOption))
                case .artist:
                    let sortOption = ArtistSortingOption(title: sortingOptions.1)
                    self.artistSorting.send((sortingOptions.0, sortOption))
                }
            })
    }
}

extension SearchResultsViewModel {
    enum ViewSegementState {
        case beer, brewery, artist
    }
}

enum ViewSegementState {
    case beer, brewery, artist
}

enum BeerViewSegmentState {
    case gallery, list
}

extension Publisher where Output: Hashable {
    func removeLifetimeDuplicates() -> AnyPublisher<Output, Failure> {
        return scan((Set<Output>(), nil)) { (state, newValue) -> (Set<Output>, Output?) in
            var (seenValues, _) = state
            if !seenValues.contains(newValue) {
                seenValues.insert(newValue)
                return (seenValues, newValue)
            } else {
                return (seenValues, nil)
            }
        }
        .compactMap { $0.1 }
        .eraseToAnyPublisher()
    }
}

