//
//  SearchResultsViewController.swift
//  HopSpin
//
//  Created by Antonio Carella on 8/20/23.
//

import Combine
import UIKit
import OrderedCollections

final class SearchResultsViewController: UIViewController {
    
    private var beerListView: UIView!
    private var beerGalleryView: UIView!
    private var breweryView: UIView!
    private var artistView: UIView!
    
    // MARK: Combine
    private var subscriptions = Set<AnyCancellable>()
    
    // MARK: Dependencies
    private let viewModel: SearchResultsViewModel
    
    // MARK: UI
    private lazy var searchControlBar = SearchControlBar(        
        config: .searchResultsView
    )
    
    // MARK: Lifecycle
    init(viewModel: SearchResultsViewModel) {
        self.viewModel = viewModel
        super.init(nibName: nil, bundle: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.beerListView = addChildViewController(
            BeerListViewController(
                viewModel: viewModel.beerListViewModel
            )
        )
        
        self.beerGalleryView = addChildViewController(
            GalleryTableViewController(
                viewModel: viewModel.beerGalleryViewModel
            )
        )
        
        self.breweryView = addChildViewController(
            BrewerySearchResultsViewController(
                viewModel: viewModel.breweryListViewModel
            )
        )
        
        self.artistView = addChildViewController(
            ArtistSearchResultsViewController(
                viewModel: viewModel.artistListViewModel
            )
        )
        
        bindSelf()
        bindViewModel()
        constrainViews()
        searchControlBar.filterSegmentedControl.selectedSegmentIndex = viewModel.selectedIndex
        searchControlBar.setGalleryOrListSegmentedControl(hidden: viewModel.selectedIndex != 0)
    }
    
    private func bindViewModel() {
        viewModel
            .resultsViewPublisher
            .receive(on: DispatchQueue.main)
            .sink(receiveValue: updateView(for:))
            .store(in: &subscriptions)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func bindSelf() {
        
        searchControlBar
            .filterButtonTap
            .receive(on: DispatchQueue.main)
            .sink { [viewModel] index in
                viewModel.filtersTapped()
            }
            .store(in: &subscriptions)
        
        searchControlBar
            .sortButtonTap
            .receive(on: DispatchQueue.main)
            .sink { [viewModel] index in
                viewModel.sortingTapped()
            }
            .store(in: &subscriptions)
        
        searchControlBar
            .filterSegmentTap
            .receive(on: DispatchQueue.main)
            .sink { [viewModel] index in
                switch index {
                case 0:
                    viewModel.beerSegmentedTapped()
                case 1:
                    viewModel.brewerySegmentedTapped()
                case 2:
                    viewModel.artistSegmentedTapped()
                default:
                    assertionFailure("Tap not handled")
                }
            }
            .store(in: &subscriptions)
        
        searchControlBar
            .galleryTap
            .receive(on: DispatchQueue.main)
            .sink { [viewModel] index in
                switch index {
                case 0:
                    viewModel.gallerySegmentTapped()
                case 1:
                    viewModel.listSegmentTapped()
                default:
                    assertionFailure("Tap not handled")
                }
            }
            .store(in: &subscriptions)
    }
        
    private func constrainViews() {
        
        searchControlBar.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(searchControlBar)
        
        NSLayoutConstraint.activate([
            searchControlBar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            searchControlBar.topAnchor.constraint(equalTo: view.topAnchor),
            searchControlBar.trailingAnchor.constraint(equalTo: view.trailingAnchor)
        ])
        
        [beerListView, beerGalleryView, breweryView, artistView].forEach { childView in
            childView.translatesAutoresizingMaskIntoConstraints = false
            NSLayoutConstraint.activate([
                childView.topAnchor.constraint(equalTo: searchControlBar.bottomAnchor),
                childView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
                childView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
                childView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            ])
        }
    }
    
    private func updateView(for resultsView: DiscoveryView) {        
        switch resultsView {
        case .beerGallery:
            view.bringSubviewToFront(beerGalleryView)
        case .beerList:
            view.bringSubviewToFront(beerListView)
        case .brewery:
            view.bringSubviewToFront(breweryView)
        case .artist:
            view.bringSubviewToFront(artistView)
        }
    }
}
