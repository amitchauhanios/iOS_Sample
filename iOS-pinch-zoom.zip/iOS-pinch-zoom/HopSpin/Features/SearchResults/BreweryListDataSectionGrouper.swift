//
//  BreweryListDataSectionGrouper.swift
//  HopSpin
//
//  Created by Antonio Carella on 11/28/23.
//

import Foundation
import OrderedCollections

struct BreweryListDataSectionGrouper {
    static func group(items: [Brewery], sortingOption: BrewerySortingOption, orderOption: OrderOption) -> OrderedCollections.OrderedDictionary<String, [Brewery]> {
        switch sortingOption {
        case .classification:
            return groupBreweries(breweries: items, by: \.classification, orderOption: orderOption) { keys in
                let ordering = [
                    "Macro Brewery",
                    "Regional Brewery",
                    "Micro Brewery",
                    "Nano Brewery",
                    "Pico Brewery",
                    "Home Brewery"
                ]

                return keys.sorted {
                    guard let first = ordering.firstIndex(of: $0),
                          let second = ordering.firstIndex(of: $1)
                    else {
                        return false
                    }
                    return orderOption == .descending ? first < second : first > second
                }
            }
        case .distinctBeers:
            let grouped = groupBreweries(breweries: items, by: \.distinctBeers, orderOption: orderOption)
            return GenericGrouper.groupNumericResult(grouped: grouped, orderOption: orderOption) { key in
                if key == "0" {
                    return "(Not Listed)"
                } else if key == "1" {
                    return "\(key) Beer"
                } else {
                    return "\(key) Beers"
                }
            }
        case .distinctDistributionStates:
            let grouped = groupBreweries(breweries: items, by: \.distinctDistributionStates, orderOption: orderOption)
            return GenericGrouper.groupNumericResult(grouped: grouped, orderOption: orderOption) { key in
                if key == "0" {
                    return "(Not Listed)"
                } else if key == "1" {
                    return "\(key) Distribution State"
                } else {
                    return "\(key) Distribution States"
                }
            }
        case .distributionState:
            return GenericGrouper.groupItems(
                items: items,
                by: \.distributionState,
                orderOption: orderOption,
                keepsNullOptionAtBottom: true
            )
        case .distinctLocations:
            let grouped = groupBreweries(breweries: items, by: \.distinctLocations, orderOption: orderOption)
            return GenericGrouper.groupNumericResult(grouped: grouped, orderOption: orderOption) { key in
                if key == "0" {
                    return "(Not Listed)"
                } else if key == "1" {
                    return "\(key) Location"
                } else {
                    return "\(key) Locations"
                }
            }
        case .distinctShippingStates:
            let grouped = groupBreweries(breweries: items, by: \.distinctShippingStates, orderOption: orderOption)
            return GenericGrouper.groupNumericResult(grouped: grouped, orderOption: orderOption) { key in
                if key == "0" {
                    return "0 Shipping States"
                } else if key == "1" {
                    return "\(key) Shipping State"
                } else {
                    return "\(key) Shipping States"
                }
            }
        case .datePubliclyViewable:
            return DatePubliclyViewableGrouper<Brewery>.group(items: items, by: orderOption)
        case .locationState:
            return groupBreweries(breweries: items, by: \.locationState, orderOption: orderOption)
        case .name:
            return NameGrouper<Brewery>.group(items: items, by: orderOption)
        case .shippingState:
            return GenericGrouper.groupItems(
                items: items,
                by: \.shippingState,
                orderOption: orderOption,
                replaceNilKeyWith: "(Does Not Ship)",
                keepsNullOptionAtBottom: true
            )
        case .yearFounded:
            return groupBreweries(breweries: items, by: \.yearFounded, orderOption: orderOption)
        }
    }
    
    private static func groupBreweries<T: Hashable>(
        breweries: [Brewery],
        by keyPath: KeyPath<Brewery, T>,
        shouldSortResultsAlpha: Bool = true,
        orderOption: OrderOption,
        customSorting: (([String]) -> [String])? = nil
    ) -> OrderedDictionary<String, [Brewery]> {
        var grouped: [String: [Brewery]] = [:]

        for brewery in breweries {
            if let array = brewery[keyPath: keyPath] as? [String] {
                // If the keyPath is an array of strings, group under each element
                for element in array {
                    grouped[element, default: []].append(brewery)
                }
            } else {
                // Otherwise, treat it as a single string
                let key = "\(brewery[keyPath: keyPath])"
                grouped[key, default: []].append(brewery)
            }
        }

        // Sort the breweries alphabetically within their secions,
        // if asked to
        if shouldSortResultsAlpha {
            grouped = grouped.mapValues { breweryArray in
                breweryArray.sorted {
                    $0.name.localizedStandardCompare($1.name) == .orderedAscending
                }
            }
        }

        let orderedKeys: [String]
        // If there's a custom sort from the calling code, then us it
        if let customSorting {
            orderedKeys = customSorting(Array(grouped.keys))
        } else {
            // If not, just sort by alpha
           orderedKeys = grouped.keys.sorted {
                if orderOption == .ascending {
                    $0.localizedStandardCompare($1) == .orderedAscending
                } else {
                    $0.localizedStandardCompare($1) == .orderedDescending
                }
            }
        }
        var orderedDict = OrderedDictionary<String, [Brewery]>()

        for key in orderedKeys {
            orderedDict[key] = grouped[key]
        }

        return orderedDict
    }

}

struct DatePubliclyViewableGrouper<Item: DatePubliclyViewable> {
    
    static func group(items: [Item], by orderOption: OrderOption) -> OrderedDictionary<String, [Item]> {
        let key = orderOption == .ascending ?
        "Oldest Additions" : "Newest Additions"
        return OrderedDictionary(dictionaryLiteral: (key, items))
    }
    
}
