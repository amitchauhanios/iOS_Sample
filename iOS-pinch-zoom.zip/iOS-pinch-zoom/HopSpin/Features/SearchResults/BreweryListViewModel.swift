//
//  BreweryListViewModel.swift
//  HopSpin
//
//  Created by Antonio Carella on 11/14/23.
//

import Combine
import OrderedCollections
import Foundation

class BrewerySearchResultsListViewModel: GenericListViewModel<Brewery, BreweryListDataProcessor, BreweryDataFetcher, BrewerySortingOption> {
    
    override func itemSelected(at indexPath: IndexPath) {
        let key = itemsSubject.value.orderedDict.keys[indexPath.section]
        
        if let array = itemsSubject.value.orderedDict[key],
           let item = array.first(where: { $0.id == array[indexPath.row].id }),
           let brewery = items.first(where: { UUIDHandler.compare(id: $0.id, salted: item.id) }) {
            delegate?.navigateToBrewery(brewery)
        } else {
            self.errorMessageSubject.send(
                .unknown
            )
        }
    }
}
    
class BreweryDataFetcher: DataFetcherProtocol {    
    typealias ItemType = Brewery
    
    private let apiClient: ApiClient
    
    
    init(apiClient: ApiClient = .live) {
        self.apiClient = apiClient
    }
    
    func fetchItems(
        searchTerm: String,
        filters: FiltersAndOperator,
        sorting: (OrderOption, BrewerySortingOption)
    ) async throws -> [Brewery] {
        let search = BrewerySearch(
            name: searchTerm,
            filters: filters,
            sortOption: sorting.1,
            sortDirection: sorting.0.sortDirection
        )
        return try await apiClient.brewerySearch(search)
    }
}

struct BreweryListDataProcessor: ListDataProcessorProtocol {
    typealias SortingOption = BrewerySortingOption
    typealias ItemType = Brewery
    
    static func process(
        items: [Brewery],
        searchTerm: String,
        orderOption: OrderOption, 
        sortingOption: BrewerySortingOption
    ) -> OrderedCollections.OrderedDictionary<String, [SearchListItem]> {

        let grouped = BreweryListDataSectionGrouper.group(items: items, sortingOption: sortingOption , orderOption: orderOption)
        
        return grouped.mapValues { breweryArray in
            breweryArray.enumerated().map { brewery in
                SearchListItem
                    .breweryListItem(
                        brewery: brewery.element,
                        searchTerm: searchTerm,
                        isFinalRow: brewery.offset == breweryArray.count - 1
                    )
            }
        }
    }
}

// Consider: replacing other filters with this generic one
struct ItemFilterer<Item: FilteringParamsProtocol> {
    static func filter(items: [Item], selectedFilters: [FilterParam]) -> [Item] {
        items
            .filter {
            let filteringParamsSet = Set($0.filteringParams)
            let result = filteringParamsSet.intersection(selectedFilters)
            return selectedFilters.isEmpty ? true : !result.isEmpty
        }
    }
}
