//
//  SearchResultsProvider.swift
//  HopSpin
//
//  Created by Antonio Carella on 8/20/23.
//

import Foundation

struct SearchResultsProvider {
    
    private static let apiClient: ApiClient = .live
    
    var beerResultsFor: (String) async throws -> [Beer]
    var breweryResultsFor: (String) async throws -> [Brewery]
    var artistResultsFor: (String) async throws -> [Artist]
    var brewery: (Int) async throws -> BreweryDetail
    var discoveryBeers: () async throws -> [Beer]
    var discoveryBreweries: () async throws -> [Brewery]
    var discoveryArtists: () async throws -> [Artist]
}

extension SearchResultsProvider {
    static let live: SearchResultsProvider = .init(
        beerResultsFor: { (searchTerm) in
            try await Self.apiClient
                .beers()
                .filter {
                    $0.name.lowercased().contains(searchTerm.lowercased())
                }
        },
        breweryResultsFor:  { (searchTerm) in
            try await Self.apiClient
                .breweries()
                .filter {
                    $0.name.lowercased().contains(searchTerm.lowercased())
                }
        },
        artistResultsFor:  { (searchTerm) in
            try await Self.apiClient
                .artists()
                .filter {
                    $0.name.lowercased().contains(searchTerm.lowercased())
                }
        },
        brewery: { (id) in
            try await Self.apiClient
                .brewery(id)                
        }, discoveryBeers: {
            try await Self.apiClient
                .beers()
        }, discoveryBreweries: {
            try await Self.apiClient
                .breweries()
        }, discoveryArtists: {
            try await Self.apiClient
                .artists()
        }
    )
}
