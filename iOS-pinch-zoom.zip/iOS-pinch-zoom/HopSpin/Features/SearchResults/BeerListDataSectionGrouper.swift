//
//  BeerListDataSectionGrouper.swift
//  HopSpin
//
//  Created by Antonio Carella on 11/28/23.
//

import Foundation
import OrderedCollections

/// Object responsible for grouping an array of Beers according to the BeerSortingOption passed to the server
struct BeerListDataSectionGrouper {
    
    func group(items: [Beer], sortingOption: BeerSortingOption, orderOption: OrderOption) -> OrderedCollections.OrderedDictionary<String, [Beer]> {
        switch sortingOption {
        case .abv:
            return ABVGrouper.groupBeersByABV(beers: items, order: orderOption)
            
        case .distinctAdjuncts:
            let grouped = GenericGrouper.groupItems(items: items, by: \.distinctAdjuncts, orderOption: orderOption)
            return GenericGrouper.groupNumericResult(grouped: grouped, orderOption: orderOption) { key in
                    if key == "0" {
                        return "0 Adjuncts"
                    } else if key == "1" {
                        return "\(key) Adjunct"
                    } else {
                        return "\(key) Adjuncts"
                    }
            }
        case .distinctAwards:
            let grouped = GenericGrouper.groupItems(items: items, by: \.distinctAwards, orderOption: orderOption)
            return GenericGrouper.groupNumericResult(grouped: grouped, orderOption: orderOption) { key in
                if key == "0" {
                    return "0 Awards"
                } else if key == "1" {
                    return "\(key) Award"
                } else {
                    return "\(key) Awards"
                }
            }
        case .distinctHops:
            let grouped = GenericGrouper.groupItems(items: items, by: \.distinctHops, orderOption: orderOption)
            return GenericGrouper.groupNumericResult(grouped: grouped, orderOption: orderOption, keepsZeroOptionAtBottom: true) { key in
                if key == "0" {
                    return "(Not Listed)"
                } else if key == "1" {
                    return "\(key) Hop"
                } else {
                    return "\(key) Hops"
                }
            }
        case .distinctBrandings:
            let grouped = GenericGrouper.groupItems(items: items, by: \.distinctBrandings, orderOption: orderOption)
            return GenericGrouper.groupNumericResult(grouped: grouped, orderOption: orderOption) { key in
                if key == "0" {
                    return "(Not Listed)"
                } else if key == "1" {
                    return "\(key) Label"
                } else {
                    return "\(key) Labels"
                }
            }
        case .styles:
            return GenericGrouper.groupItems(items: items, by: \.styles, orderOption: orderOption)
        case .datePubliclyViewable:
            return DatePubliclyViewableGrouper<Beer>.group(items: items, by: orderOption)
        case .ibu:
            return IBUGrouper.groupBeersByIBU(beers: items, order: orderOption)
        case .name:
            return NameGrouper<Beer>.group(items: items, by: orderOption)
        case .pourColor:
            return GenericGrouper.groupItems(
                items: items,
                by: \.pourColor,
                orderOption: orderOption,
                keepsNullOptionAtBottom: true
            ) { keys in
                var sorted = keys.sorted(by: {
                    guard let first = Beer.pourColorOrder.firstIndex(of: $0),
                          let second = Beer.pourColorOrder.firstIndex(of: $1)
                    else {
                        return false
                    }
                    return orderOption == .descending ? first > second : first < second
                })
                
                if let nilIndex = sorted.firstIndex(of: "nil") {
                    let nilValue = sorted.remove(at: nilIndex)
                    sorted.append(nilValue)
                }
                
                return sorted
            }
        case .primaryLabelColor:
            return GenericGrouper.groupItems(items: items, by: \.labelColor1IsFeatured, orderOption: orderOption) { keys in
                return keys.sorted(by: {
                    guard let first = Beer.labelColorOrdering.firstIndex(of: $0),
                          let second = Beer.labelColorOrdering.firstIndex(of: $1)
                    else {
                        return false
                    }
                    return orderOption == .descending ? first > second : first < second
                })
            }
        case .yearFirstReleased:
            return GenericGrouper.groupItems(
                items: items,
                by: \.yearFirstReleased,
                orderOption: orderOption,
                keepsNullOptionAtBottom: true
            )
        case .yearLastReleased:
            return GenericGrouper.groupItems(
                items: items,
                by: \.yearLastReleased,
                orderOption: orderOption,
                keepsNullOptionAtBottom: true
            )
        case .labelStyle:
            return GenericGrouper.groupItems(items: items, by: \.labelStyle, orderOption: orderOption)
        case .adjunct:
            return GenericGrouper.groupItems(items: items, by: \.adjuncts, orderOption: orderOption, replaceNilKeyWith: "(No Adjuncts)", keepsNullOptionAtBottom: true)
        case .artist:
            return GenericGrouper.groupItems(items: items, by: \.collabDesigners, orderOption: orderOption, replaceNilKeyWith: "(In-House)", keepsNullOptionAtBottom: true)
        case .award:
            return GenericGrouper.groupItems(items: items, by: \.awards, orderOption: orderOption, replaceNilKeyWith: "(No Awards)", keepsNullOptionAtBottom: true)
        case .brewery:
            return GenericGrouper.groupItems(items: items, by: [\Beer.brewery, \Beer.collabBreweries], orderOption: orderOption)
        case .brewerySeries:
            return GenericGrouper.groupItems(items: items, by: \.brewerySeries, orderOption: orderOption, replaceNilKeyWith: "(No Brewery Series)", keepsNullOptionAtBottom: true)
        case .hop:
            return GenericGrouper.groupItems(items: items, by: \.hops, orderOption: orderOption, replaceNilKeyWith: "(Not Listed)", keepsNullOptionAtBottom: true)
        case .nonindustryCollab:
            return GenericGrouper.groupItems(items: items, by: \.collabNonindustries, orderOption: orderOption, replaceNilKeyWith: "(No Nonindustry Collabs)", keepsNullOptionAtBottom: true)
        case .releaseYear:
            return GenericGrouper.groupItems(
                items: items,
                by: \.releaseYear,
                orderOption: orderOption
            )
        }
    }
    
    private func groupBeers<T: Hashable>(
        beers: [Beer],
        by keyPath: KeyPath<Beer, T>
    ) -> OrderedDictionary<String, [Beer]> {
        let groupedBeers = Dictionary(grouping: beers, by: { "\($0[keyPath: keyPath])" })

        var orderedKeys = [String]()
        for beer in beers {
            let key = "\(beer[keyPath: keyPath])"
            if !orderedKeys.contains(key) {
                orderedKeys.append(key)
            }
        }

        var orderedDict = OrderedDictionary<String, [Beer]>()
        for key in orderedKeys {
            orderedDict[key] = groupedBeers[key]
        }

        return orderedDict
    }
    
    private static func modifyKeys(dict: OrderedDictionary<String, [Beer]>, keyModifier: (String) -> String) -> OrderedDictionary<String, [Beer]>{
        var modifiedDict = OrderedDictionary<String, [Beer]>()
        for (key, value) in dict {
            let modifiedKey = keyModifier(key)
            modifiedDict[modifiedKey] = value
        }
        
        return modifiedDict
    }
}
