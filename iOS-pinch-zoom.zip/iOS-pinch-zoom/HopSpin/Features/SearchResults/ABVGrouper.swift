//
//  ABVGrouper.swift
//  HopSpin
//
//  Created by Antonio Carella on 2/29/24.
//

import Foundation
import OrderedCollections

struct ABVGrouper {
    
    static func groupBeersByABV(beers: [Beer], order: OrderOption) -> OrderedDictionary<String, [Beer]> {
        let ranges: OrderedDictionary<String, ClosedRange<Double>?> = [
            "0.0 – 2.9 ABV %": 0.0...2.9,
            "3.0 – 5.9 ABV %": 3.0...5.9,
            "6.0 – 8.9 ABV %": 6.0...8.9,
            "9.0 – 11.9 ABV %": 9.0...11.9,
            "12.0 – 14.9 ABV %": 12.0...14.9,
            "15.0 – 17.9 ABV %": 15.0...17.9,
            "18.0 – 20.9 ABV %": 18.0...20.9,
            "21.0+ ABV %": 21.0...Double.infinity,
            "(Not Listed)": nil  // Added here for initial grouping
        ]
        
        var groupedBeers = OrderedDictionary<String, [Beer]>()
        
        for beer in beers {
            if let abv = beer.abv {
                var matched = false
                for (rangeLabel, range) in ranges {
                    if range?.contains(abv) ?? false {
                        groupedBeers[rangeLabel, default: []].append(beer)
                        matched = true
                        break
                    }
                }
                if !matched {
                    groupedBeers["Other ABV %", default: []].append(beer)
                }
            } else {
                groupedBeers["(Not Listed)", default: []].append(beer)
            }
        }
        
        // alphabetize the arrays
        groupedBeers = groupedBeers.mapValues { itemArray in
            itemArray.sorted {
                $0.name.localizedStandardCompare($1.name) == .orderedAscending
            }
        }
        
        // Define the order of the keys based on the ranges dictionary
        let orderedKeys = Array(ranges.keys)

        // Sorting the dictionary based on the order option
        var sortedKeys: [String] = []
        if order.sortDirection == .ascending {
            sortedKeys = orderedKeys
        } else {
            sortedKeys = orderedKeys.reversed()
        }

        if let index = sortedKeys.firstIndex(of: "(Not Listed)") {
            sortedKeys.append(sortedKeys.remove(at: index))
        }
        
        var sortedGroupedBeers = OrderedDictionary<String, [Beer]>()
        for key in sortedKeys {
            sortedGroupedBeers[key] = groupedBeers[key]
        }
        
        return sortedGroupedBeers
    }
}
