//
//  SearchResult.swift
//  HopSpin
//
//  Created by Antonio Carella on 8/24/23.
//

import Foundation

struct SearchListItem: Identifiable, Hashable, Equatable {
    let id: String
    let titleText: String
    let subtitleText: String
    let attributedTitleText: NSMutableAttributedString?
    let labelImageURLPath: String?
    let isFinalRow: Bool
}

extension SearchListItem {
    static func beerListItem(beer: Beer, searchTerm: String?, isFinalRow: Bool) -> SearchListItem {
        let attrStr: NSMutableAttributedString? = if let searchTerm {
            StyleKit.bold(
                searchText: searchTerm.replacingApostropheWithQuote,
                in: beer.name,
                fontSize: 17.0
            )
        } else {
            nil
        }
        
        let id = UUIDHandler.salt(id: "\(beer.id)")
        
        return SearchListItem(
            id: id,
            titleText: beer.name, 
            subtitleText: beer.brewery,
            attributedTitleText: attrStr,
            labelImageURLPath: beer.featuredAvatar,
            isFinalRow: isFinalRow
        )
    }
}

extension SearchListItem {
    static func beerCellarListItem(beer: Beer, searchTerm: String?, isFinalRow: Bool) -> SearchListItem {
        let attrStr: NSMutableAttributedString? = if let searchTerm {
            StyleKit.bold(
                searchText: searchTerm.replacingApostropheWithQuote,
                in: beer.name,
                fontSize: 17.0
            )
        } else {
            nil
        }
        
        let beerCount = beer.styles.count - 1
        let subtitleText: String
        if let firstStyle = beer.styles.first {
            if beerCount > 0 {
                subtitleText = "\(firstStyle) (+\(beerCount))"
            } else {
                subtitleText = firstStyle
            }
        } else {
            subtitleText = ""
        }
         
        let id = UUIDHandler.salt(id: "\(beer.id)")
        
        return SearchListItem(
            id: id,
            titleText: beer.name,
            subtitleText: subtitleText,
            attributedTitleText: attrStr,
            labelImageURLPath: beer.featuredAvatar, 
            isFinalRow: isFinalRow
        )
    }
}

extension SearchListItem {
    static func breweryListItem(brewery: Brewery, searchTerm: String?, isFinalRow: Bool) -> SearchListItem {
        let attrStr: NSMutableAttributedString? = if let searchTerm {
            StyleKit.bold(
                searchText: searchTerm,
                in: brewery.name,
                fontSize: 17.0
            )
        } else {
            nil
        }
        
        let id = UUIDHandler.salt(id: "\(brewery.id)")
        
        return SearchListItem(
            id: id,
            titleText: brewery.name,
            subtitleText: "\(brewery.homeCity), \(brewery.homeState)",
            attributedTitleText: attrStr,
            labelImageURLPath: nil,
            isFinalRow: isFinalRow
        )
        
    }
}

extension SearchListItem {
    static func artistListItem(artist: Artist, searchTerm: String?, isFinalRow: Bool) -> SearchListItem {
        let attrStr: NSMutableAttributedString? = if let searchTerm {
            StyleKit.bold(
                searchText: searchTerm,
                in: artist.name,
                fontSize: 17.0
            )
        } else {
            nil
        }
        
        let id = UUIDHandler.salt(id: "\(artist.id)")
        
        return SearchListItem(
            id: id,
            titleText: artist.name,
            subtitleText: "\(artist.homeCity), \(artist.homeState)",
            attributedTitleText: attrStr,
            labelImageURLPath: nil,
            isFinalRow: isFinalRow
        )
    }
}

extension SearchListItem {
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(self.id)
    }
    
    static func == (lhs: Self, rhs: Self) -> Bool {
        lhs.id == rhs.id
    }
}

struct GalleryItem: Identifiable, Hashable, Equatable {
    
    // So we can identify which beer was tapped
    struct UrlAndId {
        let url: String
        let id: String
    }
    
    var id: String
    let labelURLsAndIds: [UrlAndId]
    
    init(labelURLsAndIds: [UrlAndId]) {
        self.labelURLsAndIds = labelURLsAndIds
        self.id = labelURLsAndIds.map(\.id).joined()
    }
}

extension GalleryItem {
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(self.id)
    }
    
    static func == (lhs: Self, rhs: Self) -> Bool {
        lhs.id == rhs.id
    }
}

/// Object responsible for creating and deciphering UUIDs based on server Ids
///  Creating a UUID that salts a server ID solves for the case where we want to display
///  more than one server Object in a diffable datasource at one time. Salting
///  allows us to display multiple instances and still keep thier Identifiable Ids unique
struct UUIDHandler {
    
    static func salt(id: String) -> String {
        "\(id)-salt-\(UUID().uuidString)"
    }
    
    static func deciper(id: String) -> String {
        id.components(separatedBy: "-salt-").first ?? id
    }
    
    static func compare(id: Int, salted: String) -> Bool {
        let strId = "\(id)"
        let deciphered = Self.deciper(id: salted)
        
        return strId == deciphered
    }
}
