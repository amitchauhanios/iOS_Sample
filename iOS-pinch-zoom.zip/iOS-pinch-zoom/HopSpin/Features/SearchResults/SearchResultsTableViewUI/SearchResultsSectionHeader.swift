//
//  SectionHeader.swift
//  HopSpin
//
//  Created by Antonio Carella on 8/22/23.
//

import UIKit

class SearchResultsSectionHeader: UITableViewHeaderFooterView {
    
    lazy var label: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 17.0, weight: .semibold)
        label.textColor = .black
        return label
    }()
    
    private lazy var separator: UIView = {
        let view = UIView()
        view.backgroundColor = .black
        return view
    }()
    
    override init(reuseIdentifier: String?) {
        super.init(reuseIdentifier: reuseIdentifier)
        layout()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func layout() {
        
        contentView.addSubview(label)
        label.translatesAutoresizingMaskIntoConstraints = false
        
        addSubview(separator)
        separator.translatesAutoresizingMaskIntoConstraints = false
        
        let labelLeading = label.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16.0)
        labelLeading.priority = UILayoutPriority(999.0)
        
        NSLayoutConstraint.activate([
            labelLeading,
            label.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -8.0),
            label.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16.0),
            separator.heightAnchor.constraint(equalToConstant: 0.5),
            separator.bottomAnchor.constraint(equalTo: bottomAnchor),
            separator.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 16.0),
            separator.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -16.0)
        ])
    }
}
