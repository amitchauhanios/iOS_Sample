//
//  SearchResultsTableViewCell.swift
//  HopSpin
//
//  Created by Antonio Carella on 8/20/23.
//

import UIKit

class SearchResultsTableViewCell: UITableViewCell {
    
    private var disclosureButtonTrailingAnchor: NSLayoutConstraint!
    
    lazy var titleLabel: UILabel = {
        let label = UILabel()
        return label
    }()
    
    lazy var subTitleLabel: UILabel = {
        let label = UILabel()
        label.textColor = Colors.greyText
        label.font = .systemFont(ofSize: 13.0)
        return label
    }()
    
    lazy var labelImageView: UIImageView = {
         let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    lazy var vStack: UIStackView = {
        let stack = UIStackView(arrangedSubviews: [
            titleLabel, subTitleLabel
        ])
        stack.axis = .vertical
        return stack
    }()
    
    lazy var disclosureButton: UIButton = {
        let button = UIButton()
        let symbolConfig = UIImage.SymbolConfiguration(pointSize: 15, weight: .semibold, scale: .large)
        let symbolImage = UIImage(systemName: "chevron.right",
                                  withConfiguration: symbolConfig)
        button.setImage(symbolImage?.withTintColor(Colors.hopspinGreen , renderingMode: .alwaysOriginal), for: .normal)
        return button
    }()
    
    lazy var hStack: UIStackView = {
        let stack = UIStackView(arrangedSubviews: [
            labelImageView, vStack
        ])
        stack.distribution = .fillProportionally
        stack.spacing = UIStackView.spacingUseSystem
        
        return stack
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        layout()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func layout() {
        hStack.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(hStack)
        
        let imageViewHeight = labelImageView.heightAnchor.constraint(equalToConstant: 34)
        imageViewHeight.priority = .defaultHigh
        
        contentView.addSubview(disclosureButton)
        disclosureButton.translatesAutoresizingMaskIntoConstraints = false
        
        disclosureButtonTrailingAnchor = disclosureButton.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16.0)
        
        NSLayoutConstraint.activate([
            imageViewHeight,
            labelImageView.widthAnchor.constraint(equalToConstant: 16),
            
            hStack.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16.0),
            hStack.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 5.0),
            hStack.trailingAnchor.constraint(equalTo: disclosureButton.leadingAnchor),
            hStack.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -5.0),
            
            disclosureButton.widthAnchor.constraint(equalToConstant: 10.0),
            disclosureButton.heightAnchor.constraint(equalToConstant: 15.0),
            disclosureButtonTrailingAnchor,
            disclosureButton.centerYAnchor.constraint(equalTo: contentView.centerYAnchor)
        ])
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        if contentView.frame.width < frame.width && 
            disclosureButtonTrailingAnchor.constant != 0.0
        {
            disclosureButtonTrailingAnchor.constant = 0.0
            setNeedsLayout()
            layoutIfNeeded()
        } else if contentView.frame.width == frame.width &&
            disclosureButtonTrailingAnchor.constant != -16.0
        {
            disclosureButtonTrailingAnchor.constant = -16.0
            setNeedsLayout()
            layoutIfNeeded()
        }        
    }
}

