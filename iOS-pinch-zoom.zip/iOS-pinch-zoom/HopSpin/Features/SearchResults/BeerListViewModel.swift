//
//  BeerListViewModel.swift
//  HopSpin
//
//  Created by Antonio Carella on 11/14/23.
//

import Combine
import OrderedCollections
import UIKit

class BeerListViewModel: GenericListViewModel<Beer, BeerListDataHandler, BeerDataFetcher, BeerSortingOption> {

    private let imageRepository: ImageRepository
    let beerViewSegementStateFilterSubject: CurrentValueSubject<BeerViewSegmentState, Never>
    
    init(
        dataFetcher: BeerDataFetcher,
        searchTerm: CurrentValueSubject<String, Never>,
        filters: CurrentValueSubject<FiltersAndOperator, Never>,
        sorting: CurrentValueSubject<(OrderOption, BeerSortingOption), Never>,
        imageRepository: ImageRepository,
        tintColor: UIColor,
        cellSelectionColor: UIColor,
        activityIndicatorColor: UIColor,
        beerViewSegementStateFilterSubject: CurrentValueSubject<BeerViewSegmentState, Never>
    ) {
        self.imageRepository = imageRepository
        self.beerViewSegementStateFilterSubject = beerViewSegementStateFilterSubject
        super.init(
            dataFetcher: dataFetcher,
            searchTerm: searchTerm,
            filters: filters,
            sorting: sorting,
            tintColor: tintColor,
            cellSelectionColor: cellSelectionColor, 
            activityIndicatorColor: activityIndicatorColor
        )
    }
    
    func fetchImage(urlPath: String?) async -> UIImage {
        do {
            if
                let urlPath,
                let image = try await imageRepository.image(path: urlPath)
            {
                return image
            }
            
            return UIImage(named: "beer-placeholder")!
            
        } catch {
            
            // TODO: report error
            return UIImage(named: "avatar")!
            
        }
    }
    
    override func itemSelected(at indexPath: IndexPath) {
        let key = itemsSubject.value.orderedDict.keys[indexPath.section]
        if let array = itemsSubject.value.orderedDict[key],
           let beer = items.first(where: { UUIDHandler.compare(id: $0.id, salted: array[indexPath.row].id) }) {
            delegate?.navigateToBeer(beer, shouldUpdate: nil, tintColor: nil)
        } else {
            let error = ErrorMessage.unknown
            errorMessageSubject.send(error)
        }
    }
}

struct BeerCellarListDataHandler: ListDataProcessorProtocol {
    typealias SortingOption = BeerSortingOption
    typealias ItemType = Beer
    
    static func process(
        items: [Beer],
        searchTerm: String,
        orderOption: OrderOption,
        sortingOption: BeerSortingOption
    ) -> OrderedCollections.OrderedDictionary<String, [SearchListItem]> {
        
        let ordered = BeerListDataSectionGrouper()
            .group(
                items: items,
                sortingOption: sortingOption,
                orderOption: orderOption
            )
        
        return ordered.mapValues { array in
            array.enumerated().map { beer in
                SearchListItem
                    .beerCellarListItem(
                        beer: beer.element,
                        searchTerm: searchTerm,
                        isFinalRow: beer.offset == array.count - 1)
            }
        }
    }
}

struct BeerListDataHandler: ListDataProcessorProtocol {
    typealias SortingOption = BeerSortingOption
    typealias ItemType = Beer
    
    static func process(
        items: [Beer],
        searchTerm: String,
        orderOption: OrderOption,
        sortingOption: BeerSortingOption
    ) -> OrderedCollections.OrderedDictionary<String, [SearchListItem]> {
        
        let ordered = BeerListDataSectionGrouper()
            .group(
                items: items,
                sortingOption: sortingOption,
                orderOption: orderOption
            )
        
        return ordered.mapValues { array in
            array.enumerated().map { beer in
                SearchListItem
                    .beerCellarListItem(
                        beer: beer.element,
                        searchTerm: searchTerm,
                        isFinalRow: beer.offset == array.count - 1)
            }
        }
    }
}

/// Conformance to Generic Handler
class BeerDataFetcher: DataFetcherProtocol {
    private var isFetching = false
    private var fetchTask: Task<[Beer], Error>? = nil
    private var apiClient: ApiClient
    
    init(apiClient: ApiClient = .live) {
        self.apiClient = apiClient
    }

    func fetchItems(
        searchTerm: String,
        filters: FiltersAndOperator,
        sorting: (OrderOption, BeerSortingOption)
    ) async throws -> [Beer] {

        if isFetching {
            // If a fetch is already in progress, await its result
            return try await fetchTask?.value ?? []
        }

        let sortOption = sorting.1        
        isFetching = true
        fetchTask = Task {
            do {
                let search = BeerSearch(
                    name: searchTerm,
                    filters: filters,
                    sortOption: sortOption,
                    sortDirection: sorting.0.sortDirection
                )
                let fetchedItems = try await apiClient.beerSearch(search)
                return fetchedItems
            } catch {
                throw error
            }
        }

        defer {
            isFetching = false
        }

        return try await fetchTask?.value ?? []
    }
}
