//
//  BeerDetailViewController.swift
//  HopSpin
//
//  Created by Antonio Carella on 9/7/23.
//

import CenteredCollectionView
import Combine
import UIKit

class BeerDetailViewController: UIViewController {
    
    // MARK: UI Elements
    private let centeredCollectionViewFlowLayout = CenteredCollectionViewFlowLayout()
    private let scrollView = UIScrollView()
    private let collectionView: UICollectionView
    private let cellPercentWidth: CGFloat = 0.7
    private let pageViewControl = UIPageControl()
    private let loadingView = LoadingView()      
    
    private let refreshControl: UIRefreshControl = {
        let control = UIRefreshControl()
        control.tintColor = .clear
        return control
    }()
    
    private lazy var stackView: UIStackView = {
        let stack = UIStackView(arrangedSubviews: [
            pageViewControl
        ])
        
        stack.distribution = .fillProportionally
        stack.axis = .vertical
        return stack
    }()
    
    private var cellWidth: CGFloat {
        view.bounds.width * cellPercentWidth
    }
    
    // MARK: Dependencies
    private let viewModel: BeerDetailViewModel
    private let navigationBarAppearance: NavigationBarAppearance
    
    // MARK: Combine
    private var subscriptions = Set<AnyCancellable>()
    
    // MARK: LifeCycle
    init(viewModel: BeerDetailViewModel, navigationBarAppearance: NavigationBarAppearance) {
        self.viewModel = viewModel
        self.navigationBarAppearance = navigationBarAppearance
        self.collectionView = UICollectionView(centeredCollectionViewFlowLayout: centeredCollectionViewFlowLayout)
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = viewModel.beerName
        self.loadingView.animationStrokeColor = viewModel.tintColor
        view.backgroundColor = .white
        bindViewModel()
        viewModel.fetchBeerDetail()
        
        setupCollectionView()
        constrainViews()
        scrollView.contentInsetAdjustmentBehavior = .never
        scrollView.refreshControl = refreshControl
        refreshControl.addTarget(self, action: #selector(refreshControlValueChanged), for: .valueChanged)
        adjustSafeAreasForMaxScreens()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        updateNavigationControllerAppearance(navigationBarAppearance)
    }
    
    override func viewSafeAreaInsetsDidChange() {
        super.viewSafeAreaInsetsDidChange()
        if shouldAdjustSafeAreasForMaxScreens() {
            scrollView.scrollIndicatorInsets = makeMaxScreenAdditionalSafeAreaInsetsInverted()
        }
    }
    
    private func constrainViews() {
        view.addSubview(scrollView)
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        scrollView.addSubview(stackView)
        stackView.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(loadingView)
        loadingView.translatesAutoresizingMaskIntoConstraints = false
        
        let spacingView = Spacing.makeInteriorSpacer()
        scrollView.addSubview(spacingView)
        spacingView.translatesAutoresizingMaskIntoConstraints = false
        
        scrollView.addSubview(collectionView)
        collectionView.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            scrollView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scrollView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            scrollView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            scrollView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
                                    
            spacingView.topAnchor.constraint(equalTo: scrollView.topAnchor),
            spacingView.widthAnchor.constraint(equalTo: view.widthAnchor),
            spacingView.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor),
            spacingView.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor),
            
            collectionView.topAnchor.constraint(equalTo: spacingView.bottomAnchor),
            collectionView.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor),
            collectionView.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor),
            
            stackView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor),
            stackView.topAnchor.constraint(equalTo: collectionView.bottomAnchor),
            stackView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor),
            stackView.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor),
                                    
            loadingView.centerXAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerXAnchor),
            loadingView.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: 52)
        ])
        
        pageViewControl.setContentHuggingPriority(.required, for: .horizontal)
        pageViewControl.setContentCompressionResistancePriority(.required, for: .vertical)
    }
    
    private func setupCollectionView() {
        collectionView.dataSource = self

        collectionView.register(
            BeerDetailCollectionViewCell.self,
            forCellWithReuseIdentifier: String(describing: BeerDetailCollectionViewCell.self)
        )
        
        centeredCollectionViewFlowLayout.minimumLineSpacing = 20
        collectionView.showsVerticalScrollIndicator = false
        collectionView.showsHorizontalScrollIndicator = false
        collectionView.delegate = self
        
        pageViewControl.currentPageIndicatorTintColor = viewModel.tintColor
        pageViewControl.pageIndicatorTintColor = UIColor(r: 187.5, g: 187.5, b: 187.5)
        pageViewControl.backgroundStyle = .prominent
        pageViewControl.hidesForSinglePage = true
        pageViewControl.addTarget(self, action: #selector(pageViewControlChanged), for: .valueChanged)
    }
    
    private var collectionViewCellWidth: CGFloat {
        view.bounds.width * cellPercentWidth
    }
    
    private func updateCollectionViewLayout(height: CGFloat) {
        centeredCollectionViewFlowLayout.itemSize = CGSize(
            width: collectionViewCellWidth,
            height: height
        )
        
        let collectionviewHeight = collectionView.heightAnchor.constraint(equalToConstant: height)
        collectionviewHeight.priority = UILayoutPriority(rawValue: 999.0)
        NSLayoutConstraint.activate([
            collectionviewHeight
        ])
        
        collectionView.invalidateIntrinsicContentSize()
        collectionView.setNeedsLayout()
        view.setNeedsLayout()
        view.layoutIfNeeded()
    }
    
    private func bindViewModel() {
        viewModel
            .$beerInfoViewModel
            .receive(on: DispatchQueue.main)
            .compactMap { $0 }
            .sink(receiveValue: updateViews)
            .store(in: &subscriptions)
        
        viewModel
            .$brandingViewModel
            .receive(on: DispatchQueue.main)
            .compactMap { $0 }
            .sink(receiveValue: updateViews)
            .store(in: &subscriptions)
        
        viewModel
            .$showLoadingView
            .receive(on: DispatchQueue.main)
            .compactMap { $0 }
            .removeDuplicates()
            .sink(receiveValue: showLoadingView)
            .store(in: &subscriptions)
        
        viewModel
            .$errorMessage
            .receive(on: DispatchQueue.main)
            .compactMap { $0 }
            .sink(receiveValue: { [weak self] in
                self?.present(errorMessage: $0)
            })
            .store(in: &subscriptions)
            
    }
    
    private func updateViews(beerInfoViewModel: BeerInfoViewModel) {
        let beerInfoView = BeerInfoView(viewModel: beerInfoViewModel)
        stackView.addArrangedSubview(beerInfoView)
    }
        
    private func updateViews(brandingViewModel: BrandingViewModel) {
        
        // For each beer, adjust the text stack height to the max height of all labels
        let maxHeight = maxTextStackHeight(for: brandingViewModel)
        let newCollectionViewHeight = 494.0 + maxHeight
        updateCollectionViewLayout(height: newCollectionViewHeight)
        
        collectionView.reloadData()
        pageViewControl.numberOfPages = brandingViewModel.pages.count
        pageViewControl.currentPage = centeredCollectionViewFlowLayout.currentCenteredPage ?? 0
    }
    
    private func maxTextStackHeight(for brandingViewModel: BrandingViewModel) -> CGFloat {
        brandingViewModel.pages.map { page in
            LabelTextStack().heightForView(
                years: page.yearsValue,
                notes: page.notesValue,
                artists: page.artistsValue,
                width: collectionViewCellWidth - 24 - 29 - 16// 24 for labels stack horizontal padding, 29 for spacing between labels, 16 for additional padding to help layout engine not elipsize text that's close to returning.
            )
        }
        .max() ?? 0.0
    }
    
    private func showLoadingView(show: Bool) {
        scrollView.isHidden = show
        
        if show {
            loadingView.isHidden = false
            loadingView.startAnimating()
            view.bringSubviewToFront(loadingView)
        } else {
            loadingView.isHidden = true
            loadingView.stopAnimating()
            view.sendSubviewToBack(loadingView)
        }
    }
    
    @objc private func pageViewControlChanged() {
        centeredCollectionViewFlowLayout.scrollToPage(index: pageViewControl.currentPage, animated: true)
    }        
    
    @objc private func refreshControlValueChanged() {
        refreshControl.endRefreshing()
    }
    
}

extension BeerDetailViewController: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return viewModel.brandingViewModel?.pages.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: String(describing: BeerDetailCollectionViewCell.self), for: indexPath) as! BeerDetailCollectionViewCell
        
        if let page = viewModel.brandingViewModel?.pages[indexPath.row] {
            cell.set(years: page.yearsValue)
            cell.set(artists: page.artistsValue)
            cell.set(notes: page.notesValue)
            cell.imageView.kf.setImage(with: page.imageURL) { [weak self] result in
                guard indexPath.row == 0 else { return }
                self?.viewModel.firstImageReturned = true
            }
            
            cell.onMenuButtonTapped = { [viewModel] in
                viewModel.presentMenuView(row: indexPath.row)
            }
            
            cell.onThreeDButtonTapped = { [viewModel] in
                viewModel.presentThreeDView(row: indexPath.row)
            }
            
            cell.setButtonView(backgroundColor: viewModel.tintColor, strokeColor: viewModel.strokeColor)
        }
        
        // For each beer, adjust the text stack height to the max height of all labels
        if let brandingViewModel = viewModel.brandingViewModel {
            cell.textStackHeight = maxTextStackHeight(for: brandingViewModel)
        }
        
        return cell
    }
}

extension BeerDetailViewController: UICollectionViewDelegate {
    
    func scrollViewWillBeginDecelerating(_ scrollView: UIScrollView) {
        pageViewControl.currentPage = centeredCollectionViewFlowLayout.currentCenteredPage ?? 0
    }

    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        pageViewControl.currentPage = centeredCollectionViewFlowLayout.currentCenteredPage ?? 0
    }
}
