//
//  BeerDetailViewModel.swift
//  HopSpin
//
//  Created by Antonio Carella on 9/7/23.
//

import Combine
import Foundation
import Kingfisher
import UIKit

@MainActor
class BeerDetailViewModel: ObservableObject {
    
    private let apiClient: ApiClient
    private let beer: Beer
    
    @Published var brandingViewModel: BrandingViewModel? = nil
    @Published var beerInfoViewModel: BeerInfoViewModel? = nil
    @Published var errorMessage: ErrorMessage? = nil
    @Published var showLoadingView: Bool = true
    @Published var firstImageReturned: Bool = false
    
    let shouldUpdate: PassthroughSubject<Void, Never>?
    let tintColor: UIColor
    let strokeColor: UIColor
    
    let beerName: String
    
    private var cancellables = Set<AnyCancellable>()
    
    weak var threeDPresenter: ThreeDViewPresentable?
    weak var menuPresenter: MenuViewPresentable?
    
    init(
        beer: Beer,
        apiClient: ApiClient,
        shouldUpdate: PassthroughSubject<Void, Never>?,
        tintColor: UIColor? = nil
    ) {
        self.apiClient = apiClient
        self.beer = beer
        self.beerName = beer.name
        self.shouldUpdate = shouldUpdate
        self.tintColor = tintColor ?? StyleKit.parseUIColor(string: beer.iosHeaderTextColor, fallback: Colors.hopspinGreen)
        self.strokeColor = beer.iosStatusBarColor == "lightContent" ? .white : .black
        bindSelf()
    }
    
    private func bindSelf() {
        $firstImageReturned
            .receive(on: DispatchQueue.main)
            .filter { $0 }
            .sink { [weak self] _ in
                self?.showLoadingView = false
            }
            .store(in: &cancellables)
    }
    
    func fetchBeerDetail() {
        showLoadingView = true
        Task {
            do {
                async let beerDetail = try await apiClient.beer(beer.id)
                let viewModels = try await beerDetail.brandings.map {
                    BrandingPageViewModel(
                        branding: $0,
                        beerName: beer.name,
                        beerId: beer.id
                    )
                }
                brandingViewModel = BrandingViewModel(pages: viewModels)
                beerInfoViewModel = try await BeerInfoViewModel(beerDetail: beerDetail, beer: beer)
            } catch {
                errorMessage = ErrorMessage(
                    title: "Error",
                    subtitle: error.localizedDescription
                )
                showLoadingView = false
                print("Error", error)
            }
        }
    }
    
    func presentThreeDView(row: Int) {
        let data = MenuAnd3DData(
            name: beer.name,
            avatar: brandingViewModel?.pages[row].imageURL?.absoluteString ?? "",
            brandingYear: brandingViewModel?.pages[row].yearsValue ?? "",
            id: beer.id,
            fileName: brandingViewModel?.pages[row].threeDFileName, 
            tintColor: tintColor
        )
        
        threeDPresenter?.presentThreeDView(data: data, shouldUpdate: shouldUpdate)
    }
    
    func presentMenuView(row: Int) {
        let data = MenuAnd3DData(
            name: beer.name,
            avatar: brandingViewModel?.pages[row].imageURL?.absoluteString ?? "",
            brandingYear: brandingViewModel?.pages[row].yearsValue ?? "",
            id: beer.id,
            fileName: brandingViewModel?.pages[row].threeDFileName, 
            tintColor: StyleKit.parseUIColor(string: beer.iosHeaderTextColor, fallback: Colors.hopspinGreen)
        )
        
        menuPresenter?.presentMenuView(data: data, shouldUpdate: shouldUpdate)
    }
}

struct BrandingViewModel{
    let pages: [BrandingPageViewModel]
    
    init(pages: [BrandingPageViewModel]) {
        self.pages = pages
    }
}

struct BrandingPageViewModel {
    
    let imageURL: URL?
    let yearsValue: String?
    let notesValue: String?
    let artistsValue: String?
    
    let threeDFileName: String?
        
    init(branding: Branding, beerName: String, beerId: Int) {
        self.imageURL = Endpoint.image(path: branding.hero2d).url
        self.yearsValue = if let years = branding.yearsUsed { years.sorted(by: { $0 > $1 }).map { "\($0)" }.joined(separator: ", ") } else { nil }
        self.notesValue = branding.introductionNote
        self.artistsValue = branding.collabDesigners.uniquedAndSorted().map { $0.description }.joined(separator: ", ")
        self.threeDFileName = branding.model3d
    }
}
