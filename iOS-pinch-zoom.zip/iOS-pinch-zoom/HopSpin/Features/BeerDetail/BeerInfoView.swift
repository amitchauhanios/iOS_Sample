//
//  BeerInfoView.swift
//  HopSpin
//
//  Created by Antonio Carella on 9/7/23.
//

import Kingfisher
import UIKit

class BeerInfoView: UIView {
    
    static let colorImageDimension = 22.0
    
    // Labels, in vertical layout order
    private let nameLabel = UILabel()
    private let styleLabel = UILabel()
    private let breweryTitleLabel = UILabel()
    private let breweryValueLabel = UILabel()
    private let seriesTitleLabel = UILabel()
    private let seriesValueLabel = UILabel()
    private let collaborationTitleLabel = UILabel()
    private let collaborationValueLabel = UILabel()
    private var awardTitleLabels = [UILabel]()
    private var awardValueLabels = [UILabel]()
    private var awardCategoryValueLabels = [UILabel]()
    private let aboutTitleLabel = UILabel()
    private let aboutValueLabel = UILabel()
    private let brewersNotesTitleLabel = UILabel()
    private let brewersNotesValueLabel = UILabel()
    
    // Beginning of label - value horizontal layouts
        
    private let releaseScheduleTitleLabel = UILabel()
    private let releaseScheduleValueLabel = UILabel()
    
    private let releaseYearsTitleLabel = UILabel()
    private let releaseYearsValueLabel = UILabel()

    private let releaseMethodTitleLabel = UILabel()
    private let releaseMethodValueLabel = UILabel()

    private let releaseContaintersTitleLabel = UILabel()
    private let releaseContaintersValueLabel = UILabel()

    private let tabColorTitleLabel = UILabel()
    private let tabColorValueLabel = UILabel()

    private let topColorTitleLabel = UILabel()
    private let topColorValueLabel = UILabel()
    
    private let waxColorTitleLabel = UILabel()
    private let waxColorValueLabel = UILabel()
    
    private let capsColorTitleLabel = UILabel()
    private let capsColorValueLabel = UILabel()
    
    private let glassColorTitleLabel = UILabel()
    private let glassColorValueLabel = UILabel()

    private let abvTitleLabel = UILabel()
    private let abvValueLabel = UILabel()
    
    private let ibuTitleLabel = UILabel()
    private let ibuValueLabel = UILabel()
    
    private let pourColorTitleLabel = UILabel()
    private let pourColorValueLabel = UILabel()

    private let hopsTitleLabel = UILabel()
    private let hopsValueLabel = UILabel()

    private let yeastTitleLabel = UILabel()
    private let yeastValueLabel = UILabel()
    
    private let maltsTitleLabel = UILabel()
    private let maltsValueLabel = UILabel()
    
    private let adjunctsTitleLabel = UILabel()
    private let adjunctsValueLabel = UILabel()
    
    // convenience, for styling
    private lazy var titles = [
        breweryTitleLabel,
        seriesTitleLabel,
        collaborationTitleLabel,
        aboutTitleLabel,
        brewersNotesTitleLabel,
        releaseScheduleTitleLabel,
        releaseYearsTitleLabel,
        releaseMethodTitleLabel,
        releaseContaintersTitleLabel,
        tabColorTitleLabel,
        topColorTitleLabel,
        waxColorTitleLabel,
        capsColorTitleLabel,
        glassColorTitleLabel,
        abvTitleLabel,
        ibuTitleLabel,
        pourColorTitleLabel,
        hopsTitleLabel,
        yeastTitleLabel,
        maltsTitleLabel,
        adjunctsTitleLabel
    ]
    
    // convenience, for styling
    private lazy var values = [
        styleLabel,
        breweryValueLabel,
        seriesValueLabel,
        collaborationValueLabel,
        aboutValueLabel,
        brewersNotesValueLabel,
        releaseScheduleValueLabel,
        releaseYearsValueLabel,
        releaseMethodValueLabel,
        releaseContaintersValueLabel,
        tabColorValueLabel,
        topColorValueLabel,
        waxColorValueLabel,
        capsColorValueLabel,
        glassColorValueLabel,
        abvValueLabel,
        ibuValueLabel,
        pourColorValueLabel,
        hopsValueLabel,
        yeastValueLabel,
        maltsValueLabel,
        adjunctsValueLabel
    ]
    
    init(viewModel: BeerInfoViewModel) {
        super.init(frame: .zero)
        applyViewModel(viewModel: viewModel)
        let views = buildArrayOfViews(viewModel: viewModel)
        styleViews()
        constrainViews(views: views)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func styleViews() {
        nameLabel.font = UIFont.systemFont(ofSize: 22.0, weight: .bold)
        nameLabel.numberOfLines = 0
        nameLabel.setContentCompressionResistancePriority(.required, for: .horizontal)
        nameLabel.setContentCompressionResistancePriority(.required, for: .vertical)
        
        titles.forEach {
            $0.font = UIFont.systemFont(ofSize: 17.0, weight: .semibold)
            $0.setContentCompressionResistancePriority(.required, for: .vertical)
        }
        
        awardTitleLabels.forEach {
            $0.font = UIFont.systemFont(ofSize: 17.0, weight: .semibold)
            $0.setContentCompressionResistancePriority(.required, for: .vertical)
        }
        
        values.forEach {
            $0.font = UIFont.systemFont(ofSize: 17.0)
            $0.numberOfLines = 0
            $0.setContentCompressionResistancePriority(.required, for: .vertical)
            $0.setContentCompressionResistancePriority(.required, for: .horizontal)
        }
        
        awardValueLabels.forEach {
            $0.font = UIFont.systemFont(ofSize: 17.0)
            $0.numberOfLines = 0
            $0.setContentCompressionResistancePriority(.required, for: .vertical)
        }

        awardCategoryValueLabels.forEach {
            $0.font = UIFont.systemFont(ofSize: 17.0)
            $0.numberOfLines = 0
            $0.setContentCompressionResistancePriority(.required, for: .vertical)
        }
        
    }
    
    func buildArrayOfViews(viewModel: BeerInfoViewModel) -> [UIView] {
        var views = [
            nameLabel,
            styleLabel,
            Spacing.makeInteriorSpacer(),
            breweryTitleLabel,
            breweryValueLabel
        ]
        
        if viewModel.shouldShowSeries {
            let stack = UIStackView(arrangedSubviews: [Spacing.makeInteriorSpacer(), seriesTitleLabel, seriesValueLabel])
            stack .axis = .vertical
            views.append(stack)
        }
        
        if viewModel.shouldShowCollaboration {
            let stack = UIStackView(arrangedSubviews: [Spacing.makeInteriorSpacer(), collaborationTitleLabel, collaborationValueLabel])
            stack .axis = .vertical
            views.append(stack)
        }
        
        // Awards labels
        let awardVStacks: [UIStackView] = zipThree(awardTitleLabels, awardValueLabels, awardCategoryValueLabels)
            .enumerated()
            .compactMap { enumeratedElement in
                let views = enumeratedElement.element
                var viewsArray: [UIView] = [views.0, views.1, views.2]
                
                if enumeratedElement.offset == 0 {
                    let sectionalSpacer = Spacing.makeSectionalSpacer()
                    viewsArray.insert(sectionalSpacer, at: 0)
                } else {
                    let interiorSpacer = Spacing.makeInteriorSpacer()
                    viewsArray.insert(interiorSpacer, at: 0)
                }
                
                let stack = UIStackView(arrangedSubviews: viewsArray)
                stack.axis = .vertical
                stack.setContentCompressionResistancePriority(.required, for: .vertical)
                return stack
            }
        
        views.append(contentsOf: awardVStacks)
        
        if viewModel.shouldShowAbout {
            let stack = UIStackView(arrangedSubviews: [Spacing.makeSectionalSpacer(), aboutTitleLabel, aboutValueLabel])
            stack .axis = .vertical
            views.append(stack)
        }
        
        if viewModel.shouldShowBrewersNotes {
            let stack = UIStackView(arrangedSubviews: [Spacing.makeSectionalSpacer(), brewersNotesTitleLabel,  brewersNotesValueLabel])
            stack .axis = .vertical
            views.append(stack)
        }
        
        // H Stack views
        views.append(contentsOf: [
            Spacing.makeSectionalSpacer(),
            createHStackViews(title: releaseScheduleTitleLabel, value: releaseScheduleValueLabel),
            Spacing.makeDetailSpacer(),
            createHStackViews(title: releaseYearsTitleLabel, value: releaseYearsValueLabel),
            Spacing.makeDetailSpacer(),
            createHStackViews(title: releaseMethodTitleLabel, value: releaseMethodValueLabel),
            Spacing.makeDetailSpacer(),
            createHStackViews(title: releaseContaintersTitleLabel, value: releaseContaintersValueLabel),
        ])
        
        if viewModel.shouldShowTab {
            let stack = UIStackView(arrangedSubviews: [Spacing.makeDetailSpacer(), createHStackViews(title: tabColorTitleLabel, value: tabColorValueLabel)])
            stack.axis = .vertical
            views.append(stack)
        }
        
        if viewModel.shouldShowTop {
            let stack = UIStackView(arrangedSubviews: [Spacing.makeDetailSpacer(), createHStackViews(title: topColorTitleLabel, value: topColorValueLabel)])
            stack.axis = .vertical
            views.append(stack)
        }
        
        if viewModel.shouldShowWax {
            let stack = UIStackView(arrangedSubviews: [Spacing.makeDetailSpacer(), createHStackViews(title: waxColorTitleLabel, value: waxColorValueLabel)])
            stack.axis = .vertical
            views.append(stack)
        }
        
        if viewModel.shouldShowCaps {
            let stack = UIStackView(arrangedSubviews: [Spacing.makeDetailSpacer(), createHStackViews(title: capsColorTitleLabel, value: capsColorValueLabel)])
            stack.axis = .vertical
            views.append(stack)
        }
        
        if viewModel.shouldShowGlass {
            let stack = UIStackView(arrangedSubviews: [Spacing.makeDetailSpacer(), createHStackViews(title: glassColorTitleLabel, value: glassColorValueLabel)])
            stack.axis = .vertical
            views.append(stack)
        }
        
        views.append(contentsOf: [
            Spacing.makeSectionalSpacer(),
            createHStackViews(title: abvTitleLabel, value: abvValueLabel),
            Spacing.makeDetailSpacer(),
            createHStackViews(title: ibuTitleLabel, value: ibuValueLabel),
            Spacing.makeDetailSpacer(),
            createHStackViews(title: pourColorTitleLabel, value: pourColorValueLabel),
            Spacing.makeSectionalSpacer(),
            createHStackViews(title: hopsTitleLabel, value: hopsValueLabel),
            Spacing.makeDetailSpacer(),
            createHStackViews(title: yeastTitleLabel, value: yeastValueLabel),
            Spacing.makeDetailSpacer(),
            createHStackViews(title: maltsTitleLabel, value: maltsValueLabel),
            Spacing.makeDetailSpacer(),
            createHStackViews(title: adjunctsTitleLabel, value: adjunctsValueLabel),
            Spacing.makeSectionalSpacer(),
            Spacing.makeSectionalSpacer()
        ])
        
        return views
    }
    
    private func constrainViews(views: [UIView]) {
        let stack = UIStackView(arrangedSubviews: views)
        stack.axis = .vertical
        stack.translatesAutoresizingMaskIntoConstraints = false
        stack.spacing = 0.0
        
        addSubview(stack)
        
        NSLayoutConstraint.activate([
            stack.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 16.0),
            stack.topAnchor.constraint(equalTo: topAnchor, constant: 16.0),
            stack.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -16.0),
            stack.bottomAnchor.constraint(equalTo: bottomAnchor)
        ])
    }
    
    private func applyViewModel(viewModel: BeerInfoViewModel) {
        nameLabel.text = viewModel.name
        styleLabel.text = viewModel.style
        
        breweryTitleLabel.text = viewModel.breweryTitle
        breweryValueLabel.text = viewModel.brewery
        
        seriesTitleLabel.text = viewModel.seriesTitle
        seriesValueLabel.text = viewModel.series
        
        collaborationTitleLabel.text = viewModel.collaborationTitle
        collaborationValueLabel.text = viewModel.collaboration
        
        viewModel.awards.forEach { award in
            let title = UILabel()
            title.text = award.title
            awardTitleLabels.append(title)
            
            let valueLabel = UILabel()
            valueLabel.text = award.award
            awardValueLabels.append(valueLabel)
            
            let categoryValueLabel = UILabel()
            categoryValueLabel.text = award.awardCategory
            awardCategoryValueLabels.append(categoryValueLabel)
        }
        
        aboutTitleLabel.text = viewModel.aboutTitle
        aboutValueLabel.text = viewModel.about
        
        brewersNotesTitleLabel.text = viewModel.brewersNotesTitle
        brewersNotesValueLabel.text = viewModel.brewersNotes
        
        releaseScheduleTitleLabel.text = viewModel.releaseScheduleTitle
        releaseScheduleValueLabel.text = viewModel.releaseSchedule
        
        releaseYearsTitleLabel.text = viewModel.releaseYearsTitle
        releaseYearsValueLabel.text = viewModel.releaseYears
        
        releaseMethodTitleLabel.text = viewModel.releaseMethodTitle
        releaseMethodValueLabel.text = viewModel.releaseMethod
        
        releaseContaintersTitleLabel.text = viewModel.releaseContainerTitle
        releaseContaintersValueLabel.text = viewModel.releaseContainer
                
        tabColorTitleLabel.text = viewModel.tabColorTitle
        tabColorValueLabel.text = viewModel.tabColor
        
        topColorTitleLabel.text = viewModel.topColorTitle
        topColorValueLabel.text = viewModel.topColor
        
        waxColorTitleLabel.text = viewModel.waxColorTitle
        waxColorValueLabel.text = viewModel.waxColor
        
        capsColorTitleLabel.text = viewModel.capsColorTitle
        capsColorValueLabel.text = viewModel.capsColor
        
        glassColorTitleLabel.text = viewModel.glassColorTitle
        glassColorValueLabel.text = viewModel.glassColor
                
        abvTitleLabel.text = viewModel.abvTitle
        abvValueLabel.text = viewModel.abv
        
        ibuTitleLabel.text = viewModel.ibuTitle
        ibuValueLabel.text = viewModel.ibu
        
        pourColorTitleLabel.text = viewModel.pourColorTitle
        pourColorValueLabel.text = viewModel.pourColor
        
        hopsTitleLabel.text = viewModel.hopsTitle
        hopsValueLabel.text = viewModel.hops
        
        yeastTitleLabel.text = viewModel.yeastsTitle
        yeastValueLabel.text = viewModel.yeasts
        
        maltsTitleLabel.text = viewModel.maltsTitle
        maltsValueLabel.text = viewModel.malts
        
        adjunctsTitleLabel.text = viewModel.adjunctsTitle
        adjunctsValueLabel.text = viewModel.adjuncts
    }
    
    private func createHStackViews(title: UILabel, value: UILabel) -> UIStackView {
        let stackView = UIStackView(arrangedSubviews: [title, value])
        stackView.axis = .horizontal
        stackView.alignment = .firstBaseline
        stackView.spacing = 0.0
        title.translatesAutoresizingMaskIntoConstraints = false
        title.widthAnchor.constraint(equalToConstant: 125).isActive = true
                
        return stackView
    }
    
}
