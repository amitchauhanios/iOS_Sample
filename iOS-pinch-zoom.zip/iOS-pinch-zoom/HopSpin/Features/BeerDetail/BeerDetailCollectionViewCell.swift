//
//  BeerDetailCollectionViewCell.swift
//  HopSpin
//
//  Created by Antonio Carella on 9/7/23.
//

import UIKit

class BeerDetailCollectionViewCell: UICollectionViewCell {

    private static let buttonDimensions = 25.0
    
    let imageView: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    let textStack = LabelTextStack()
    
    private let threeDButton = UIButton()
    private let ellipsesButton = UIButton()
    
    lazy var buttonView: UIView = {
        let view = UIView()
        let stack = UIStackView(arrangedSubviews: [threeDButton, ellipsesButton])
        let symbolConfig = UIImage.SymbolConfiguration(pointSize: 15, weight: .semibold, scale: .large)
        
        threeDButton.setImage(
            UIImage(systemName: "cube.transparent", withConfiguration: symbolConfig),
            for: .normal
        )
        threeDButton.tintColor = .white
        
        ellipsesButton.setImage(
            UIImage(systemName: "ellipsis.circle", withConfiguration: symbolConfig),
            for: .normal
        )
        ellipsesButton.tintColor = .white
        stack.translatesAutoresizingMaskIntoConstraints = false
        stack.axis = .horizontal
        stack.spacing = 15
        
        view.addSubview(stack)
        view.layer.borderColor = UIColor.white.cgColor
        view.layer.borderWidth = 2.0
        NSLayoutConstraint.activate([
            threeDButton.heightAnchor.constraint(equalToConstant: Self.buttonDimensions),
            threeDButton.widthAnchor.constraint(equalToConstant: Self.buttonDimensions),
            ellipsesButton.heightAnchor.constraint(equalToConstant: Self.buttonDimensions),
            ellipsesButton.widthAnchor.constraint(equalToConstant: Self.buttonDimensions),
            stack.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 13),
            stack.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -13),
            stack.topAnchor.constraint(equalTo: view.topAnchor, constant: 7),
            stack.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -7)
        ])
        
        view.layer.maskedCorners = [
            CACornerMask.layerMaxXMaxYCorner,
            CACornerMask.layerMaxXMinYCorner,
            CACornerMask.layerMinXMaxYCorner,
            CACornerMask.layerMinXMinYCorner
        ]
        
        view.clipsToBounds = true
        
        view.backgroundColor = .red
        
        return view
    }()
    
    private static let hmargins = 12.0
    
    var onThreeDButtonTapped: (() -> Void)?
    var onMenuButtonTapped: (() -> Void)?
    
    // We want to set the textStack to
    // the max height of all textStacks
    // in the collectionView
    var textStackHeight: CGFloat = .zero {
        didSet {
            textStackHeightConstraint.constant = textStackHeight
            setNeedsLayout()
        }
    }
    
    private lazy var textStackHeightConstraint: NSLayoutConstraint = {
        textStack.heightAnchor.constraint(equalToConstant: 64)
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupViews()
        layoutViews()
    }
    
    private func setupViews() {
        threeDButton.addTarget(self, action: #selector(threeDButtonTapped), for: .touchUpInside)
        ellipsesButton.addTarget(self, action: #selector(menuButtonTapped), for: .touchUpInside)
    }
    
    private func layoutViews() {
        
        contentView.addSubview(imageView)
        imageView.addSubview(buttonView)
        imageView.isUserInteractionEnabled = true
        
        [
            imageView,
            buttonView
        ].forEach {
            $0.translatesAutoresizingMaskIntoConstraints = false
        }
        
        addSubview(textStack)
        textStack.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate {
            imageView.topAnchor.constraint(equalTo: contentView.topAnchor)
            imageView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: Self.hmargins)
            imageView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -Self.hmargins)
            imageView.bottomAnchor.constraint(equalTo: textStack.topAnchor, constant: -Self.hmargins)
            
            textStack.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: Self.hmargins)
            textStack.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -Self.hmargins)
            textStack.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -16)
            textStackHeightConstraint
            
            buttonView.centerXAnchor.constraint(equalTo: centerXAnchor)
            buttonView.bottomAnchor.constraint(equalTo: imageView.bottomAnchor, constant: -10)
        }
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        buttonView.layer.cornerRadius = Self.buttonDimensions / 2
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc private func threeDButtonTapped() {
        onThreeDButtonTapped?()
    }
    
    @objc private func menuButtonTapped() {
        onMenuButtonTapped?()
    }
    
    func set(years: String?) {
        textStack.set(years: years)
    }
    
    func set(notes: String?) {
        textStack.set(notes: notes)
    }
    
    func set(artists: String?) {
        textStack.set(artists: artists)
    }
    
    func setButtonView(backgroundColor: UIColor, strokeColor: UIColor) {
        buttonView.backgroundColor = backgroundColor
        threeDButton.tintColor = strokeColor
        ellipsesButton.tintColor = strokeColor
    }
    
}

extension UILabel {
    
    var sizeWithText: CGSize {
        let attributes = [NSAttributedString.Key.font: font]
        let boundingRect = text?.boundingRect(
            with: CGSize(
                width: CGFloat.greatestFiniteMagnitude,
                height: CGFloat.greatestFiniteMagnitude
            ),
            options: .usesLineFragmentOrigin,
            attributes: attributes as [NSAttributedString.Key : Any],
            context: nil
        )
        return boundingRect?.size ?? CGSize.zero
    }
    
}

class LabelTextStack: UIView {

    private static let labelLabelString = "Label"
    private static let noteLabelString = "Note"
    private static let artistsLabelString = "Artists"
    
    private let yearsLabel = UILabel()
    private let notesLabel = UILabel()
    private let artistsLabel = UILabel()
    
    private let yearsValue = UILabel()
    private let notesValue = UILabel()
    private let artistsValue = UILabel()
    
    private lazy var yearsHStack: UIStackView = {
        let stack = UIStackView(arrangedSubviews: [
            yearsLabel, yearsValue
        ])
        stack.spacing = 8.0
        stack.alignment = .top
        stack.setContentCompressionResistancePriority(.required, for: .vertical)
        stack.setContentCompressionResistancePriority(.required, for: .horizontal)
        return stack
    }()
    
    private lazy var notesHStack: UIStackView = {
        let stack = UIStackView(arrangedSubviews: [
            notesLabel, notesValue
        ])
        stack.spacing = 8.0
        stack.alignment = .top
        stack.setContentCompressionResistancePriority(.required, for: .vertical)
        stack.setContentCompressionResistancePriority(.required, for: .horizontal)
        return stack
    }()
    
    private lazy var artistsHStack: UIStackView = {
        let stack = UIStackView(arrangedSubviews: [
            artistsLabel, artistsValue
        ])
        stack.spacing = 8.0
        stack.alignment = .top
        stack.setContentCompressionResistancePriority(.required, for: .vertical)
        stack.setContentCompressionResistancePriority(.required, for: .horizontal)
        return stack
    }()
    
    private lazy var textStack: UIStackView = {
        let stack = UIStackView(arrangedSubviews: [
            yearsHStack, artistsHStack, notesHStack
        ])
        stack.axis = .vertical
        stack.setContentCompressionResistancePriority(.required, for: .vertical)
        stack.setContentCompressionResistancePriority(.required, for: .horizontal)
        return stack
    }()

    func set(years: String?) {
        if let years, !years.isEmpty {
            yearsValue.text = years
            yearsHStack.isHidden = false
        } else {
            yearsHStack.isHidden = true
        }
    }
    
    func set(notes: String?) {
        if let notes, !notes.isEmpty {
            notesValue.text = notes
            notesHStack.isHidden = false
        } else {
            notesHStack.isHidden = true
        }
    }
    
    func set(artists: String?) {
        if let artists, !artists.isEmpty {
            artistsValue.text = artists
            artistsHStack.isHidden = false
        } else {
            artistsHStack.isHidden = true
        }
        
        artistsLabel.text = (artists?.contains(",") ?? false) ? "Artists" : "Artist"
    }
    
    init() {
        super.init(frame: .zero)
        styleViews()
        layoutViews()        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func layoutViews() {
        
        addSubview(textStack)
        textStack.translatesAutoresizingMaskIntoConstraints = false
        
        let labels = [
            yearsLabel,
            notesLabel,
            artistsLabel
        ]
        
        let maxWidth = labels
            .map { $0.sizeWithText }
            .sorted { $0.width > $1.width }
            .first?.width ?? 55.0
        
        let labelWidths = labels.map {
            $0.widthAnchor.constraint(equalToConstant: maxWidth)
        }
            
        let top = textStack.leadingAnchor.constraint(equalTo: leadingAnchor)
        top.priority = UILayoutPriority(rawValue: 999.0)
        
        NSLayoutConstraint.activate {
            labelWidths
            top
            textStack.leadingAnchor.constraint(equalTo: leadingAnchor)
            textStack.trailingAnchor.constraint(equalTo: trailingAnchor)
            textStack.bottomAnchor.constraint(lessThanOrEqualTo: bottomAnchor)
            textStack.topAnchor.constraint(equalTo: topAnchor)
        }
    }
    
    private func styleViews() {
        
        yearsLabel.text = Self.labelLabelString
        notesLabel.text = Self.noteLabelString
        artistsLabel.text = Self.artistsLabelString
        
        [
            yearsLabel,
            notesLabel,
            artistsLabel
        ].forEach {
            $0.font = UIFont.systemFont(ofSize: 13.0, weight: .semibold)
            $0.setContentHuggingPriority(.required, for: .horizontal)
            $0.setContentHuggingPriority(.required, for: .vertical)
            $0.setContentCompressionResistancePriority(.required, for: .vertical)
            $0.setContentCompressionResistancePriority(.required, for: .horizontal)
        }
        
        [
            yearsValue,
            notesValue,
            artistsValue
        ].forEach {
            $0.font = UIFont.systemFont(ofSize: 13.0)
            $0.numberOfLines = 2
            $0.setContentHuggingPriority(.required, for: .horizontal)
            $0.setContentHuggingPriority(.required, for: .vertical)
            $0.setContentCompressionResistancePriority(.required, for: .horizontal)
            $0.setContentCompressionResistancePriority(.required, for: .vertical)
        }
    }
}

extension LabelTextStack {
    func heightForView(years: String?, notes: String?, artists: String?, width: CGFloat) -> CGFloat {
        set(years: years)
        set(notes: notes)
        set(artists: artists)
        
        let verticalSpacing = textStack.spacing
        var totalHeight: CGFloat = 0
        
        func heightForLabel(_ label: UILabel, text: String?, maxWidth: CGFloat) -> CGFloat {
            guard let text = text, !text.isEmpty else {
                return 0
            }

            // Use lineHeight for single-line labels
            if label.numberOfLines == 1 {
                return label.font.lineHeight
            }

            let size = CGSize(width: maxWidth, height: CGFloat.greatestFiniteMagnitude)
            let options: NSStringDrawingOptions = [.usesLineFragmentOrigin, .usesFontLeading]
            let attributes = [NSAttributedString.Key.font: label.font!]

            let boundingRect = text.boundingRect(with: size, options: options, attributes: attributes, context: nil)

            let lineHeight = ceil(label.font.lineHeight)
            let actualHeight = ceil(boundingRect.height)
            // Check if the text actually spans more than one line
            let height = actualHeight > lineHeight ? lineHeight * CGFloat(label.numberOfLines) : lineHeight
                        
            return height
        }


        
        // Calculate the maximum height for each horizontal stack
        func heightForStack(stack: UIStackView, label1: UILabel, text1: String?, label2: UILabel, text2: String?, stackWidth: CGFloat) -> CGFloat {
            if stack.isHidden { return 0 }
            
            //let labelWidth = [label1, label2].map { $0.sizeWithText }.max(by: { $0.width > $1.width } )?.width ?? 0.0
            let height1 = heightForLabel(label1, text: text1, maxWidth: width)
            let height2 = heightForLabel(label2, text: text2, maxWidth: width)
            
            return max(height1, height2)
        }
        
        // Calculate heights of individual stack views
        totalHeight += heightForStack(stack: yearsHStack, label1: yearsLabel, text1: Self.labelLabelString, label2: yearsValue, text2: years, stackWidth: width)
        totalHeight += heightForStack(stack: notesHStack, label1: notesLabel, text1: Self.noteLabelString, label2: notesValue, text2: notes, stackWidth: width)
        totalHeight += heightForStack(stack: artistsHStack, label1: artistsLabel, text1: Self.artistsLabelString, label2: artistsValue, text2: artists, stackWidth: width)
        
        // Add vertical spacing
        totalHeight += verticalSpacing * CGFloat(
            (textStack.arrangedSubviews
                .filter { !$0.isHidden }.count - 1)
        )
        
        return totalHeight
    }
}

