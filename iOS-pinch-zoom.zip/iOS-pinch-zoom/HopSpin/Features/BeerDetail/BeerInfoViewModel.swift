//
//  BeerInfoViewModel.swift
//  HopSpin
//
//  Created by Antonio Carella on 9/7/23.
//

import Foundation

struct BeerInfoViewModel {
    
    let name: String
    let style: String
    let brewery: String
    let breweryTitle: String = "Brewery"
    let series: String
    let seriesTitle: String?
    let collaboration: String
    let collaborationTitle: String?
    let awards: [BreweryAwardViewModel]
    let about: String?
    let aboutTitle: String?
    let brewersNotes: String?
    let brewersNotesTitle: String?
    let releaseSchedule: String
    let releaseScheduleTitle: String = "Released"
    let releaseYears: String
    let releaseYearsTitle: String
    let releaseMethod: String
    let releaseMethodTitle: String = "Availability"
    let releaseContainer: String
    let releaseContainerTitle: String
    let tabColor: String
    let tabColorTitle: String?
    let topColor: String
    let topColorTitle: String?
    let waxColor: String
    let waxColorTitle: String?
    let capsColor: String
    let capsColorTitle: String?
    let glassColor: String
    let glassColorTitle: String?
    let abv: String
    let abvTitle: String = "ABV % "
    let ibu: String
    let ibuTitle: String = "IBU"
    let pourColor: String
    let pourColorTitle: String = "Color (SRM)"
    let hops: String
    let hopsTitle: String
    let yeasts: String
    let yeastsTitle: String
    let malts: String
    let maltsTitle: String
    let adjuncts: String
    let adjunctsTitle: String
        
    let shouldShowSeries: Bool
    let shouldShowCollaboration: Bool
    let shouldShowAbout: Bool
    let shouldShowBrewersNotes: Bool
    let shouldShowTab: Bool
    let shouldShowTop: Bool
    let shouldShowWax: Bool
    let shouldShowCaps: Bool
    let shouldShowGlass: Bool
    
    init(beerDetail: BeerDetail, beer: Beer) {
        self.name = beerDetail.name.dashIfEmpty
        self.style = beerDetail.styles.map { $0.description }.joined(separator: "\n").dashIfEmpty
        self.brewery = beer.brewery.dashIfEmpty
        self.series = beerDetail.brewerySeries.joined(separator: "\n")
        self.collaboration = beerDetail.collabAll.joined(separator: "\n")
        self.awards = beerDetail.awards.map({ award in
            let title = "\(award.awardYear) \(award.competition)"
            return BreweryAwardViewModel(title: title, award: award.award, awardCategory: award.awardCategory)
        }).sorted(by: { $0.title.localizedStandardCompare($1.title) == .orderedDescending })
        
        self.about = beerDetail.about
        self.brewersNotes = beerDetail.backstory
        
        self.releaseSchedule = beer.releaseSchedule.uniquedAndSorted().joined(separator: ", ").dashIfEmpty
        
        let releaseYearsRaw = beerDetail.releaseYear.uniquedAndSortedYears().compactMap { "\($0)" }
        self.releaseYears = releaseYearsRaw.joined(separator: ", ").dashIfEmpty
        self.releaseMethod = beer.releaseMethod.uniquedAndSorted().joined(separator: ", ").dashIfEmpty
        
        let releaseContainerRaw = beerDetail.releaseContainer.uniquedAndSorted()
        self.releaseContainer = releaseContainerRaw.joined(separator: ", ").dashIfEmpty
        
        let tabColorRaw = beerDetail.brandings.compactMap(\.tabColor).uniquedAndSorted()
        self.tabColor = tabColorRaw.joined(separator: ", ")
        let topColorRaw = beerDetail.brandings.compactMap(\.endColor).uniquedAndSorted()
        self.topColor = topColorRaw.joined(separator: ", ")
        self.waxColor = beerDetail.brandings.compactMap(\.waxColor).uniquedAndSorted().joined(separator: ", ")
        let capsColorRaw = beerDetail.brandings.compactMap(\.closureColor).uniquedAndSorted()
        self.capsColor = capsColorRaw.joined(separator: ", ")
        self.glassColor = beerDetail.brandings.compactMap(\.glassColor).uniquedAndSorted().joined(separator: ", ")
        
        self.abv = if let abv = beerDetail.abv { "\(Double(round(100 * abv) / 100))".dashIfEmpty } else { "".dashIfEmpty }
        self.ibu = if let ibu = beerDetail.ibu { "\(ibu)" } else { "".dashIfEmpty }
        self.pourColor = beer.pourColor.coallesceToDash
                
        let yeastsRaw = beerDetail.yeasts.uniquedAndSorted()
        self.yeasts = yeastsRaw.joined(separator: ", ").dashIfEmpty
        let maltsRaw = beerDetail.malts.uniquedAndSorted()
        self.malts = maltsRaw.joined(separator: ", ").dashIfEmpty
        let hopsRaw = beer.hops.uniquedAndSorted()
        self.hops = hopsRaw.joined(separator: ", ").dashIfEmpty
        let adjunctsRaw = beer.adjuncts.uniquedAndSorted()
        self.adjuncts = adjunctsRaw.joined(separator: ", ").dashIfEmpty
        
        self.shouldShowSeries = beerDetail.brewerySeries.isNotEmpty
        self.shouldShowCollaboration = beerDetail.collabAll.isNotEmpty
        self.shouldShowAbout = if let about = beerDetail.about { !about.isEmpty} else { false }
        self.shouldShowBrewersNotes = if let about = beerDetail.backstory { !about.isEmpty} else { false }
        self.shouldShowTab = beerDetail.brandings.compactMap(\.tabColor).isNotEmpty
        self.shouldShowTop = beerDetail.brandings.compactMap(\.endColor).isNotEmpty
        self.shouldShowWax = beerDetail.brandings.compactMap(\.waxColor).isNotEmpty
        self.shouldShowCaps = beerDetail.brandings.compactMap(\.closureColor).isNotEmpty
        self.shouldShowGlass = beerDetail.brandings.compactMap(\.glassColor).isNotEmpty
        
        self.seriesTitle = shouldShowSeries ? "Brewery Series" : nil
        self.collaborationTitle = shouldShowCollaboration ? "Collaboration" : nil
        self.aboutTitle = shouldShowAbout ? "About" : nil
        self.brewersNotesTitle = shouldShowBrewersNotes ? "Brewer’s Notes" : nil
        self.releaseYearsTitle = beerDetail.releaseYear.count > 1 ? "Years" : "Year"
        self.releaseContainerTitle = beerDetail.releaseContainer.count > 1 ? "Containers" : "Container"
        self.tabColorTitle = shouldShowTab  ? tabColorRaw.count > 1 ? "Tabs" : "Tab" : nil
        self.topColorTitle = shouldShowTop ? topColorRaw.count > 1 ? "Tops" : "Top" : nil
        self.waxColorTitle = shouldShowWax ? "Wax" : nil
        self.capsColorTitle = shouldShowCaps ? capsColorRaw.count > 1 ? "Caps" : "Cap" : nil
        self.glassColorTitle = shouldShowGlass ? "Glass" : nil
        
        self.hopsTitle = hopsRaw.count > 1 ?  "Hops" : "Hop"
        self.yeastsTitle = yeastsRaw.count > 1 ?  "Yeasts" : "Yeast"
        self.maltsTitle = maltsRaw.count > 1 ?  "Malts" : "Malt"
        self.adjunctsTitle = adjunctsRaw.count > 1 ?  "Adjuncts" : "Adjunct"
    }
    
    struct BreweryAwardViewModel {
        let title: String
        let award: String
        let awardCategory: String
    }
    
}

struct ColorDescription {
    let imageURL: URL?
    let text: String?
    
    init(urlString: String?, text: String?) {
        if let urlString {
            self.imageURL = Endpoint.image(path: urlString).url
        } else {
            self.imageURL = nil
        }
        
        self.text = text.coallesceToEmpty
    }
}
