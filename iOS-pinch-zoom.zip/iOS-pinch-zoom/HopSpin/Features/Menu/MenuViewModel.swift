//
//  MenuViewModel.swift
//  HopSpin
//
//  Created by Antonio Carella on 11/27/23.
//

import Combine
import UIKit

struct MenuItem: Hashable {
    let text: String
    let imageName: String
}

struct MenuAnd3DData {
    let name: String
    let avatar: String
    let brandingYear: String
    let id: Int
    let fileName: String?
    let tintColor: UIColor
}

class MenuViewModel {
    
    @Published var errorMessage: ErrorMessage? = nil
    @Published var shouldDismiss: Bool = false
    
    let favoriteItems: [MenuItem] = [
        .init(text: "Add to Favorites", imageName: "heart")
    ]
    
    let cellarItems: [MenuItem] = [
        .init(text: "Cellar as \"Have\"", imageName: "rectangle.and.paperclip"),
        .init(text: "Cellar as \"Want\"", imageName: "rectangle.dashed.and.paperclip"),
        .init(text: "Cellar as \"Had\"", imageName: "paperclip")
    ]
    
    let name: String
    let imageURL: String
    let brandingYear: String
    let tintColor: UIColor
    
    private let shouldUpdate: PassthroughSubject<Void, Never>?
    private let beerId: Int
    
    private let persister: BeerCellarPersistable
    
    init(
        data: MenuAnd3DData,
        persister: BeerCellarPersistable,
        shouldUpdate: PassthroughSubject<Void, Never>?
    ) {
        
        self.name = data.name
        self.imageURL = data.avatar
        self.brandingYear = data.brandingYear.isEmpty ? "" : "\(data.brandingYear) Branding"
        self.beerId = data.id
        self.persister = persister
        self.shouldUpdate = shouldUpdate
        self.tintColor = data.tintColor
    }
    
    func userSelected(indexPath: IndexPath) {
        
        var cellar: BeerCellar?
        if indexPath.section == 1 {
            switch indexPath.row {
            case 0:
                cellar = .have
            case 1:
                cellar = .want
            case 2:
                cellar = .had
            default:
                assertionFailure("Cellar persistence case not implemented")
                break
            }
            do {
                if let cellar {
                    try persister.save(beerId: "\(beerId)", cellar: cellar)
                    shouldUpdate?.send(())
                } else {
                    throw BeerCellarPersisterError.noCellar
                }
            } catch {
                errorMessage = .unknown
                print("Error", error)
            }
        }
        
        shouldDismiss = true
    }
}

enum BeerCellarPersisterError: Error {
    case noCellar
}

class MenuTableViewCell: UITableViewCell {
    
    let label: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 17)
        return label
    }()
    
    let iconImageView = UIImageView()
    
    lazy var hStack: UIStackView = {
        let stack = UIStackView(arrangedSubviews: [
            label, iconImageView
        ])
        
        return stack
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        layoutViews()
        iconImageView.tintColor = .black
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func layoutViews() {
        contentView.addSubview(hStack)
        hStack.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            hStack.leadingAnchor.constraint(equalTo: contentView.layoutMarginsGuide.leadingAnchor),
            hStack.trailingAnchor.constraint(equalTo: contentView.layoutMarginsGuide.trailingAnchor),
            hStack.topAnchor.constraint(equalTo: contentView.layoutMarginsGuide.topAnchor),
            hStack.bottomAnchor.constraint(equalTo: contentView.layoutMarginsGuide.bottomAnchor)
        ])
        
    }
}
