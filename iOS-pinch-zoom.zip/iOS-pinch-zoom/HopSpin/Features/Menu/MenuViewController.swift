//
//  MenuViewController.swift
//  HopSpinTest
//
//  Created by Antonio Carella on 9/8/23.
//

import Combine
import Kingfisher
import UIKit

class MenuViewController: UIViewController {
    
    //MARK: DiffableDataSource
    enum Section: Hashable {
        case favorites
        case cellar
    }
    
    private typealias MenuDataSource = UITableViewDiffableDataSource<Section, MenuItem>
    private typealias MenuSnapshot = NSDiffableDataSourceSnapshot<Section, MenuItem>
    
    private let menuDataSource: MenuDataSource
        
    // MARK: UI Elements
    private let thumbnailBackground: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.cornerRadius = 7.5
        view.layer.maskedCorners = [
            CACornerMask.layerMaxXMaxYCorner,
            CACornerMask.layerMaxXMinYCorner,
            CACornerMask.layerMinXMaxYCorner,
            CACornerMask.layerMinXMinYCorner
        ]
        
        NSLayoutConstraint.activate([
            view.widthAnchor.constraint(equalToConstant: 60.0),
            view.heightAnchor.constraint(equalToConstant: 60.0)
        ])
        
        view.clipsToBounds = true
        
        return view
    }()
    
    private let thumbNailImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
                
        return imageView
    }()
    
    private let nameLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 15.0)
        label.textColor = .black
        return label
    }()
    
    private let brandingLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 13.0)
        label.textColor = UIColor(red: 0.235, green: 0.235, blue: 0.263, alpha: 0.6)
        return label
    }()
    
    private let closeButton: UIButton = {
        let button = UIButton()
        let symbolConfig = UIImage.SymbolConfiguration(pointSize: 16, weight: .semibold, scale: .large)
        button.setImage(.init(systemName: "xmark", withConfiguration: symbolConfig), for: .normal)
        button.tintColor = UIColor(red: 0.235, green: 0.235, blue: 0.263, alpha: 0.6)
        button.backgroundColor = UIColor(red: 0.463, green: 0.463, blue: 0.502, alpha: 0.12)
        
        NSLayoutConstraint.activate([
            button.widthAnchor.constraint(equalToConstant: 30.0),
            button.heightAnchor.constraint(equalToConstant: 30.0)
        ])
        
        button.layer.cornerRadius = StyleKit.cornerRadius
        button.layer.maskedCorners = [
            CACornerMask.layerMaxXMaxYCorner,
            CACornerMask.layerMaxXMinYCorner,
            CACornerMask.layerMinXMaxYCorner,
            CACornerMask.layerMinXMinYCorner
        ]
        
        button.clipsToBounds = true
        return button
        
    }()
    
    private let handleView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor(red: 0.235, green: 0.235, blue: 0.263, alpha: 0.3)
        
        view.layer.cornerRadius = 2.5
        view.layer.maskedCorners = [
            CACornerMask.layerMaxXMaxYCorner,
            CACornerMask.layerMaxXMinYCorner,
            CACornerMask.layerMinXMaxYCorner,
            CACornerMask.layerMinXMinYCorner
        ]
        
        view.clipsToBounds = true
        return view
        
    }()
    
    private lazy var headerStack: UIStackView = {
        
        thumbnailBackground.addSubview(thumbNailImageView)
        thumbNailImageView.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            thumbNailImageView.leadingAnchor.constraint(equalTo: thumbnailBackground.layoutMarginsGuide.leadingAnchor),
            thumbNailImageView.trailingAnchor.constraint(equalTo: thumbnailBackground.layoutMarginsGuide.trailingAnchor),
            thumbNailImageView.topAnchor.constraint(equalTo: thumbnailBackground.layoutMarginsGuide.topAnchor),
            thumbNailImageView.bottomAnchor.constraint(equalTo: thumbnailBackground.layoutMarginsGuide.bottomAnchor)
        ])
        
        let labelsVStack = UIStackView(arrangedSubviews: [nameLabel, brandingLabel])
        labelsVStack.axis = .vertical
        let hStack = UIStackView(arrangedSubviews: [thumbnailBackground, labelsVStack])
        hStack.spacing = 16.0
        hStack.alignment = .center
        return hStack
    }()
    
    private let borderView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor(red: 0.24, green: 0.24, blue: 0.26, alpha: 0.15)
        return view
    }()
    
    private let tableView = UITableView(frame: .zero, style: .insetGrouped)
    private let cellId = "cellId"
    
    // MARK: - Combine
    private var subscriptions = Set<AnyCancellable>()
    
    // MARK: - Dependencies
    private let viewModel: MenuViewModel
    
    init(viewModel: MenuViewModel) {
        self.viewModel = viewModel
        
        self.menuDataSource = MenuDataSource(tableView: tableView, cellProvider: { [cellId] tableView, indexPath, cellViewModel in
            let cell = tableView.dequeueReusableCell(
                                withIdentifier: cellId,
                                for: indexPath) as! MenuTableViewCell
            
            let config = UIImage.SymbolConfiguration(pointSize: 17)
            cell.iconImageView.image = UIImage(systemName: cellViewModel.imageName, withConfiguration: config)
            cell.label.text = cellViewModel.text
            return cell
            
        })
        
        super.init(nibName: nil, bundle: nil)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: false)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupViews()
        layoutViews()
        bindViewModel()
        populateViews()
    }
    
    private func setupViews() {
        view.backgroundColor = .white
        tableView.register(MenuTableViewCell.self,
                                   forCellReuseIdentifier: cellId)
        tableView.delegate = self
        
        closeButton.addTarget(self, action: #selector(closeButtonTapped), for: .touchUpInside)
        view.backgroundColor = UIColor.systemGroupedBackground
    }
    
    private func layoutViews() {
        
        view.addSubview(headerStack)
        headerStack.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(handleView)
        handleView.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(closeButton)
        closeButton.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(tableView)
        tableView.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(borderView)
        borderView.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            headerStack.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16.0),
            headerStack.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16.0),
            headerStack.topAnchor.constraint(equalTo: view.topAnchor, constant: 21.0),
            headerStack.bottomAnchor.constraint(equalTo: borderView.bottomAnchor, constant: -11.0),
            
            handleView.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            handleView.topAnchor.constraint(equalTo: view.topAnchor, constant: 17.0),
            
            closeButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
            closeButton.topAnchor.constraint(equalTo: view.topAnchor, constant: 15),
            
            borderView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            borderView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            borderView.heightAnchor.constraint(equalToConstant: 1.0),
            borderView.bottomAnchor.constraint(equalTo: tableView.topAnchor),
            
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
            
        ])
    }
    
    private func bindViewModel() {
        viewModel
            .$errorMessage
            .receive(on: DispatchQueue.main)
            .compactMap { $0 }
            .sink(receiveValue: { [weak self] in
                self?.present(errorMessage: $0)
            })
            .store(in: &subscriptions)
        
        viewModel
            .$shouldDismiss
            .receive(on: DispatchQueue.main)
            .filter { $0 }
            .map { _ in Void() }
            .sink(receiveValue: dismissSelf)
            .store(in: &subscriptions)
            
    }
    
    private func populateViews() {
        thumbNailImageView.kf.setImage(with: URL(string: viewModel.imageURL))
        nameLabel.text = viewModel.name
        brandingLabel.text = viewModel.brandingYear
        
        loadSnapshot()
    }
    
    private func loadSnapshot() {
        var snapshot = MenuSnapshot()
        
        snapshot.appendSections([.favorites, .cellar])

        snapshot.appendItems(viewModel.favoriteItems, toSection: .favorites)
        snapshot.appendItems(viewModel.cellarItems, toSection: .cellar)
        
        menuDataSource.apply(snapshot)
    }
    
    @objc private func closeButtonTapped() {
        dismissSelf()
    }
    
    private func dismissSelf() {
        presentingViewController?.dismiss(animated: true)
    }
    
}

extension MenuViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        viewModel.userSelected(indexPath: indexPath)
    }
    
}
