//
//  SortingViewControllerNew.swift
//  HopSpin
//
//  Created by Antonio Carella on 12/29/23.
//

import Combine
import UIKit

class SortingViewController: UIViewController {
    
    // MARK: Diffable Data Source
    
    enum Section {
        case sorts
    }
    
    typealias ItemsSnapshot = NSDiffableDataSourceSnapshot<Section, SortingRowViewModel>
    typealias ItemsDataSource = UITableViewDiffableDataSource<Section, SortingRowViewModel>
    
    var dataSource: ItemsDataSource!
    private let cellID = "cellId"
    
    private let headerHeight: CGFloat = 44
    private let footerHeight: CGFloat = 56
    
    // MARK: - UI Elements
    private let sortOrderHeader = UILabel()
    private let sortOrderHeaderView = UIView()
    private let ascendingButtonView = RadioButtonLabelView()
    private let descendingButtonView = RadioButtonLabelView()
    
    private lazy var sortOrderStack: UIStackView = {
        let stack = UIStackView(arrangedSubviews: [
            ascendingButtonView, descendingButtonView
        ])
        stack.axis = .vertical
        return stack
    }()
    
    private let sortByHeader = UILabel()
    private let sortByHeaderView = UIView()
    private let tableView = UITableView()
    private let footerView = UIView()
    private lazy var cancelButton: PaddedButton = {
        let button = PaddedButton()
        button.updateConfiguration(
            title: "Cancel",
            titleColor: viewModel.tintColor,
            backgroundColor: .clear,
            font: UIFont.systemFont(ofSize: 17.0, weight: .semibold),
            cornerRadius: 0.0
        )
        button.setContentHuggingPriority(.defaultHigh, for: .horizontal)
        button.setContentHuggingPriority(.required, for: .vertical)
        return button
    }()
    
    private let viewModel: SortingViewModel
    private var cancellables = Set<AnyCancellable>()
    
    init(viewModel: SortingViewModel) {
        self.viewModel = viewModel
        super.init(nibName: nil, bundle: nil)
        setupDataSource()
        setup()
        bind()
        style()
        layout()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func bind() {
        ascendingButtonView.onTap = { [weak self] in
            self?.viewModel.orderOptionSelected(orderOption: .ascending)
        }
        
        descendingButtonView.onTap = { [weak self] in
            self?.viewModel.orderOptionSelected(orderOption: .descending)
        }
        
        viewModel
            .orderOption
            .receive(on: DispatchQueue.main)
            .sink { [weak self] orderOption in
                self?.ascendingButtonView.isSelected = orderOption == .ascending
                self?.descendingButtonView.isSelected = orderOption == .descending
            }
            .store(in: &cancellables)
        
        viewModel
            .$rowViewModels
            .receive(on: DispatchQueue.main)
            .sink { [weak self] data in
                self?.updateList(data: data)
            }
            .store(in: &cancellables)
        
        viewModel
            .shouldDismiss
            .receive(on: DispatchQueue.main)
            .sink { [weak self] data in
                self?.dismiss(animated: true)
            }
            .store(in: &cancellables)
    }
    
    private func setup() {
        view.backgroundColor = .white
        
        tableView.register(RadioButtonTableViewCell.self, forCellReuseIdentifier: cellID)
        tableView.contentInset.bottom = 44.0
        
        ascendingButtonView.label.text = "Ascending"
        descendingButtonView.label.text = "Descending"
        ascendingButtonView.tintColor = viewModel.tintColor
        descendingButtonView.tintColor = viewModel.tintColor
        
        cancelButton.addTarget(self, action: #selector(cancelButtonTapped), for: .touchUpInside)
    }
    
    private func setupDataSource() {
        
        dataSource = ItemsDataSource(tableView: self.tableView, cellProvider: { [weak self] tableView, indexPath, itemIdentifier in
            guard let self else { return UITableViewCell() }
            
            guard let cell = tableView.dequeueReusableCell(withIdentifier: cellID, for: indexPath) as? RadioButtonTableViewCell else {
                assertionFailure("Incorrect Cell Dequeue")
                return UITableViewCell()
            }
            
            cell.view.label.text = itemIdentifier.title
            cell.view.tintColor = viewModel.tintColor
            cell.view.isSelected = itemIdentifier.isSelected
            
            cell.view.onTap = { [viewModel] in
                viewModel.rowSelected(row: indexPath.row)
            }
            
            cell.selectionStyle = .none
            itemIdentifier.isLastRow ? cell.hideSeparator() : cell.showStandardSeparator()
            
            return cell
            
        })
        
    }
    
    private func updateList(data: [SortingRowViewModel]) {
        var snapshot = ItemsSnapshot()
        snapshot.appendSections([.sorts])
        snapshot.appendItems(data)
        dataSource.apply(snapshot, animatingDifferences: false)
    }
    
    private func style() {
        view.backgroundColor = viewModel.sectionTitleBackgroundColor
        
        sortOrderHeader.font = UIFont.systemFont(ofSize: 20.0, weight: .semibold)
        sortOrderHeader.text = "Sort Order"
        sortOrderHeaderView.backgroundColor = viewModel.sectionTitleBackgroundColor
        
        ascendingButtonView.backgroundColor = .white
        descendingButtonView.backgroundColor = .white
        
        sortByHeader.font = UIFont.systemFont(ofSize: 20.0, weight: .semibold)
        sortByHeader.text = viewModel.sectionTitle
        sortByHeaderView.backgroundColor = viewModel.sectionTitleBackgroundColor
    }
    
    private func layout() {
        view.addSubview(sortOrderHeaderView)
        sortOrderHeaderView.translatesAutoresizingMaskIntoConstraints = false
        
        sortOrderHeaderView.addSubview(sortOrderHeader)
        sortOrderHeader.translatesAutoresizingMaskIntoConstraints = false
        
        let sortOrderHeaderBottomBorder = makeBorderView()
        sortOrderHeader.addSubview(sortOrderHeaderBottomBorder)
        
        view.addSubview(sortOrderStack)
        sortOrderStack.translatesAutoresizingMaskIntoConstraints = false
        
        let ascendingViewBottomBorder = makeBorderView()
        ascendingButtonView.addSubview(ascendingViewBottomBorder)
        
        view.addSubview(sortByHeaderView)
        sortByHeaderView.translatesAutoresizingMaskIntoConstraints = false
        
        sortByHeaderView.addSubview(sortByHeader)
        sortByHeader.translatesAutoresizingMaskIntoConstraints = false
        
        let descendingViewBottomBorder = makeBorderView()
        descendingButtonView.addSubview(descendingViewBottomBorder)
        
        let sortByHeaderBottomBorder = makeBorderView()
        sortByHeader.addSubview(sortByHeaderBottomBorder)
        
        let footerTopBorder = makeBorderView()
        footerView.addSubview(footerTopBorder)
        
        view.addSubview(tableView)
        tableView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(footerView)
        footerView.translatesAutoresizingMaskIntoConstraints = false
        footerView.addSubview(cancelButton)
        cancelButton.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate {
            
            sortOrderHeader.leadingAnchor.constraint(equalTo: sortOrderHeaderView.leadingAnchor, constant: 16.0)
            sortOrderHeader.trailingAnchor.constraint(equalTo: sortOrderHeaderView.trailingAnchor)
            sortOrderHeader.bottomAnchor.constraint(equalTo: sortOrderHeaderView.bottomAnchor)
            sortOrderHeader.topAnchor.constraint(equalTo: sortOrderHeaderView.topAnchor)
            
            sortOrderHeaderView.heightAnchor.constraint(equalToConstant: headerHeight)
            sortOrderHeaderView.topAnchor.constraint(equalTo: view.topAnchor)
            sortOrderHeaderView.leadingAnchor.constraint(equalTo: view.leadingAnchor)
            sortOrderHeaderView.trailingAnchor.constraint(equalTo: view.trailingAnchor)
            sortOrderHeaderView.bottomAnchor.constraint(equalTo: sortOrderStack.topAnchor)
            
            sortOrderHeaderBottomBorder.heightAnchor.constraint(equalToConstant: 0.5)
            sortOrderHeaderBottomBorder.leadingAnchor.constraint(equalTo: view.leadingAnchor)
            sortOrderHeaderBottomBorder.trailingAnchor.constraint(equalTo: view.trailingAnchor)
            sortOrderHeaderBottomBorder.bottomAnchor.constraint(equalTo: sortOrderHeader.bottomAnchor)
            
            sortOrderStack.leadingAnchor.constraint(equalTo: view.leadingAnchor)
            sortOrderStack.trailingAnchor.constraint(equalTo: view.trailingAnchor)
            sortOrderStack.bottomAnchor.constraint(equalTo: sortByHeader.topAnchor)
                        
            ascendingViewBottomBorder.heightAnchor.constraint(equalToConstant: 0.5)
            ascendingViewBottomBorder.leadingAnchor.constraint(equalTo: ascendingButtonView.leadingAnchor, constant: 16.0)
            ascendingViewBottomBorder.trailingAnchor.constraint(equalTo: ascendingButtonView.trailingAnchor, constant: -16.0)
            ascendingViewBottomBorder.bottomAnchor.constraint(equalTo: ascendingButtonView.bottomAnchor)
            
            descendingViewBottomBorder.heightAnchor.constraint(equalToConstant: 0.5)
            descendingViewBottomBorder.leadingAnchor.constraint(equalTo: view.leadingAnchor)
            descendingViewBottomBorder.trailingAnchor.constraint(equalTo: view.trailingAnchor)
            descendingViewBottomBorder.bottomAnchor.constraint(equalTo: descendingButtonView.bottomAnchor)
                        
            sortByHeaderView.heightAnchor.constraint(equalToConstant: headerHeight)
            sortByHeaderView.leadingAnchor.constraint(equalTo: view.leadingAnchor)
            sortByHeaderView.trailingAnchor.constraint(equalTo: view.trailingAnchor)
            sortByHeaderView.bottomAnchor.constraint(equalTo: tableView.topAnchor)
                        
            sortByHeader.leadingAnchor.constraint(equalTo: sortByHeaderView.leadingAnchor, constant: 16)
            sortByHeader.trailingAnchor.constraint(equalTo: sortByHeaderView.trailingAnchor)
            sortByHeader.bottomAnchor.constraint(equalTo: sortByHeaderView.bottomAnchor)
            sortByHeader.topAnchor.constraint(equalTo: sortByHeaderView.topAnchor)
                                    
            sortByHeaderBottomBorder.heightAnchor.constraint(equalToConstant: 0.5)
            sortByHeaderBottomBorder.leadingAnchor.constraint(equalTo: view.leadingAnchor)
            sortByHeaderBottomBorder.trailingAnchor.constraint(equalTo: view.trailingAnchor)
            sortByHeaderBottomBorder.bottomAnchor.constraint(equalTo: sortByHeader.bottomAnchor)
            
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor)
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor)
            tableView.bottomAnchor.constraint(equalTo: footerView.topAnchor)
            
            footerView.heightAnchor.constraint(equalToConstant: footerHeight)
            footerView.leadingAnchor.constraint(equalTo: view.leadingAnchor)
            footerView.trailingAnchor.constraint(equalTo: view.trailingAnchor)
            footerView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: 7.0)
            
            footerTopBorder.heightAnchor.constraint(equalToConstant: 0.5)
            footerTopBorder.leadingAnchor.constraint(equalTo: view.leadingAnchor)
            footerTopBorder.trailingAnchor.constraint(equalTo: view.trailingAnchor)
            footerTopBorder.bottomAnchor.constraint(equalTo: footerView.topAnchor)            
            
            cancelButton.centerXAnchor.constraint(equalTo: footerView.centerXAnchor)
            cancelButton.centerYAnchor.constraint(equalTo: footerView.centerYAnchor)
            
        }
    }
    
    @objc private func cancelButtonTapped() {
        self.dismiss(animated: true)
    }
}
