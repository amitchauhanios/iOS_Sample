//
//  SortingViewModelNew.swift
//  HopSpin
//
//  Created by Antonio Carella on 12/30/23.
//

import Combine
import UIKit

class SortingViewModel {
    
    @Published var rowViewModels: [SortingRowViewModel]
    let tintColor: UIColor
    let orderOption: CurrentValueSubject<OrderOption, Never>
    let shouldDismiss = PassthroughSubject<Void, Never>()
    let sectionTitle: String
    let sectionTitleBackgroundColor: UIColor
    
    private let applySortingHandler: (((OrderOption, String)) -> Void)?
    
    private var cancellables = Set<AnyCancellable>()
    
    init(_ sortingOptions: [String],
         selected: (OrderOption, String),
         applySortingHandler: (((OrderOption, String)) -> Void)?,
         tintColor: UIColor,
         sectionTitleItem: SortSectionTitleItem
    ) {
        
        self.rowViewModels = sortingOptions
            .enumerated()
            .map({ title in
                SortingRowViewModel(
                    title: title.element,
                    isSelected: title.element == selected.1,
                    isLastRow: title.offset == sortingOptions.count - 1
                )
        })
        self.orderOption = CurrentValueSubject<OrderOption, Never>(selected.0)
        self.applySortingHandler = applySortingHandler
        self.tintColor = tintColor
        self.sectionTitle = sectionTitleItem.sectionTitle
        self.sectionTitleBackgroundColor = sectionTitleItem.color
    }
    
    func rowSelected(row: Int) {
        // unselect currently selected row
        if let selectedIndex = rowViewModels.firstIndex(where: { $0.isSelected == true }) {
            let selected = rowViewModels[selectedIndex]
            let unselected = SortingRowViewModel(title: selected.title, isSelected: false, isLastRow: selected.isLastRow)
            rowViewModels[selectedIndex] = unselected
        }

        // select newly selected row
        let toBeSelected = rowViewModels[row]
        let newlySelected = SortingRowViewModel(title: toBeSelected.title, isSelected: true, isLastRow: toBeSelected.isLastRow)
        rowViewModels[row] = newlySelected
                
        dismiss()
    }
    
    func orderOptionSelected(orderOption: OrderOption) {
        self.orderOption.send(orderOption)
        dismiss()
    }
    
    private func dismiss() {
        let selected = rowViewModels.filter({ $0.isSelected }).first ?? rowViewModels[0]
        applySortingHandler?((orderOption.value, selected.title))
        
        Task {
            try await Task.sleep(for: .seconds(0.25))
            shouldDismiss.send(())
        }
    }
}

struct SortingRowViewModel: Hashable {
    let title: String
    let isSelected: Bool
    let isLastRow: Bool
}

enum SortSectionTitleItem {
    case beer(UIColor)
    case brewery(UIColor)
    case artist(UIColor)
    
    var sectionTitle: String {
        switch self {
        case .beer:
            "Sort Beers By"
        case .brewery:
            "Sort Breweries By"
        case .artist:
            "Sort Artists By"
        }
    }
    
    var color: UIColor {
        switch self {
        case .beer(let color):
            return color
        case .brewery(let color):
            return color
        case .artist(let color):
            return color
        }
    }
}
