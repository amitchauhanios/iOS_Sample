//
//  SortingOption.swift
//  HopSpin
//
//  Created by Antonio Carella on 01.09.2023.
//

import UIKit

/// User facing options
enum OrderOption: String, CaseIterable {
    case ascending = "Ascending Order"
    case descending = "Descending Order"
    
    var sortDirection: SortDirection {
        switch self {
        case .ascending: return .ascending
        case .descending: return .descending
        }
    }
}
