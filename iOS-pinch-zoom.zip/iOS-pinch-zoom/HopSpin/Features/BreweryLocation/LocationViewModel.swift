//
//  LocationViewModel.swift
//  HopSpin
//
//  Created by Antonio Carella on 8/29/23.
//

import SwiftUI
import Combine

class LocationViewModel {
    
    private var locations: [LocationRowViewModel]
    private let refresh: (Int) async throws -> [LocationDisplayable]
    private let id: Int
    
    @Published var locationRowViewModels: [LocationRowViewModel]
    @Published var showLoadingIndicator: Bool = false
    @Published var refreshing: Bool = false
    let viewWillAppearSubject = PassthroughSubject<Void, Never>()
    let showCountSubject = PassthroughSubject<ToastPresentation, Never>()
    let searchTermCurrentValueSubject = CurrentValueSubject<String, Never>("")
    let contentMargins: CGFloat
    private var cancellables = Set<AnyCancellable>()
    
    let name: String
    let tintColor: UIColor
    
    init(
        locations: [LocationDisplayable],
        name: String,
        tintColor: UIColor,
        refresh: @escaping (Int) async throws -> [LocationDisplayable],
        id: Int,
        contentMargins: CGFloat
    ) {
               
        self.locations = []
        self.locationRowViewModels = []
        self.name = name
        self.tintColor = tintColor
        self.refresh = refresh
        self.id = id
        self.contentMargins = contentMargins
       
        searchTermCurrentValueSubject
            .sink { [weak self] searchTerm in
                self?.updateView(for: searchTerm)
            }
            .store(in: &cancellables)
        
        $locationRowViewModels
            .sink { [weak self] viewModels in
                self?.showCountSubject.send(.display(viewModels.count))
            }
            .store(in: &cancellables)
        
        viewWillAppearSubject
            .sink { _ in
                let viewModels = self.locationRowViewModels
                self.locationRowViewModels = viewModels
            }
            .store(in: &cancellables)
        
        let locationViewModels = locations.enumerated().map {
            LocationRowViewModel(
                location: $0.1,
                name: name,
                color: Color(tintColor),
                isFinalRow: $0.0 == locations.count - 1
            )
        }
        
        self.locations = locationViewModels
        self.locationRowViewModels = locationViewModels
    }
    
    private func updateView(for text: String) {
        locationRowViewModels = text.isEmpty ?
        locations :
        locations
            .filter { viewModel in
                viewModel.headerViewModel
                    .name.lowercased()
                    .contains(
                        text.lowercased()
                    )
            }
    }
    
    func refreshLocations() async {
        refreshing = true
        Task {
            do {
                let refreshed = try await refresh(id)
                let refreshedLocationViewModels = refreshed.enumerated().map {
                    LocationRowViewModel(
                        location: $0.1,
                        name: name,
                        color: Color(tintColor),
                        isFinalRow: $0.0 == locations.count - 1
                    )
                }
                DispatchQueue.main.async { [weak self] in
                    guard let self else { return }
                    self.locationRowViewModels = refreshedLocationViewModels
                    self.updateView(for: searchTermCurrentValueSubject.value)
                    refreshing = false
                }
                return
            } catch {
                print(error)
                refreshing = false
            }
        }
    }
    
    func userScrolled(direction: UserScrollDirection) {
        switch direction {
        case .down:
            showCountSubject.send(.animateDown)
        default:
            let total = locationRowViewModels.count
            showCountSubject.send(.animateUp(total))
        }
    }
    
}
