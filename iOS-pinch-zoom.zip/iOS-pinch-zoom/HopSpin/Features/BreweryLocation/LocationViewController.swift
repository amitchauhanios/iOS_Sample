//
//  LocationViewController.swift
//  HopSpin
//
//  Created by Antonio Carella on 4/8/24.
//

import Combine
import UIKit
import SwiftUI

class LocationViewController: TableViewController {
    
    enum Section {
        case one
    }
    
    typealias LocationItemsSnapshot = NSDiffableDataSourceSnapshot<Section, LocationRowViewModel>
    typealias LocationItemsDataSource = UITableViewDiffableDataSource<Section, LocationRowViewModel>
    
    var locationsDataSource: LocationItemsDataSource!
    
    static let cellId = "cellId"
    static let headerId = "headerId"
    
    override var bottomToastBottomConstaintConstant: CGFloat {
        24.0
    }
    
    // MARK: Combine
    private var subscriptions = Set<AnyCancellable>()
    
    private let viewModel: LocationViewModel
    
    init(viewModel: LocationViewModel) {
        self.viewModel = viewModel
        
        super.init()
        
        locationsDataSource = LocationItemsDataSource(tableView: tableView, cellProvider: { tableView, indexPath, viewModel in
            let cell = tableView.dequeueReusableCell(withIdentifier: Self.cellId, for: indexPath)
            let margins = shouldAdjustSafeAreasForMaxScreens() ? 20.0 : 16.0
            
            cell.contentConfiguration = UIHostingConfiguration {
                LocationRow(viewModel: viewModel)
            }.margins(.horizontal, margins)
            
            cell.selectionStyle = .none
            cell.hideSeparator()
            
            return cell
        })
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
        setupTableView()
        bindViewModel()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        viewModel.viewWillAppearSubject.send(())
    }
    
    private func setup() {
        addRefreshControl(color: viewModel.tintColor)
        loadingView.animationStrokeColor = viewModel.tintColor
    }
    
    private func setupTableView() {
        tableView.rowHeight = UITableView.automaticDimension
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: Self.cellId)        
    }
    
    override func constrainTableView() {
        NSLayoutConstraint.activate([
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
    }
    
    override func constrainBottomStack() {
                
        NSLayoutConstraint.activate([
            bottomToast.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            bottomToast.bottomAnchor.constraint(
                equalTo: view.bottomAnchor,
                constant: -bottomToastBottomConstaintConstant
            ),
            bottomToast.heightAnchor.constraint(equalToConstant: 48)
            ]
        )
    }
    
    override func viewSafeAreaInsetsDidChange() {
        // do nothing here
    }
    
    private func bindViewModel() {
        viewModel
            .$locationRowViewModels
            .receive(on: DispatchQueue.main)
            .sink(receiveValue: updateList)
            .store(in: &subscriptions)
        
        viewModel
            .$showLoadingIndicator
            .receive(on: DispatchQueue.main)
            .sink(receiveValue: showLoadingView)
            .store(in: &subscriptions)
        
        viewModel
            .$refreshing
            .receive(on: DispatchQueue.main)
            .sink(receiveValue: handleRefreshControl)
            .store(in: &subscriptions)
        
        viewModel
            .showCountSubject
            .receive(on: DispatchQueue.main)
            .sink { [weak self] presentation in
                self?.showToast(presentation: presentation)
            }
            .store(in: &subscriptions)
    }
    
    private func updateList(viewModels: [LocationRowViewModel]) {
        var snapshot = LocationItemsSnapshot()
        snapshot.appendSections([.one])
        snapshot.appendItems(viewModels, toSection: .one)
        
        locationsDataSource.apply(snapshot, animatingDifferences: false)
    }
    
    override func refreshTriggered() {
        Task {
            await viewModel.refreshLocations()
        }
    }
    
    private func handleRefreshControl(refreshing: Bool) {
        refreshing ?
        showRefreshControl() :
        hideRefreshControl()
    }
    
    override func userScrolled(direction: UserScrollDirection) {
        viewModel.userScrolled(direction: direction)
    }
    
    override func animateBottomToast(visible: Bool, duration: TimeInterval = StyleKit.animationDuration) {
        if visible == bottomToastIsVisible() { return }
        let offsetY = visible ? -bottomToastVOffset : bottomToastVOffset
        
        UIViewPropertyAnimator(duration: duration, curve: .linear) { [weak self] in
            guard let self else { return }
            self.bottomToast.frame = CGRect(
                x: self.bottomToast.frame.minX,
                y: self.view.frame.height + offsetY,
                width: self.bottomToast.frame.width,
                height: self.bottomToast.frame.height
            )
            
            self.view.setNeedsDisplay()
            self.view.layoutIfNeeded()
        }
        .startAnimation()
    }
    
    override var bottomToastVOffset: CGFloat {
        bottomToast.frame.size.height + bottomToastBottomConstaintConstant
    }
    
}
