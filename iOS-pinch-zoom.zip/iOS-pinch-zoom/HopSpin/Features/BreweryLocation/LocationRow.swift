//
//  BreweryLocationRow.swift
//  HopSpin
//
//  Created by Antonio Carella on 8/29/23.
//

import CoreLocation
import SwiftUI
import MapKit

struct LocationRow: View {
    @ObservedObject var viewModel: LocationRowViewModel
    
    var body: some View {        
        VStack(alignment: .leading) {
            LocationRowHeader(viewModel: viewModel.headerViewModel)
                .padding([.bottom], 20.0)
            
            Grid(alignment: .topLeading) {
                ForEach(viewModel.dayHours, id: \.self) { dayHour in
                    GridRow {
                        Text(dayHour.day)
                            .font(.system(size: 17, weight: .semibold))
                            .frame(width: 150, alignment: .leading)
                        Text(dayHour.open)
                            .font(.system(size: 17))
                        Text(dayHour.dash)
                            .font(.system(size: 17))
                        Text(dayHour.close)
                            .font(.system(size: 17))
                    }
                }.padding([.bottom], 5.0)
            }
            
            Map(coordinateRegion: $viewModel.region, annotationItems: viewModel.location) { location in
                MapMarker(coordinate: location.coordinate, tint: viewModel.tintColor)
            }
            .onTapGesture {
                if let mapItem = viewModel.mapItem {
                    mapItem
                        .openInMaps(launchOptions: viewModel.mapOptions)
                }
            }
            .frame(height: 133)
            .padding(EdgeInsets(top: 20, leading: 0.0, bottom: 20.0, trailing: 0.0))
            
            if (!viewModel.isFinalRow) {
                Color(red: 0.235, green: 0.235, blue: 0.263, opacity: 0.36)
                .frame(height: 1.0)
                .padding([.top], 20.0)
            }
        }
        .padding([.top, .bottom], 20.0)
    }
}

class LocationRowViewModel: ObservableObject, Identifiable {
    
    struct LocationCoordinate: Identifiable {
        let id = UUID()
        let coordinate: CLLocationCoordinate2D
    }

    @Published var dayHours: [DayHour]
    @Published var location: [LocationCoordinate] = []
    @Published var region: MKCoordinateRegion
    @Published var tintColor: Color
    @Published var headerViewModel: LocationRowHeaderViewModel
    let mapItem: MKMapItem?
    let mapOptions: [String: Any]?
    let isFinalRow: Bool
    
    init(
        location: LocationDisplayable,
        name: String,
        color: Color,
        isFinalRow: Bool
    ) {
        self.dayHours = Self.formatHours(location: location)
        
        let coordinate = CLLocationCoordinate2D(
            latitude: location.latitude ?? 0.0,
            longitude: location.longitude ?? 0.0
        )
        
        let region = MKCoordinateRegion(
            center: coordinate,
            latitudinalMeters: 600,
            longitudinalMeters: 600
        )
        
        self.location = [LocationCoordinate(coordinate: coordinate)]
        self.region = region
        
        let placemark = MKPlacemark(coordinate: coordinate, addressDictionary: nil)
        
        let mapItem = MKMapItem(placemark: placemark)
        mapItem.name = "\(name) \(location.name)"
        mapItem.phoneNumber = location.phoneNumber
        mapItem.pointOfInterestCategory = .brewery
        
        self.mapItem = mapItem
        self.mapOptions = [
            MKLaunchOptionsMapCenterKey: NSValue(mkCoordinate: coordinate),
            MKLaunchOptionsMapSpanKey: NSValue(mkCoordinateSpan: region.span)
        ]
                    
        self.headerViewModel = LocationRowHeaderViewModel(location: location, tintColor: color)
        self.tintColor = color
                
        
        self.isFinalRow = isFinalRow
    }
    
    private static func formatHours(location: LocationDisplayable) -> [DayHour] {
        guard let openingHours = location.openingHours else { return [] }
        
        return openingHours.compactMap { dayKey, hours in
            if let day = Day(rawValue: dayKey) {
                return DayHour(day: day, open: convertToStandardTime(hours.open), close: convertToStandardTime(hours.close))
            }
            
            return nil
        }
        .sorted(by: { $0.sortOrder < $1.sortOrder } )
    }
    
    private static func convertToStandardTime(_ militaryTime: String?) -> String? {
        guard let militaryTime, !militaryTime.isEmpty else { return nil }
        
        // Formatter to convert the input string to a date
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "H:mm"
        
            // Formatter to output the date in the desired 12-hour format with uppercase AM/PM
            let outputFormatter = DateFormatter()
            outputFormatter.dateFormat = "h:mm a"
            outputFormatter.locale = Locale(identifier: "en_US_POSIX")
            outputFormatter.amSymbol = "AM"
            outputFormatter.pmSymbol = "PM"
            
            // Special case for "24:00"
            if militaryTime == "24:00" {
                return "Noon"
            } else {
                // Convert the input string to a date
                if let date = dateFormatter.date(from: militaryTime) {
                    // Convert the date back to a string in the desired format
                    return outputFormatter.string(from: date)
                } else {
                    // Handle invalid input
                    return nil
                }
            }
    }
    
}

extension LocationRowViewModel: Equatable {
    static func == (lhs: LocationRowViewModel, rhs: LocationRowViewModel) -> Bool {
        lhs.headerViewModel.name == rhs.headerViewModel.name
    }
}

extension LocationRowViewModel: Hashable {
    func hash(into hasher: inout Hasher) {
        hasher.combine(headerViewModel.name)
    }
}

struct DayHour: Identifiable, Hashable, Equatable {
    var id: String {
        get {
            return day
        }
    }
    
    let day: String
    let open: String
    let dash: String
    let close: String
    let sortOrder: Int
    
    init(day: Day, open: String?, close: String?, dash: String = " - ") {
        self.day = day.userFacing
        self.sortOrder = day.sortOrder
        
        if let open, let close {
            self.open = open.replacingOccurrences(of: " (noon)", with: "")
            self.close = close.replacingOccurrences(of: " (midnight)", with: "")
            self.dash = close.isEmpty ? "" : dash
        } else {
            self.open = "Closed"
            self.dash = ""
            self.close = ""
        }
    }
}

enum Day: String {
    case monday
    case tuesday
    case wednesday
    case thursday
    case friday
    case saturday
    case sunday
    
    var userFacing: String {
        switch self {
        case .monday: return "Mondays"
        case .tuesday: return "Tuesdays"
        case .wednesday: return "Wednesdays"
        case .thursday: return "Thursdays"
        case .friday: return "Fridays"
        case .saturday: return "Saturdays"
        case .sunday: return "Sundays"
        }
    }
    
    var sortOrder: Int {
        switch self {
        case .monday: return 0
        case .tuesday: return 1
        case .wednesday: return 2
        case .thursday: return 3
        case .friday: return 4
        case .saturday: return 5
        case .sunday: return 6
        }
    }
}
