//
//  ThreeDWebView.swift
//  HopSpin
//
//  Created by Antonio Carella on 9/8/23.
//

import Combine
import WebKit
import UIKit

enum ThreeDViewError: Error {
    case emptyURL
}

class ThreeDWebView: UIViewController {
    
    private var threeDImageNavigation: WKNavigation?
    
    // MARK: - UI Elements
    private lazy var ellipsesButton: UIBarButtonItem = {
        let symbolConfig = UIImage.SymbolConfiguration(pointSize: 15, weight: .semibold, scale: .large)
        let image = UIImage(systemName: "ellipsis.circle", withConfiguration: symbolConfig)?.withTintColor(.white)
        return UIBarButtonItem(image: image, style: .plain, target: self, action: #selector(ellipsesButtonTapped))
    }()
    
    private lazy var closeButton: UIBarButtonItem = {
        UIBarButtonItem(
            image: UIImage(
                systemName: "xmark",
                withConfiguration: UIImage.SymbolConfiguration(pointSize: 17, weight: .semibold)
            ),
            style: .plain,
            target: self,
            action: #selector(closeTapped)
        )
    }()
    
    private var webView: WKWebView!
    private let loadingView = LoadingView()
    
    // MARK: - Dependencies
    private let viewModel: ThreeDWebViewModel
    
    // MARK: - Combine
    private var subscriptions = Set<AnyCancellable>()
    
    // MARK: - Life Cycle
    init(viewModel: ThreeDWebViewModel) {
        self.viewModel = viewModel
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupView()
        layoutViews()
        bindViewModel()
        
        navigationController?.presentationController?.presentedView?.gestureRecognizers?.forEach {
            $0.isEnabled = false
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationItem.setRightBarButton(ellipsesButton, animated: false)
        navigationItem.setLeftBarButton(closeButton, animated: true)
        viewModel.onViewDidAppear.send(())
        
    }
    
    private func setupView() {
        let configuration = WKWebViewConfiguration()
        configuration.setValue(true, forKey: "allowUniversalAccessFromFileURLs")
        webView = WKWebView(frame: .zero, configuration: configuration)
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        webView.navigationDelegate = self
        title = viewModel.beerName
     
        loadingView.animationStrokeColor = viewModel.tintColor
        
    }
    
    private func layoutViews() {
        view.addSubview(loadingView)
        loadingView.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(webView)
        webView.translatesAutoresizingMaskIntoConstraints = false
        
        
        NSLayoutConstraint.activate([
            webView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            webView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            webView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            webView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            
            loadingView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            loadingView.centerYAnchor.constraint(equalTo: view.centerYAnchor)
        ])
        
    }
    
    // Now, this should be called when the touch intercepting view is touched
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
        print("Touches began in ViewController")
    }
    
    private func bindViewModel() {
        
        viewModel
            .$url
            .receive(on: DispatchQueue.main)
            .compactMap { $0 }
            .sink(receiveValue: load)
            .store(in: &subscriptions)
        
        viewModel
            .$showLoadingView
            .receive(on: DispatchQueue.main)
            .compactMap { $0 }
            .removeDuplicates()
            .sink(receiveValue: showLoadingView)
            .store(in: &subscriptions)
        
        viewModel
            .$errorMessage
            .receive(on: DispatchQueue.main)
            .compactMap { $0 }
            .sink(receiveValue: { [weak self] in
                self?.present(errorMessage: $0)
            })
            .store(in: &subscriptions)
    }
    
    private func load(url: URL) {
        let request = URLRequest(url: url)
        threeDImageNavigation = webView.load(request)
        showLoadingView(show: true)
    }
        
    private func showLoadingView(show: Bool) {
        if show {
            loadingView.isHidden = false
            loadingView.startAnimating()
            view.bringSubviewToFront(loadingView)
        } else {
            loadingView.isHidden = true
            loadingView.stopAnimating()
            view.sendSubviewToBack(loadingView)
        }
    }
    
    @objc private func ellipsesButtonTapped() {
        viewModel.handleElipsesButtonTap()
    }
    
    @objc private func closeTapped() {
        self.dismiss(animated: true)
    }
}

extension ThreeDWebView: MenuViewPresentable {
    func presentMenuView(data: MenuAnd3DData, shouldUpdate: PassthroughSubject<Void, Never>?) {
        let beerCellarPersister = BeerCellarPersistance()
        let menuViewController = MenuViewController(
            viewModel: MenuViewModel(
                data: data,
                persister: beerCellarPersister,
                shouldUpdate: shouldUpdate
            )
        )
        menuViewController.modalPresentationStyle = .pageSheet
        let nav = NavigationController(rootViewController: menuViewController)
        nav.modalPresentationStyle = .pageSheet
        if let sheet = nav.sheetPresentationController {
            let id = UISheetPresentationController.Detent.Identifier("detentId")
            let detent = UISheetPresentationController.Detent.custom(identifier: id) { context in
                return 342
            }
            
            sheet.detents = [
                detent
            ]
        }
        self.present(nav, animated: true, completion: nil)
    }
}

extension ThreeDWebView: WKNavigationDelegate {
    
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        if let threeDImageNavigation, threeDImageNavigation == navigation {
            showLoadingView(show: false)
        }
    }
    
}
