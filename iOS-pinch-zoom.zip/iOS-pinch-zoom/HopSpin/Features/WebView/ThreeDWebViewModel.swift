//
//  ThreeDWebViewModel.swift
//  HopSpin
//
//  Created by Antonio Carella on 9/10/23.
//

import Combine
import Foundation
import UIKit

class ThreeDWebViewModel {
        
    @Published var showLoadingView = false
    @Published var errorMessage: ErrorMessage?
    @Published var url: URL? = nil
    let onViewDidAppear = PassthroughSubject<Void, Never>()
    let beerName: String
    let tintColor: UIColor
    
    private let data: MenuAnd3DData
    private var cancellables = Set<AnyCancellable>()
    private let shouldUpdate: PassthroughSubject<Void, Never>?
    
    weak var menuPresenter: MenuViewPresentable?
    
    init(
        data: MenuAnd3DData,
        shouldUpdate: PassthroughSubject<Void, Never>?
    ) {
        self.data = data
        self.beerName = data.name
        self.shouldUpdate = shouldUpdate
        self.tintColor = data.tintColor
        bindSelf()
    }
            
    private func bindSelf() {
        onViewDidAppear
            .sink { [weak self ] in
                let endpoint = Endpoint(
                    path: "/hopspinmodel/hopspinmodel.php",
                    queryItems: [URLQueryItem(name: "model", value: self?.data.fileName ?? "")],
                    env: App.environment.api
                ).url
                
                self?.url = endpoint
            }
            .store(in: &cancellables)
    }
    
    
    func handleElipsesButtonTap() {
        menuPresenter?.presentMenuView(data: data, shouldUpdate: shouldUpdate)
    }
}
