//
//  PastSearchResultTableViewCell.swift
//  HopSpin
//
//  Created by Antonio Carella on 8/20/23.
//

import UIKit

class PastSearchResultTableViewCell: UITableViewCell {
    
    lazy var label: UILabel = {
        let label = UILabel()
        label.font = UIFont.preferredFont(forTextStyle: .body)
        return label
    }()
    
    private lazy var button: UIButton = {
        let button = UIButton()
        button.setImage(.init(named: "delete-x"), for: .normal)
        button.setTitleColor(Colors.darkGreen, for: .normal)
        button.addAction(UIAction(handler: { [weak self] _ in
            self?.buttonHandler?()
        }), for: .touchUpInside)
        return button
    }()
    
    lazy var hStack: UIStackView = {
        let spacer = UIView()
        let stack = UIStackView(arrangedSubviews: [
            label, spacer
        ])
        
        return stack
    }()
    
    var buttonHandler: (() -> Void)?
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        layout()        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func layout() {
        hStack.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(hStack)
        
        button.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(button)
        
        NSLayoutConstraint.activate([
            hStack.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16.0),
            hStack.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 11.0),
            hStack.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -11.0),
            
            button.leadingAnchor.constraint(equalTo: hStack.trailingAnchor),
            button.topAnchor.constraint(equalTo: contentView.topAnchor),
            button.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
            button.bottomAnchor.constraint(equalTo: contentView.bottomAnchor),
            button.widthAnchor.constraint(equalToConstant: 45)
            
        ])
    }
    
}
