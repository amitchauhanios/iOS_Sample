//
//  SearchTermsPersistable.swift
//  HopSpin
//
//  Created by Antonio Carella on 8/23/23.
//

import Foundation

protocol SearchTermsPersistable {
    func saveSearchTerm(_ term: String) throws
    func fetchAllSearchTerms() throws -> [String]
    func removeSearchTerm(_ term: String) throws
}

import Foundation

class SearchTermsPersistance: SearchTermsPersistable {
    
    private let fileName = "searchTerms.txt"
    
    private var fileURL: URL {
        let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        return documentsDirectory.appendingPathComponent(fileName)
    }
    
    func saveSearchTerm(_ term: String) throws {
        var existingTerms = try fetchAllSearchTerms()
        if !existingTerms.contains(term) {
            existingTerms.append(term)
            let combinedString = existingTerms.joined(separator: "\n")
            try combinedString.write(to: fileURL, atomically: true, encoding: .utf8)
        }
    }
    
    func fetchAllSearchTerms() throws -> [String] {
        guard FileManager.default.fileExists(atPath: fileURL.path) else {
            return []
        }
        let savedTerms = try String(contentsOf: fileURL, encoding: .utf8)
        return savedTerms.split(separator: "\n").map(String.init)
    }
    
    func removeSearchTerm(_ term: String) throws {
        var terms = try fetchAllSearchTerms()
        terms.removeAll { $0 == term }
        let updatedString = terms.joined(separator: "\n")
        try updatedString.write(to: fileURL, atomically: true, encoding: .utf8)
    }
}
