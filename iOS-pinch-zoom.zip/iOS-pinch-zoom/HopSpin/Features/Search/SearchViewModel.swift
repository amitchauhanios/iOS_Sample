//
//  SearchViewModel.swift
//  HopSpin
//
//  Created by Antonio Carella on 8/19/23.
//

import Foundation
import Combine

class SearchViewModel: ObservableObject, Identifiable {
    
    //var delegate: SearchTermExecutedHandler?
    
    // Use as binding to track selected index of Search Control Bar
    private(set) var searchControlSelectedIndex: Int = 0
    
    ///  User provided string to use in the search
    @Published var searchTerm: String = ""
    
    /// Previous Search Terms
    ///  Sort by most recent
    @Published var previousSearches: [String] = []
    @Published var removedPreviousTermSuccessfully: String?
    @Published var errorMessage: ErrorMessage? = nil
    
    private let searchTermsPersister: SearchTermsPersistable
    
    private var disposables = Set<AnyCancellable>()
    
    init(searchTermsPersister: SearchTermsPersistable) {
        self.searchTermsPersister = searchTermsPersister
    }
    
   func fetchPreviousSearchTerms() {
       do {
           previousSearches = try searchTermsPersister.fetchAllSearchTerms()
       } catch {           
           errorMessage = ErrorMessage(title: "Error", subtitle: error.localizedDescription)
           print("Error", error)
       }
    }
    
    func remove(term: String) {
        guard let index = previousSearches.firstIndex(of: term) else {
            errorMessage = .unknown
            return
        }
       
        do {
            try searchTermsPersister.removeSearchTerm(previousSearches[index])
            
            let term = previousSearches[index]
            previousSearches.remove(at: index)
            
            removedPreviousTermSuccessfully = term
        } catch {
            errorMessage = .unknown
        }
    }
    
    func initiateSearch(searchTerm: String) {
        do {
            try searchTermsPersister.saveSearchTerm(searchTerm)
        } catch {
            // TODO: Log error
            print("Error persisting search term", error)
        }
        //delegate?.userExecuted(searchTerm: searchTerm, selectedSegmentIndex: searchControlSelectedIndex)
    }
    
    func beerSegmentedTapped() {
        searchControlSelectedIndex = 0
    }
    
    func brewerySegmentedTapped() {
        searchControlSelectedIndex = 1
    }
    
    func artistSegmentedTapped() {
        searchControlSelectedIndex = 2
    }
}
