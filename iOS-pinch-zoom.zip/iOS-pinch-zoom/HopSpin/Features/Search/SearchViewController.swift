//
//  SearchViewController.swift
//  HopSpin
//
//  Created by Antonio Carella on 8/15/23.
//

import Combine
import UIKit

class SearchViewController: UIViewController {
    
    enum Section {
        case main
    }
    
    // MARK: Dependencies
    private let viewModel: SearchViewModel
    private let apiClient: ApiClient = .live
    
    // MARK: UI Elements
    private lazy var searchController: UISearchController = {
        let searchController = UISearchController(searchResultsController: nil)
        searchController.searchBar.autocapitalizationType = .none
        searchController.searchBar.delegate = self
        searchController.searchBar.tintColor = .white
        searchController.searchBar.searchTextField.backgroundColor = Colors.darkerGreen
        searchController.obscuresBackgroundDuringPresentation = false
        searchController.hidesNavigationBarDuringPresentation = false
        searchController.showsSearchResultsController = false
        
        return searchController
    }()
    
    private lazy var searchControlBar = SearchControlBar(        
        config: .searchView
    )
    
    private let tableView = UITableView()
    
    private var diffableDataSource: UITableViewDiffableDataSource<Section, String>!
    
    private static let pastResultsCellId = "pastResultsCellId"
    
    // MARK: Combine
    private var subscriptions = Set<AnyCancellable>()
    
    init(viewModel: SearchViewModel) {
        self.viewModel = viewModel
        super.init(nibName: nil, bundle: nil)
    }
    
    private func removeTerm(term: String) {
        viewModel.remove(term: term)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupDataSource()
        setupUI()
        bindSelf()
        layout()
        bindViewModel()
    }
    
    private func setupDataSource() {
        self.diffableDataSource = UITableViewDiffableDataSource(tableView: self.tableView) { [viewModel] tableView, indexPath, searchTerm in
            guard let cell = tableView.dequeueReusableCell(withIdentifier: Self.pastResultsCellId, for: indexPath) as? PastSearchResultTableViewCell else {
                assertionFailure("PastSearchResultTableViewCell dequeue issue")
                return UITableViewCell()
            }
            
            cell.label.text = searchTerm
            cell.buttonHandler = {
                viewModel.remove(term: searchTerm)
            }
            
            cell.showStandardSeparator()
            
            return cell
            
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        viewModel.fetchPreviousSearchTerms()
    }
    
    private func setupUI() {
        
        placeLogoInNavBar()
        
        navigationItem.searchController = searchController
        
        // These need to be set here, else they won't get applied, b/c... UIKit
        searchController.searchBar.searchTextField.leftView?.tintColor = Colors.dimmedWhite
        searchController.searchBar.searchTextField.rightView?.tintColor = Colors.dimmedWhite
        searchController.searchBar.searchTextField.textColor = .white
        searchController.searchBar.searchTextField.attributedPlaceholder = NSMutableAttributedString(string: "Search", attributes: [.font: UIFont.systemFont(ofSize: 17.0), .foregroundColor: Colors.dimmedWhite])

        if let searchTextField = searchController.searchBar.value(forKey: "searchField") as? UITextField, let clearButton = searchTextField.value(forKey: "clearButton") as? UIButton {
            let templateImage = clearButton.imageView?.image?.withRenderingMode(.alwaysTemplate)
            clearButton.setImage(templateImage, for: .normal)
            clearButton.tintColor = Colors.dimmedWhite
        }
        
        tableView.register(PastSearchResultTableViewCell.self, forCellReuseIdentifier: Self.pastResultsCellId)
        tableView.delegate = self
        
        searchControlBar.setGalleryOrListSegmentedControl(enabled: false)
        searchControlBar.setFilterAndSortButtons(enabled: false)
    }
    
    private func bindSelf() {
        searchControlBar
            .filterSegmentTap
            .receive(on: DispatchQueue.main)
            .sink { [weak self] index in
                switch index {
                case 0:
                    self?.viewModel.beerSegmentedTapped()
                case 1:
                    self?.viewModel.brewerySegmentedTapped()
                case 2:
                    self?.viewModel.artistSegmentedTapped()
                default:
                    assertionFailure("Case not handled")
                }
            }
            .store(in: &subscriptions)
    }
    
    private func layout() {
        searchControlBar.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(searchControlBar)
        
        tableView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(tableView)
        
        NSLayoutConstraint.activate([
            searchControlBar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            searchControlBar.topAnchor.constraint(equalTo: view.topAnchor),
            searchControlBar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.topAnchor.constraint(equalTo: searchControlBar.bottomAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo:view.bottomAnchor)
            
        ])
    }
    
    private func bindViewModel() {
        viewModel
            .$previousSearches
            .receive(on: DispatchQueue.main)
            .sink(receiveValue: update(searches:))
            .store(in: &subscriptions)
        
        viewModel
            .$errorMessage
            .receive(on: DispatchQueue.main)
            .compactMap { $0 }
            .sink(receiveValue: { [weak self] in
                self?.present(errorMessage: $0)
            })
            .store(in: &subscriptions)
        
    }
    
    private func update(searches: [String]) {
        var snapshot = NSDiffableDataSourceSnapshot<Section, String>()
        snapshot.appendSections([.main])
        snapshot.appendItems(searches)
        diffableDataSource.apply(snapshot, animatingDifferences: true)
    }
    
    private func remove(term: String) {
        var snapshot = self.diffableDataSource.snapshot()
        snapshot.deleteItems([term])
        self.diffableDataSource.apply(snapshot)
    }
}

extension SearchViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let searchTerm = viewModel.previousSearches[indexPath.row]
        viewModel.initiateSearch(searchTerm: searchTerm)
        tableView.deselectRow(at: indexPath, animated: true)
    }
}

extension SearchViewController: UISearchBarDelegate {
    
    func searchBarShouldBeginEditing(_ searchBar: UISearchBar) -> Bool {        
        tableView.blur(radius: 5)
                
        return true
    }
    
    func searchBarShouldEndEditing(_ searchBar: UISearchBar) -> Bool {        
        tableView.unBlur()
        return true
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        guard let text = searchBar.text, !text.isEmpty else {
            return
        }
        viewModel.initiateSearch(searchTerm: text)
    }
    
}
