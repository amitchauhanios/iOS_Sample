//
//  BreweryDetailViewModel.swift
//  HopSpin
//
//  Created by Antonio Carella on 8/24/23.
//

import Combine
import SwiftUI
import Kingfisher

protocol DetailsPresenter {
    func presentLocations(viewModel: LocationViewModel)
    func presentBeers(breweryDetail: BreweryDetail)
    func presentBeers(artistDetail: ArtistDetail)
    func presentArtists(name: String, tint: UIColor)
}

@MainActor
class BreweryDetailViewModel: ObservableObject {
    
    // MARK: Dependencies
    private var breweryDetail: BreweryDetail!
    
    var delegate: DetailsPresenter!
    
    // MARK: Published properties
    
    @Published var name: String = ""
    @Published var logoImage: AsyncImageViewModel = AsyncImageViewModel(url: nil)
    var processor: ImageProcessor = DefaultImageProcessor.default
    @Published var bioText: String = ""
    @Published var webpageDispay: String = ""
    @Published var webpageLink: String = ""
    @Published var emailDispay: String = ""
    @Published var emailLink: String = ""
    @Published var phoneNumberDisplay: String?
    @Published var phoneNumberLink: String?
    @Published var socials: [SocialMediaViewModel] = []
    @Published var showLoadingIndicator = true
    @Published var statusBarStyle: UIStatusBarStyle = .lightContent
    @Published var tintColor: UIColor
    
    // Top level data pairs
    @Published var topLevelDataPairs: [HopSpinDataPairViewModel] = []
        
    @Published var distributesIn: HopSpinDataPairViewModel = .empty
    @Published var shipsTo: HopSpinDataPairViewModel = .empty
    @Published var beerSeries: HopSpinDataPairViewModel = .empty
    @Published var rolesDataPairViewModel: [HopSpinDataPairViewModel] = []
    
    @Published var errorMessage: ErrorMessage? = nil
    
    var locationsViewModel: LocationViewModel? = nil
    
    let imageReadySubject = PassthroughSubject<Bool, Never>()
    let dataReadySubject = PassthroughSubject<Bool, Never>()
    let defaultContentMargins: CGFloat
    
    init(
        breweryFetch: @escaping (Int) async throws -> BreweryDetail,
        brewery: Brewery
    ) {
        self.tintColor = StyleKit.parseUIColor(
            string: brewery.iosHeaderTextColor.coallesceToEmpty,
            fallback: Colors.hopspinGreen
        )
        
        self.defaultContentMargins = shouldAdjustSafeAreasForMaxScreens() ? 20.0 : 16.0
        Task {
            do {
                async let detail = try breweryFetch(brewery.id)
                self.breweryDetail = try await detail
                await update(with: try detail)
                dataReadySubject.send(true)
            } catch {
                let errorMessage = ErrorMessage(title: "Error", subtitle: error.localizedDescription)
                self.errorMessage = errorMessage
                dataReadySubject.send(true)
            }
        }
        
        Publishers
            .CombineLatest(imageReadySubject, dataReadySubject)
            .filter {
                return $0 && $1
            }
            .map { _ in                
                return false
            }
            .assign(to: &$showLoadingIndicator)
    }
    
    private func update(with detail: BreweryDetail) {
                
        self.name = detail.name
        
        self.logoImage = AsyncImageViewModel(
            url: Endpoint.image(path: detail.branding.logo2d).url
        )
        
        self.processor = logoImage.url?.pathExtension == "svg" ? SVGImgProcessor() : DefaultImageProcessor.default
        
        self.bioText = detail.about
        self.webpageDispay = detail.website.webpageDisplayFormat
        self.webpageLink = detail.website
        self.emailDispay = detail.email
        self.emailLink = detail.email.emailFormat
        self.phoneNumberDisplay = detail.locations.first?.phoneNumber
        self.phoneNumberLink = detail.locations.first?.phoneNumber?.phoneLinkFormat
        self.socials = detail.socialMedia
            .compactMap {
                if let linkURL = URL(string: $0.profileAddress),
                let imageURL = Endpoint.image(path: $0.channelIcon).url {
                    return SocialMediaViewModel(
                        id: UUID().uuidString,
                        name: $0.channel,
                        linkURL: linkURL,
                        imageURL: imageURL
                    )
                }
                return nil
            }
        let cityState = HopSpinDataPairViewModel(
            title: "Home Location",
            value: "\(detail.homeCity), \(detail.homeState)".dashIfEmpty
        )
        
        let totalLocations = HopSpinDataPairViewModel(
            title: "Total Locations",
            value: "\(detail.locations.count)".dashIfEmpty
        )
        
        let yearFounded = HopSpinDataPairViewModel(
            title: "Founded",
            value: "\(detail.yearFounded)".dashIfEmpty
        )
        
        let classification = HopSpinDataPairViewModel(
            title: "Classification",
            value: "\(detail.classification)".dashIfEmpty
        )
        
        let distributesInValue = detail.distributionState
            .map { $0.description.getStateAbbreviation() }
            .sorted()
            .joined(separator: ", ")
            .dashIfEmpty
            
        self.distributesIn = HopSpinDataPairViewModel(
            title: "Distributes In",
            value: distributesInValue
        )
        
        let shipsToValue = detail.shippingState
            .map { $0.description.getStateAbbreviation() }
            .sorted()
            .joined(separator: ", ")
            .dashIfEmpty
        
        self.shipsTo = HopSpinDataPairViewModel(
            title: "Ships To",
            value: shipsToValue
        )
        
        let beerSeriesValue = detail.beerSeries
            .compactMap { $0.name }
            .sorted()
            .joined(separator: "\n")
            .dashIfEmpty
        
        self.beerSeries = HopSpinDataPairViewModel(
            title: "Beer Series",
            value: beerSeriesValue
        )
                
        var allRoleDataPairs = TeamMemberFormatter.formatDataPairs(teamMembers: detail.team)
        
        var founder: HopSpinDataPairViewModel = .empty
        let founderDescription = TeamMemberFormatter.parseFounderDescription(from: detail.team)
        if let index = allRoleDataPairs.firstIndex(where: { $0.title == founderDescription }) {
            founder = allRoleDataPairs.remove(at: index)
        }
        
        self.rolesDataPairViewModel = allRoleDataPairs
        
        self.topLevelDataPairs = [
            cityState,
            totalLocations,
            classification,
            yearFounded,
            founder
        ]
        
        let refresh: (Int) async throws -> [LocationDisplayable] = { id in
            let detail = try await ApiClient.live.brewery(id)
            return detail.locations.map {
                BreweryLocationDisplayable(location: $0)
            }
        }
        
        self.locationsViewModel = LocationViewModel(
            locations: detail.locations.map { BreweryLocationDisplayable(location: $0) },
            name: detail.name,
            tintColor: self.tintColor,
            refresh: refresh,
            id: breweryDetail.ID,
            contentMargins: shouldAdjustSafeAreasForMaxScreens() ? 20.0 : 16.0
        )
    }
    
    func presentLocationDetail() {
        guard let viewModel = self.locationsViewModel else {
            self.errorMessage = .unknown
            return
        }
        
        delegate.presentLocations(viewModel: viewModel)
    }
    
    func presentBeers() {
        delegate.presentBeers(breweryDetail: breweryDetail)
    }
    
    func presentArtists() {
        delegate.presentArtists(name: breweryDetail.name, tint: self.tintColor)
    }
}

struct TeamMemberFormatter {
    
    static func formatDataPairs(teamMembers: [TeamMember]) -> [HopSpinDataPairViewModel] {
        teamMembers
            .sorted(by: { $0.firstName < $1.firstName })
            .reduce(into: [HopSpinDataPairViewModel]()) { arr, teamMember in
                // Get each description for the team member, they're returned as, e.g. "Founder, Brewing"
                teamMember.role
                    .forEach { description in
                        // If there is a view model already, update it
                        if let index = arr.firstIndex(where: { viewModel in viewModel.title == description }) {
                            let newValue = "\(arr[index].value)\n\(teamMember.firstName) \(teamMember.lastName)"
                            let newViewModel = HopSpinDataPairViewModel(title: arr[index].title, value: newValue)
                            arr[index] = newViewModel
                        } else {
                            arr.append(
                                HopSpinDataPairViewModel(
                                    title: description,
                                    value: "\(teamMember.firstName) \(teamMember.lastName)"
                                )
                            )
                        }
                    }
            }
            .sorted(by: { $0.title < $1.title })
    }
    
    static func parseFounderDescription(from team: [TeamMember]) -> String? {
        let founder = team
            .filter({ $0.role.contains("Founder") })
            .first
            
            let description = founder?.role
            if let index = founder?.role.firstIndex(of: "Founder") {
                return description?[index]
            }
            return nil
    }
    
}

struct SocialMediaViewModel: Identifiable, Hashable {
    let id: String
    let name: String
    let linkURL: URL
    let imageURL: URL
}
