//
//  BreweryLocationsHostingViewController.swift
//  HopSpin
//
//  Created by Antonio Carella on 9/1/23.
//

import Combine
import UIKit
import SwiftUI

class LocationsHostingViewController: UIViewController {
    
    private let viewModel: LocationViewModel
    private let backGroundView = DarkenedBackgroundView()
    
    private var cancellables = Set<AnyCancellable>()
    
    private lazy var closeButton: UIBarButtonItem = {
        UIBarButtonItem(
            image: UIImage(
                systemName: "xmark",
                withConfiguration: UIImage.SymbolConfiguration(pointSize: 17, weight: .semibold)
            ),
            style: .plain,
            target: self,
            action: #selector(closeTapped)
        )
    }()
    
    private lazy var searchController: UISearchController = {
        let searchController = UISearchController(searchResultsController: nil)
        searchController.searchBar.autocapitalizationType = .none
        searchController.searchBar.delegate = self
        searchController.searchBar.tintColor = .white
        searchController.searchBar.searchTextField.backgroundColor = .white.withAlphaComponent(0.25)
        searchController.searchBar.searchTextField.layer.cornerRadius = StyleKit.cornerRadius
        searchController.searchBar.searchTextField.clipsToBounds = true
        searchController.obscuresBackgroundDuringPresentation = false
        searchController.hidesNavigationBarDuringPresentation = false
        searchController.showsSearchResultsController = false
        
        return searchController
    }()
    
    init(viewModel: LocationViewModel) {
        self.viewModel = viewModel
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        lockModal()
    }
    
    private func setupUI() {
        self.title = viewModel.name
        
        navigationItem.searchController = searchController
        
        view.addSubview(backGroundView)
        backGroundView.translatesAutoresizingMaskIntoConstraints = false
        
        let vc = LocationViewController(viewModel: viewModel)
        let listView = vc.view!
        listView.translatesAutoresizingMaskIntoConstraints = false
        addChild(vc)
        view.addSubview(listView)
        
        NSLayoutConstraint.activate([
            
            backGroundView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            backGroundView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            backGroundView.topAnchor.constraint(equalTo: view.topAnchor),
            backGroundView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            
            listView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            listView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            listView.topAnchor.constraint(equalTo: view.topAnchor),
            listView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
        
        // These need to be set here, else they won't get applied, b/c... UIKit
        searchController.searchBar.searchTextField.leftView?.tintColor = .white
        searchController.searchBar.searchTextField.rightView?.tintColor = .white
        searchController.searchBar.searchTextField.textColor = .white
        searchController.searchBar.searchTextField.attributedPlaceholder = NSMutableAttributedString(string: "Search", attributes: [.font: UIFont.systemFont(ofSize: 17.0), .foregroundColor: UIColor.white])

        if let searchTextField = searchController.searchBar.value(forKey: "searchField") as? UITextField, let clearButton = searchTextField.value(forKey: "clearButton") as? UIButton {
            let templateImage = clearButton.imageView?.image?.withRenderingMode(.alwaysTemplate)
            clearButton.setImage(templateImage, for: .normal)
            clearButton.tintColor = Colors.dimmedWhite
        }
        
        navigationItem.setLeftBarButton(closeButton, animated: false)
        
        vc.didMove(toParent: self)
        
    }
    
    @objc private func closeTapped() {
        navigationController?.dismiss(animated: true)
    }
    
}

extension LocationsHostingViewController: UISearchBarDelegate {
    
    func searchBarShouldBeginEditing(_ searchBar: UISearchBar) -> Bool {
        backGroundView.isHidden = false
        searchBar.placeholder = ""
        view.bringSubviewToFront(backGroundView)
        return true
    }
    
    func searchBarShouldEndEditing(_ searchBar: UISearchBar) -> Bool {
        view.sendSubviewToBack(backGroundView)
        // Hide so we don't see this view during the navigation controller's push transition
        backGroundView.isHidden = true
        return true
    }
    
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
        searchBar.placeholder = "Search"
    }

    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        guard let text = searchBar.text else {
            return
        }
        viewModel.searchTermCurrentValueSubject.send(text)
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        viewModel.searchTermCurrentValueSubject.send("")
    }
}
