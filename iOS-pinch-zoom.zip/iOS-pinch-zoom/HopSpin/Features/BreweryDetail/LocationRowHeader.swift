//
//  BreweryLocationRowHeader.swift
//  HopSpin
//
//  Created by Antonio Carella on 9/3/23.
//

import SwiftUI

struct LocationRowHeader: View {
    @ObservedObject var viewModel: LocationRowHeaderViewModel
    
    var body: some View {
        VStack(alignment: .leading) {
            if !viewModel.name.isEmpty {
                Text(viewModel.name)
                    .font(.system(size: 22, weight: .bold))
            }
            if !viewModel.address.isEmpty {
                Text(viewModel.address)
            }

            if !viewModel.cityStateZip.isEmpty {
                Text(viewModel.cityStateZip)
            }
            
            if let phoneNumber = viewModel.phoneNumberLink,
                let url = URL(string:phoneNumber) {
                Link(
                    viewModel.phoneNumberDisplay ?? "",
                    destination: url
                )
                .foregroundColor(viewModel.tintColor)
            }
        }
    }
}

class LocationRowHeaderViewModel: ObservableObject {
    @Published var name: String
    @Published var address: String
    @Published var cityStateZip: String
    @Published var phoneNumberDisplay: String?
    @Published var phoneNumberLink: String?
    @Published var tintColor: Color
    
    init(
        location: LocationDisplayable,
        tintColor: Color
    ) {
        self.name = location.name
        self.address = location.address1
        self.cityStateZip = "\(location.city), \(location.state) \(location.zipCode)"
        self.phoneNumberDisplay = location.phoneNumber?.phoneDisplayFormat
        self.phoneNumberLink = location.phoneNumber?.phoneLinkFormat
        self.tintColor = tintColor
    }
}

