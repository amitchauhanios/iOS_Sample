//
//  BreweryDetailViewController.swift
//  HopSpin
//
//  Created by Antonio Carella on 8/24/23.
//

import UIKit

class BreweryDetailViewController: UIViewController {
    
    // MARK: UI Elements
    lazy var logoImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFill
        return imageView
    }()
    
    lazy var bioTextField: UITextView = {
        let textView = UITextView()
        textView.font = .systemFont(ofSize: 17.0)
        return textView
    }()
    
    lazy var contactTextField: UITextView = {
        let textView = UITextView()
        textView.font = .systemFont(ofSize: 17.0)
        return textView
    }()
    
    
    
}
