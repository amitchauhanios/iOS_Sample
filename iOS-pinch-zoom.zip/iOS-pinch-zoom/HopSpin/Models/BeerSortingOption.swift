//
//  BeerSortingOption.swift
//  HopSpin
//
//  Created by Antonio Carella on 11/28/23.
//

import Foundation
import OrderedCollections

protocol Sortable: Equatable {
    var isName: Bool { get }
}

enum BeerSortingOption: String, Encodable, CaseIterable, Sortable {
    case distinctAdjuncts = "distinctAdjuncts"
    case distinctAwards = "distinctAwards"
    case distinctHops = "distinctHops"
    case distinctBrandings = "distinctBrandings"
    case abv = "abv"
    case styles = "styles"
    case datePubliclyViewable = "datePubliclyViewable"
    case ibu = "ibu"
    case name = "name"
    case pourColor = "pourColor"
    case primaryLabelColor = "labelColor1IsFeatured"
    case yearFirstReleased = "yearFirstReleased"
    case yearLastReleased = "yearLastReleased"
    case labelStyle = "labelStyle"
    case adjunct = "adjuncts"
    case artist = "collabDesigners"
    case award = "awards"
    case brewery = "brewery"
    case brewerySeries = "brewerySeries"
    case hop = "hops"
    case nonindustryCollab = "collabNonindustries"
    case releaseYear = "releaseYear"

    
    var title: String {
        switch self {
        case .abv: return "ABV %"
        case .datePubliclyViewable: return "Date Added To HopSpin"
        case .ibu: return "IBU"
        case .name: return "Name"
        case .distinctAdjuncts: return "Adjunct (Total #)"
        case .distinctHops: return "Hop (Total #)"
        case .pourColor: return "Pour Color (SRM)"
        case .primaryLabelColor: return "Primary Label Color"
        case .labelStyle: return "Label Style"
        case .yearFirstReleased: return "Year First Released"
        case .yearLastReleased: return "Year Last Released"
        case .distinctAwards: return "Award (Total #)"
        case .distinctBrandings: return "Label Style (Total #)"
        case .styles: return "Beer Style"
        case .adjunct: return "Adjunct"
        case .artist: return "Artist"
        case .award: return "Award"
        case .brewery: return "Brewery"
        case .brewerySeries: return "Brewery Series"
        case .hop: return "Hop"
        case .nonindustryCollab: return "Nonindustry Collab"
        case .releaseYear: return "Year Released"
        }
    }
    
    var isName: Bool {
        self == .name
    }
    
    init(title: String) {
        self = Self.allCases.first { $0.title == title } ?? .name
    }
    
    static var sortedTitles: [String] {
        [
            BeerSortingOption.abv.title,
            BeerSortingOption.adjunct.title,
            BeerSortingOption.distinctAdjuncts.title,
            BeerSortingOption.artist.title,
            BeerSortingOption.award.title,
            BeerSortingOption.distinctAwards.title,
            BeerSortingOption.styles.title,
            BeerSortingOption.brewery.title,
            BeerSortingOption.brewerySeries.title,
            BeerSortingOption.datePubliclyViewable.title,
            BeerSortingOption.hop.title,
            BeerSortingOption.distinctHops.title,
            BeerSortingOption.ibu.title,
            BeerSortingOption.labelStyle.title,
            BeerSortingOption.distinctBrandings.title,
            BeerSortingOption.name.title,
            BeerSortingOption.nonindustryCollab.title,
            BeerSortingOption.pourColor.title,
            BeerSortingOption.primaryLabelColor.title,
            BeerSortingOption.yearFirstReleased.title,
            BeerSortingOption.yearLastReleased.title,
            BeerSortingOption.releaseYear.title
        ]
    }
}
