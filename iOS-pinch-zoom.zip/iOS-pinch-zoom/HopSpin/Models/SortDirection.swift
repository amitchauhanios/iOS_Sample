//
//  SortDirection.swift
//  HopSpin
//
//  Created by Antonio Carella on 11/24/23.
//

import Foundation

/// Server-facing options
enum SortDirection: String, Encodable {
    case ascending = "ascending"
    case descending = "descending"
}
