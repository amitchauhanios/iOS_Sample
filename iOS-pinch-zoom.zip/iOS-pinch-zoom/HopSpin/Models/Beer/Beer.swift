//
//  Beer.swift
//  HopSpin
//
//  Created by Antonio Carella on 8/17/23.
//

import Foundation

class Beer: Decodable, FilteringParamsProtocol, Listable, Nameable, DatePubliclyViewable {
    let id: Int
    let datePubliclyViewable: String?
    let name: String
    let featuredAvatar: String
    let breweryID: Int
    let brewery: String
    let brewerySeries: [String]
    let collabBreweries: [String]
    let collabNonindustries: [String]
    let abv: Double?
    let ibu: Int?
    let releaseSchedule: [String]
    let releaseMethod: [String]
    let releaseContainer: [String]
    let releaseYear: [Int]
    let yearFirstReleased: Int?
    let yearLastReleased: Int?
    let releaseState: [String]
    let distinctAwards: Int
    let awards: [String]
    let hops: [String]
    let distinctHops: Int
    let adjuncts: [String]
    let distinctAdjuncts: Int
    let pourColor: String?
    let styles: [String]
    let distinctBrandings: Int
    let designer: [String]
    let collabDesigners: [String]
    let labelStyle: [String]
    let labelColor1: [String]
    let labelColor1IsFeatured: String?
    let iosHeaderTextColor: String
    let iosHeaderTextColorLight: String
    let iosStatusBarColor: String
    
    lazy var filteringParams: [FilterParam] = {
        createFilterParams(types: BeerFilterType.allCases)
    }()
    
    struct Color: Decodable, Comparable {
        static func < (lhs: Beer.Color, rhs: Beer.Color) -> Bool {
            lhs.text < rhs.text
        }
        
        let url: String
        let text: String
    }
    
    struct CompetitionAward: Decodable {
        let url: String
        let text: String
    }
    
    private enum CodingKeys: String, CodingKey {
        case id = "ID"
        case datePubliclyViewable
        case name
        case featuredAvatar
        case breweryID
        case brewery
        case brewerySeries
        case collabBreweries
        case collabNonindustries
        case abv
        case ibu
        case releaseSchedule
        case releaseMethod
        case releaseContainer
        case releaseYear
        case yearFirstReleased
        case yearLastReleased
        case releaseState
        case distinctAwards
        case awards
        case hops
        case distinctHops
        case adjuncts
        case distinctAdjuncts
        case pourColor
        case styles
        case distinctBrandings
        case designer
        case collabDesigners
        case labelStyle
        case labelColor1
        case labelColor1IsFeatured
        case iosHeaderTextColor
        case iosHeaderTextColorLight
        case iosStatusBarColor
    }
}

extension Beer {
    
    static let noAdjunctsTitle = "(No Adjuncts)"
    static let noArtistsTitle = "(In-House)"
    static let noAwardsTitle = "(No Awards)"
    static let noNonindustriesTitle = "(No Nonindustry Collabs)"
    static let noBrewerySeriesTitle = "(No Brewery Series)"
    
    static let noABVTitle = "(Not Listed)"
    static let noHopTitle = "(Not Listed)"
    static let noIBUTitle = "(Not Listed)"
    static let noPourColorTitle = "(Not Listed)"
}

extension Beer {
    
    static func loadJson(filename fileName: String) -> [Beer]? {
        if let url = Bundle.main.url(forResource: fileName, withExtension: "json") {
            do {
                let data = try Data(contentsOf: url)
                let decoder = JSONDecoder()
                let jsonData = try decoder.decode([Beer].self, from: data)
                return jsonData
            } catch {
                print("error:\(error)")
            }
        }
        return nil
    }
    
    private func createFilterParams(types: [BeerFilterType]) -> [FilterParam] {
        var params = [FilterParam]()
        
        func append(key: String, value: (title: String?, image: String?)) {
            guard let title = value.title else { return }
            var imageURL: URL? {
                guard let image = value.image else { return nil }
                return URL(string: image)
            }
            let value = FilterValue(title: title)
            let param = FilterParam(key: key, value: value)
            if !params.contains(param) { params.append(param) }
        }
        
        for type in types {
            let key = type.title
            switch type {
            case .abv:
                if let abv, let range = ABVRange(doubleValue: abv) {
                    append(key: key, value: (title: range.title, image: nil))
                } else {
                    append(key: key, value: (title: Self.noABVTitle, image: nil))
                }
            case .adjunct:
                if adjuncts.isEmpty {
                    append(key: key, value: (title: Self.noAdjunctsTitle, image: nil))
                }
                
                adjuncts.forEach { adjunct in
                    append(key: key, value: (title: adjunct, image: nil))
                }
            case .awards:
                if awards.isEmpty {
                    append(key: key, value: (title: Self.noAwardsTitle, image: nil))
                }
                
                awards.forEach { award in
                    append(key: key, value: (title: award, image: nil))
                }
            case .brewery:
                append(key: key, value: (title: brewery, image: nil))
            case .collabBrewery:
                // Append collab breweries to the brewery array
                collabBreweries.forEach { collabBrewery in
                    append(key: BeerFilterType.brewery.title, value: (title: collabBrewery, image: nil))
                }
            case .brewerySeries:
                if brewerySeries.isEmpty {
                    append(key: key, value: (title: Self.noBrewerySeriesTitle, image: nil))
                }
                
                self.brewerySeries.forEach { brewerySerie in
                    append(key: key, value: (title: brewerySerie, image: nil))
                }
            case .styles:
                self.styles.forEach { style in
                    append(key: key, value: (title: style, image: nil))
                }
            case .designer:
                if self.collabDesigners.isEmpty {
                    append(key: key, value: (title: Self.noArtistsTitle, image: nil))
                }
                
                self.collabDesigners.forEach { designer in
                    append(key: key, value: (title: designer, image: nil))
                }
            case .hops:
                if self.hops.isEmpty {
                    append(key: key, value: (title: Self.noHopTitle, image: nil))
                }
                
                self.hops.forEach { hop in
                    append(key: key, value: (title: hop, image: nil))
                }
            case .ibu:
                if let ibu {
                    append(key: key, value: (title: IBURange(intValue: ibu).title, image: nil))
                } else {
                    append(key: key, value: (title: Self.noIBUTitle, image: nil))
                }
            case .labelStyle:
                self.labelStyle.forEach { labelStyle in
                    append(key: key, value: (title: labelStyle, image: nil))
                }
            case .nonindustry:
                if self.collabNonindustries.isEmpty {
                    append(key: key, value: (title: Self.noNonindustriesTitle, image: nil))
                }
                
                self.collabNonindustries.forEach { nonIndustry in
                    append(key: key, value: (title: nonIndustry, image: nil))
                }
            case .pourColor:
                if let pourColor {
                    append(key: key, value: (title: pourColor, image: nil))
                } else {
                    append(key: key, value: (title: Self.noPourColorTitle, image: nil))
                }
                
            case .primaryLabelColor:
                append(key: key, value: (title: labelColor1IsFeatured, image: nil))
            case .yearFirstReleased:
                if let yearFirstReleased {
                    append(key: key, value: (title: "\(yearFirstReleased)", image: nil))
                }
            case .yearLastReleased:
                if let yearLastReleased {
                    append(key: key, value: (title: "\(yearLastReleased)", image: nil))
                }
            case .releaseYear:
                self.releaseYear.forEach { releaseYear in
                    append(key: key, value: (title: "\(releaseYear)", image: nil))
                }
            }
        }
        
        return BeerFilterType.sortFilterParams(params: params)
    }
}

extension Beer {
    static let pourColorOrder = [
        "Clear (0)",
        "Very Light (1)",
        "Pale Straw (2)",
        "Straw (3)",
        "Pale Gold (4)",
        "Deep Gold (6)",
        "Pale Amber (9)",
        "Medium Amber (12)",
        "Deep Amber (15)",
        "Amber Brown (18)",
        "Brown (20)",
        "Ruby Brown (24)",
        "Deep Brown (30)",
        "Black (40+)",
        "Blues",
        "Teals",
        "Greens",
        "Yellows",
        "Oranges",
        "Reds",
        "Pinks",
        "Purples",
        "(Not Listed)"
    ]
    
    static let labelColorOrdering = [
        "Blues",
        "Teals",
        "Greens",
        "Yellows",
        "Oranges",
        "Reds",
        "Pinks",
        "Purples",
        "Browns",
        "Tans",
        "Whites",
        "Grays",
        "Blacks",
        "Golds",
        "Silvers",
        "Bronzes"
    ]
}
