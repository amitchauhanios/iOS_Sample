//
//  BeerDetail.swift
//  HopSpin
//
//  Created by Antonio Carella on 8/17/23.
//

import Foundation

struct BeerDetail: Decodable {
    let ID: Int
    let datePubliclyViewable: String
    let name: String
    let featuredAvatar: String
    let about: String?
    let breweryID: Int
    let brewery: String
    let brewerySeries: [String]
    let collabAll: [String]
    let collabBreweries: [String]
    let collabNonindustries: [String]
    let abv: Double?
    let ibu: Int?
    let releaseSchedule: [String]
    let releaseMethod: [String]
    let releaseContainer: [String]
    let releaseYear: [Int]
    let yearFirstReleased: Int?
    let yearLastReleased: Int?
    let releaseState: [String]
    let distinctAwards: Int
    let awards: [Award]
    let hops: [String]
    let distinctHops: Int
    let yeasts: [String]
    let distinctYeasts: Int
    let malts: [String]
    let distinctMalts: Int
    let adjuncts: [String]
    let distinctAdjuncts: Int
    let pourColor: String?
    let pourColorIcon: String?
    let servingTempLow: Float?
    let servingTempHigh: Float?
    let styles: [String]
    let foodPairing: [String]
    let backstory: String?
    let distinctBrandings: Int
    let brandings: [Branding]
    
    struct Award: Decodable {
        let competition: String
        let award: String
        let awardIcon: String
        let awardCategory: String
        let awardYear: Int
    }
}
