//
//  Branding.swift
//  HopSpin
//
//  Created by Antonio Carella on 8/17/23.
//

import Foundation

struct Branding: Decodable {
    let brandingID: Int
    let isEnabled: Bool
    let isFeatured: Bool
    let sortOrder: Int
    let introductionNote: String?
    let designer: String?
    let collabDesigners: [String]
    let yearIntroduced: Int?
    let yearsUsed: [Int]?
    let avatar2d: String
    let hero2d: String
    let label2d: String
    let logo2d: String?
    let model3d: String
    let portrait2d: String
    let labelStyle: String
    let labelColor1: String
    let labelColor1Icon: String
    let labelColor2: String?
    let labelColor2Icon: String?
    let labelColor3: String?
    let labelColor3Icon: String?
    let decalShape: String?
    let printedBackgroundColor: String?
    let printedBackgroundColorIcon: String?
    let volume: String
    let aluminumColor: String?
    let aluminumColorIcon: String?
    let endStyle: String?
    let endColor: String?
    let endColorIcon: String?
    let tabColor: String?
    let tabColorIcon: String?
    let glassColor: String?
    let glassColorIcon: String?
    let closureStyle: String?
    let closureColor: String?
    let closureColorIcon: String?
    let waxColor: String?
    let waxColorIcon: String?
}
