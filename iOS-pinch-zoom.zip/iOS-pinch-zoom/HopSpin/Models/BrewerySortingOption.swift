//
//  BrewerySortingOption.swift
//  HopSpin
//
//  Created by Antonio Carella on 11/28/23.
//

import Foundation

enum BrewerySortingOption: String, Encodable, CaseIterable, Sortable {
    case distinctBeers = "distinctBeers"
    case distinctDistributionStates = "distinctDistributionStates"
    case distinctLocations = "distinctLocations"
    case distinctShippingStates = "distinctShippingStates"
    case classification = "classification"
    case distributionState = "distributionState"
    case shippingState = "shippingState"
    case datePubliclyViewable = "datePubliclyViewable"
    case locationState = "locationState"
    case name = "name"
    case yearFounded = "yearFounded"
    
    var title: String {
        switch self {
        case .distinctBeers: return "Beer (Total #)"
        case .distinctDistributionStates: return "Distribution State (Total #)"
        case .distinctLocations: return "Location State (Total #)"
        case .distinctShippingStates: return "Shipping State (Total #)"
        case .distributionState: return "Distribution State"
        case .shippingState: return "Shipping State"
        case .classification: return "Classification"
        case .datePubliclyViewable: return "Date Added To HopSpin"
        case .locationState: return "Location State"
        case .name: return "Name"
        case .yearFounded: return "Year Founded"
        }
    }
    
    
    var isName: Bool {
        self == .name
    }
    
    init(title: String) {
        self = Self.allCases.first { $0.title == title } ?? .name
    }
    
    static var sortedTitles: [String] {
        [
            BrewerySortingOption.distinctBeers.title,
            BrewerySortingOption.classification.title,
            BrewerySortingOption.datePubliclyViewable.title,
            BrewerySortingOption.distributionState.title,
            BrewerySortingOption.distinctDistributionStates.title,
            BrewerySortingOption.locationState.title,
            BrewerySortingOption.distinctLocations.title,
            BrewerySortingOption.name.title,
            BrewerySortingOption.shippingState.title,
            BrewerySortingOption.distinctShippingStates.title,
            BrewerySortingOption.yearFounded.title
        ]
    }
}
