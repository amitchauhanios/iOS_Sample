//
//  BeerSort.swift
//  HopSpin
//
//  Created by Antonio Carella on 11/28/23.
//

import Foundation

struct BeerSort: Encodable {
    var field: BeerSortingOption
    var direction: SortDirection
}
