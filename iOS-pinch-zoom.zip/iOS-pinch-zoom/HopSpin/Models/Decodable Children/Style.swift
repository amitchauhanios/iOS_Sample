//
//  Style.swift
//  HopSpin
//
//  Created by Antonio Carella on 8/17/23.
//

import Foundation

struct Style: Decodable {
    let id: Int
    let description: String
}
