//
//  ReleaseYear.swift
//  HopSpin
//
//  Created by Antonio Carella on 8/17/23.
//

import Foundation

struct ReleaseYear: Decodable {
    let id: Int
    let description: Int
}
