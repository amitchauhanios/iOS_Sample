//
//  Yeast.swift
//  HopSpin
//
//  Created by Antonio Carella on 8/19/23.
//

import Foundation

struct Yeast: Decodable {
    let id: Int
    let description: String
    let groupName: String
}
