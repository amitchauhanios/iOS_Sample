//
//  Hop.swift
//  HopSpin
//
//  Created by Antonio Carella on 8/17/23.
//

import Foundation

struct Hop: Decodable {
    let id: Int
    let description: String
    let groupName: String
}
