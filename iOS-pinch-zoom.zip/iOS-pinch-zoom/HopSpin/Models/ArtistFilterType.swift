//
//  ArtistFilterType.swift
//  HopSpin
//
//  Created by Antonio Carella on 11/28/23.
//

import Foundation

enum ArtistFilterType: String, CaseIterable {
    case breweries = "Brewery Partner"
    case classifications = "Classification"
    case locationStates = "Location State"
    case yearFounded = "Year Founded"
    
    var title: String {
        self.rawValue
    }
    
    init(title: String) {
        self = Self.allCases.first { $0.title == title } ?? .locationStates
    }
}
