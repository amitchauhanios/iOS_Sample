//
//  BeerSearch.swift
//  HopSpin
//
//  Created by Antonio Carella on 11/24/23.
//

import Foundation

struct BeerSearch: Encodable {
    private var `operator`: String?
    private var name: String?
    private var abv: [ABVRange?]?
    private var adjuncts: [String?]?
    private var awards: [String?]?
    private var styles: [String]?
    private var designer: [String?]?
    private var brewerySeries: [String?]?
    private var brewery: [String]?
    private var hops: [String?]?
    private var ibu: [IBURange?]?
    private var labelStyle: [String]?
    private var nonindustry: [String?]?
    private var pourColor: [String?]?
    private var yearFirstReleased: [String]?
    private var yearLastReleased: [String]?
    private var releaseYear: [String]?
    private var labelColor1IsFeatured: [String]?
    private var sort: [BeerSort]?
    
    
    
    
    init(
        name: String? = nil,
        filters: FiltersAndOperator,
        sortOption: BeerSortingOption? = nil,
        sortDirection: SortDirection? = nil
    ) {
        
        self.operator = filters.filterOperator.rawValue
        
        // Temp vars
        var abv = [ABVRange?]()
        var adjuncts = [String?]()
        var awards = [String?]()
        var styles = [String]()
        var designer = [String?]()
        var brewerySeries = [String?]()
        var brewery = [String]()
        var hops = [String?]()
        var ibu = [IBURange?]()
        var labelStyle = [String]()
        var nonindustry = [String?]()
        var pourColor = [String?]()
        var labelColor1 = [String]()
        var yearFirstReleased = [String]()
        var yearLastReleased = [String]()
        var releaseYear = [String]()
        
        if let name, !name.isEmpty {
            self.name = name
        }
                
        filters.filterParams.forEach({ param in
            let type = BeerFilterType(title: param.key)
            let value = param.value.title

            switch type {
            case .abv:
                if value == Beer.noABVTitle {
                    abv.append(nil)
                } else {
                    abv.append(ABVRange(stringValue: value))
                }
            case .adjunct:
                if value == Beer.noAdjunctsTitle {
                    adjuncts.append(nil)
                } else {
                    adjuncts.append(value)
                }
            case .awards:
                if value == Beer.noAwardsTitle {
                    awards.append(nil)
                } else {
                    awards.append(value)
                }
            case .styles:
                styles.append(value)
            case .designer:
                if value == Beer.noArtistsTitle {
                    designer.append(nil)
                } else {
                    designer.append(value)
                }
            case .brewerySeries:
                if value == Beer.noBrewerySeriesTitle {
                    brewerySeries.append(nil)
                } else {
                    brewerySeries.append(value)
                }
                
            case .hops:
                if value == Beer.noHopTitle {
                    hops.append(nil)
                } else {
                    hops.append(value)
                }
            case .ibu:
                if value == Beer.noIBUTitle {
                    ibu.append(nil)
                } else {
                    if let range = IBURange(title: value) {
                        ibu.append(range)
                    }
                }
            case .labelStyle:
                labelStyle.append(value)
            case .nonindustry:
                if value == Beer.noNonindustriesTitle {
                    nonindustry.append(nil)
                } else {
                    nonindustry.append(value)
                }
            case .pourColor:
                if value == Beer.noPourColorTitle {
                    pourColor.append(nil)
                } else {
                    pourColor.append(value)
                }
            case .primaryLabelColor:
                labelColor1.append(value)
            case .brewery, .collabBrewery:
                brewery.append(value)
            case .yearFirstReleased:
                yearFirstReleased.append(value)
            case .yearLastReleased:
                yearLastReleased.append(value)
            case .releaseYear:
                releaseYear.append(value)
            }
        })
        
        if !abv.isEmpty { self.abv = abv }
        if !adjuncts.isEmpty { self.adjuncts = adjuncts }
        if !awards.isEmpty { self.awards = awards }
        if !styles.isEmpty { self.styles = styles }
        if !designer.isEmpty { self.designer = designer }
        if !brewerySeries.isEmpty { self.brewerySeries = brewerySeries }
        if !brewery.isEmpty { self.brewery = brewery }
        if !hops.isEmpty { self.hops = hops }
        if !ibu.isEmpty { self.ibu = ibu }
        if !labelStyle.isEmpty { self.labelStyle = labelStyle }
        if !nonindustry.isEmpty { self.nonindustry = nonindustry }
        if !pourColor.isEmpty { self.pourColor = pourColor }
        if !labelColor1.isEmpty { self.labelColor1IsFeatured = labelColor1 }
        if !yearFirstReleased.isEmpty { self.yearFirstReleased = yearFirstReleased }
        if !yearLastReleased.isEmpty { self.yearLastReleased = yearLastReleased }
        if !releaseYear.isEmpty { self.releaseYear = releaseYear }
        
        if let sortOption, let sortDirection {
            sort = [BeerSort(field: sortOption, direction: sortDirection)]
        } else {
            sort = [BeerSort(field: .name, direction: .ascending)]
        }
    }
    
    init(name: String) {
        self.name = name
        sort = [BeerSort(field: BeerSortingOption.name, direction: SortDirection.ascending)]
    }
    
}
