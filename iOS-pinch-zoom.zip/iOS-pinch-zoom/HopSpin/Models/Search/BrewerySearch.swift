//
//  BrewerySearch.swift
//  HopSpin
//
//  Created by Antonio Carella on 11/24/23.
//

import Foundation

struct BrewerySearch: Encodable {
    var `operator`: String?
    var name: String?
    var classification: [String]?
    var distributionState: [String?]?
    var locationState: [String]?
    var shippingState: [String?]?
    var yearFounded: [Int]?
    var sort: [BrewerySort]?
    
    init(name: String) {        
        self.name = name
        sort = [BrewerySort(field: .name, direction: SortDirection.ascending)]
    }
    
    init(
        name: String? = nil,
        filters: FiltersAndOperator? = nil,
        sortOption: BrewerySortingOption? = nil,
        sortDirection: SortDirection? = nil
    ) {
        
        self.operator = filters?.filterOperator.rawValue
        
        if let name, !name.isEmpty {
            self.name = name
        }
        
        var classifications = [String]()
        var locationStates = [String]()
        var shippingStates = [String?]()
        var distributionStates = [String]()
        var yearsFounded = [Int]()
        
        filters?.filterParams.forEach({ param in
            let type = BreweryFilterType(title: param.key)
            let value = param.value.title
            
            switch type {
            case .classifications:
                classifications.append(value)
            case .locationStates:
                locationStates.append(value)
            case .yearFounded:
                if let intValue = Int(value) {
                    yearsFounded.append(intValue)
                }
            case .distributionStates:
                distributionStates.append(value)
            case .shippingStates:
                if value == Brewery.noShippingStatesTitle {
                    shippingStates.append(nil)
                } else {
                    shippingStates.append(value)
                }
            }
        })
        
        if !classifications.isEmpty { self.classification = classifications }
        if !locationStates.isEmpty { self.locationState = locationStates }
        if !shippingStates.isEmpty { self.shippingState = shippingStates }
        if !yearsFounded.isEmpty { self.yearFounded = yearsFounded }
        if !distributionStates.isEmpty { self.distributionState = distributionStates }
        
        if let sortOption, let sortDirection {
            sort = [BrewerySort(field: sortOption, direction: sortDirection)]
        } else {
            sort = [BrewerySort(field: .name, direction: .ascending)]
        }
    }
    
}

