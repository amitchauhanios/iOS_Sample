//
//  ArtistSearch.swift
//  HopSpin
//
//  Created by Antonio Carella on 11/24/23.
//

import Foundation

struct ArtistSearch: Encodable {
    var `operator`: String?
    var name: String?
    var breweries: [String]?
    var classification: [String]?
    var locationState: [String]?
    var yearFounded: [Int?]?
    var sort: [ArtistSort]?
    
    init(name: String) {
        self.name = name
        sort = [ArtistSort(field: .name, direction: SortDirection.ascending)]
    }
    
    init(
        name: String? = nil,
        filters: FiltersAndOperator? = nil,
        sortOption: ArtistSortingOption? = nil,
        sortDirection: SortDirection? = nil
    ) {
        
        self.operator = filters?.filterOperator.rawValue
        
        if let name, !name.isEmpty {
            self.name = name
        }
        
        var breweries = [String]()
        var classifications = [String]()
        var locationStates = [String]()
        var yearFounded = [Int?]()
        
        filters?.filterParams.forEach({ param in
            let type = ArtistFilterType(title: param.key)
            let value = param.value.title
            
            switch type {
            case .breweries:
                breweries.append(value)
            case .classifications:
                classifications.append(value)
            case .locationStates:
                locationStates.append(value)
            case .yearFounded:
                if value == Artist.noYearFoundedTitle {
                    yearFounded.append(nil)
                } else if let yearFoundedInt = Int(value) {
                    yearFounded.append(yearFoundedInt)
                }
            }
        })
        
        if !breweries.isEmpty { self.breweries = breweries }
        if !classifications.isEmpty { self.classification = classifications }
        if !locationStates.isEmpty { self.locationState = locationStates}
        if !yearFounded.isEmpty { self.yearFounded = yearFounded }
        
        if let sortOption, let sortDirection {
            sort = [ArtistSort(field: sortOption, direction: sortDirection)]
        } else {
            sort = [ArtistSort(field: .name, direction: .ascending)]
        }
    }
    
}
