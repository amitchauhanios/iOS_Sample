//
//  ArtistSort.swift
//  HopSpin
//
//  Created by Antonio Carella on 11/28/23.
//

import Foundation

struct ArtistSort: Encodable {
    var field: ArtistSortingOption
    var direction: SortDirection
}
