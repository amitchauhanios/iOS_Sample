//
//  BeerFilterType.swift
//  HopSpin
//
//  Created by Antonio Carella on 11/28/23.
//

import Foundation

enum BeerFilterType: String, CaseIterable {
    
    case abv = "ABV %"
    case adjunct = "Adjunct"
    case designer = "Artist"
    case awards = "Award"
    case styles = "Beer Style"
    case brewery = "Brewery"
    case brewerySeries = "Brewery Series"
    case hops = "Hop"
    case ibu = "IBU"
    case labelStyle = "Label Style"
    case nonindustry = "Nonindustry Collab"
    case pourColor = "Pour Color (SRM)"
    case primaryLabelColor = "Primary Label Color"
    case collabBrewery = "Collab Brewery" // Will combine with brewery in Filters UI
    case yearFirstReleased = "Year First Released"
    case yearLastReleased = "Year Last Released"
    case releaseYear = "Year Released"
    
    var title: String {
        self.rawValue
    }
    
    init(title: String) {
        self = Self.allCases.first { $0.title == title } ?? .abv
    }
    
    static var orderedTitles: [String] {
        [
            BeerFilterType.abv.title,
            BeerFilterType.adjunct.title,
            BeerFilterType.designer.title,
            BeerFilterType.awards.title,
            BeerFilterType.styles.title,
            BeerFilterType.brewery.title,
            BeerFilterType.brewerySeries.title,
            BeerFilterType.hops.title,
            BeerFilterType.ibu.title,
            BeerFilterType.labelStyle.title,
            BeerFilterType.nonindustry.title,
            BeerFilterType.pourColor.title,
            BeerFilterType.primaryLabelColor.title,
            BeerFilterType.yearFirstReleased.title,
            BeerFilterType.yearLastReleased.title,
            BeerFilterType.releaseYear.title
        ]
    }
    
    static func sortFilterParams(params: [FilterParam]) -> [FilterParam] {
        
        let sortOrder = Self.orderedTitles
        
        return params.sorted { param1, param2 in
            guard let index1 = sortOrder.firstIndex(of: param1.key),
                  let index2 = sortOrder.firstIndex(of: param2.key) else {
                if sortOrder.contains(param1.key) {
                    return true
                } else if sortOrder.contains(param2.key) {
                    return false
                } else {
                    return param1.key < param2.key
                }
            }

            return index1 < index2
        }
    }
    
}
