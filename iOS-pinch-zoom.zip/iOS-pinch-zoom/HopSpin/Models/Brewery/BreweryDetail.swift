//
//  BreweryDetail.swift
//  HopSpin
//
//  Created by Antonio Carella on 8/17/23.
//

import Foundation

class BreweryDetail: Decodable {
    let ID: Int
    let datePubliclyViewable: String
    let name: String
    let classification: String
    let yearFounded: Int
    let website: String
    let email: String
    let about: String
    let distinctBeers: Int
    let distinctDesigners: Int
    let distinctDistributionStates: Int
    let distributionState: [String]
    let distinctShippingStates: Int
    let shippingState: [String]
    let team: [TeamMember]
    let beerSeries: [BeerSeries]
    let iosHeaderTextColor: String
    let iosHeaderTextColorLight: String
    let iosStatusBarColor: String
    let iosPressHoldColor: String?
    let branding: Branding
    let socialMedia: [SocialMedia]
    let distinctLocations: Int
    let locationState: [String]
    let homeCity: String
    let homeState: String
    let locations: [BreweryLocation]
    
    struct Branding: Decodable {
        let avatar2d: String?
        let label2d: String?
        let logo2d: String
        let model3d: String?
        let portrait2d: String?
    }
    
    struct Distribution: Decodable, Comparable {
        let id: Int
        let description: String
        
        static func < (lhs: Distribution, rhs: Distribution) -> Bool {
            lhs.description < rhs.description
        }
    }
    
    struct ShipsTo: Decodable, Comparable {
        let id: Int
        let description: String
        
        static func < (lhs: ShipsTo, rhs: ShipsTo) -> Bool {
            lhs.description < rhs.description
        }
    }
    
    struct BeerSeries: Decodable {
        let name: String
        let description: String?
    }
    
    struct SocialMedia: Decodable {
        let channel: String
        let channelIcon: String
        let profileName: String
        let profileAddress: String
    }
}

struct BeerSeries: Decodable {
    let id: Int
    let name: String
    let description: String?
}

struct TeamMember: Decodable {
    let firstName: String
    let lastName: String
    let middleName: String?
    let role: [String]
}
