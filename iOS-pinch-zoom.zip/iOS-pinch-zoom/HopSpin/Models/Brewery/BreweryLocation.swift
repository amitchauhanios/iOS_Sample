//
//  BreweryLocation.swift
//  HopSpin
//
//  Created by Antonio Carella on 8/17/23.
//

import Foundation

struct BreweryLocation: Decodable {
    let isHome: Bool
    let type: [String]
    let locationID: Int
    let name: String
    let address1: String
    let address2: String?
    let address3: String?
    let zipCode: String
    let city: String
    let state: String
    let country: String
    let phoneCallingCode: Int?
    let phoneNumber: String?
    let latitude: Double
    let longitude: Double
    let placeID: String
    let openingHours: [String: OpeningHour]
}

struct BreweryLocationDisplayable: LocationDisplayable {
    var isHome: Bool
    var type: [String]
    var locationID: Int
    var name: String
    var address1: String
    var address2: String?
    var address3: String?
    var zipCode: String
    var city: String
    var state: String
    var country: String
    var phoneCallingCode: Int?
    var phoneNumber: String?
    var latitude: Double?
    var longitude: Double?
    var placeID: String?
    var openingHours: [String : OpeningHour]?
    
    init(location: BreweryLocation) {
        self.isHome = true
        self.type = []
        self.locationID = location.locationID
        self.name = location.name
        self.address1 = location.address1
        self.address2 = location.address2
        self.address3 = location.address3
        self.zipCode = location.zipCode
        self.city = location.city
        self.state = location.state
        self.country = location.country
        self.phoneCallingCode = location.phoneCallingCode
        self.phoneNumber = location.phoneNumber
        self.latitude = location.latitude
        self.longitude = location.longitude
        self.placeID = location.placeID
        self.openingHours = location.openingHours
    }
}


struct OpeningHour: Decodable {
    let open: String?
    let close: String?
}

extension BreweryLocation: Comparable {
    static func < (lhs: BreweryLocation, rhs: BreweryLocation) -> Bool {
        lhs.name < rhs.name
    }
    
    static func == (lhs: BreweryLocation, rhs: BreweryLocation) -> Bool {
        lhs.placeID == rhs.placeID
    }
}
