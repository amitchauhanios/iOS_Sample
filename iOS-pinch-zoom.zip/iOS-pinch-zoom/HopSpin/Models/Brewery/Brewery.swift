//
//  Brewery.swift
//  HopSpin
//
//  Created by Antonio Carella on 8/17/23.
//

import Foundation

protocol Nameable {
    var name: String { get }
}

protocol DatePubliclyViewable {
    var datePubliclyViewable: String? { get }
}

class Brewery: Decodable, FilteringParamsProtocol, Listable, Nameable, DatePubliclyViewable {
    
    let id: Int
    let datePubliclyViewable: String?
    let name: String
    let classification: String
    let yearFounded: Int
    let distinctBeers: Int
    let distinctDesigners: Int
    let distinctDistributionStates: Int
    let distributionState: [String]
    let distinctShippingStates: Int
    let shippingState: [String]
    let distinctLocations: Int
    let locationState: [String]
    let homeCity: String
    let homeState: String
    let iosHeaderTextColor: String?
    let iosHeaderTextColorLight: String?
    let iosStatusBarColor: String?
    
    
    lazy var filteringParams: [FilterParam] = {
        createFilterParams(types: BreweryFilterType.allCases)
    }()
    
    private enum CodingKeys: String, CodingKey {
        case id = "ID"
        case datePubliclyViewable
        case name
        case classification
        case yearFounded
        case distinctBeers
        case distinctDesigners
        case distinctDistributionStates
        case distributionState
        case distinctShippingStates
        case shippingState
        case distinctLocations
        case locationState
        case homeCity
        case homeState
        case iosHeaderTextColor
        case iosHeaderTextColorLight
        case iosStatusBarColor
    }
}

extension Brewery {
    static let noShippingStatesTitle = "(Does Not Ship)"
}

extension Brewery: Hashable {
    static func == (lhs: Brewery, rhs: Brewery) -> Bool {
        lhs.id == rhs.id
    }
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(self.id)
    }
}

extension Brewery {
    
    private func createFilterParams(types: [BreweryFilterType]) -> [FilterParam] {
        var params = [FilterParam]()
        
        func append(key: String, value: (title: String?, image: String?)) {
            guard let title = value.title else { return }
            var imageURL: URL? {
                guard let image = value.image else { return nil }
                return URL(string: image)
            }
            let value = FilterValue(title: title)
            let param = FilterParam(key: key, value: value)
            params.append(param)
        }
        
        for type in types {
            let key = type.title
            switch type {
            case .classifications:
                append(key: key, value: (title: classification, image: nil))
            case .locationStates:
                locationState.forEach { state in                    
                    append(key: key, value: (title: state, image: nil))
                }
            case .distributionStates:
                distributionState.forEach { state in
                    append(key: key, value: (title: state, image: nil))
                }
            case .shippingStates:
                
                if shippingState.isEmpty {
                    append(key: key, value: (title: Self.noShippingStatesTitle, image: nil))
                }
                
                shippingState.forEach { state in
                    append(key: key, value: (title: state, image: nil))
                }
            case .yearFounded:
                append(key: key, value: (title: "\(yearFounded)", image: nil))
            }
        }
        
        
        
        return params
    }
    
    private func sort(params: [FilterParam], on type: BreweryFilterType) -> [FilterParam] {
        switch type {
        case .classifications:
            let ordering = [
                "Macro Brewery",
                "Regional Brewery",
                "Micro Brewery",
                "Nano Brewery",
                "Pico Brewery",
                "Home Brewery"
            ]
            
            return params.sorted {
                guard let first = ordering.firstIndex(of: $0.value.title),
                      let second = ordering.firstIndex(of: $1.value.title)
                else {
                    return false
                }
                return first > second
            }
            
        case .distributionStates:
            return params.sorted { $0.value.title.localizedStandardCompare($1.value.title) == .orderedAscending }
        case .locationStates:
            return params.sorted { $0.value.title.localizedStandardCompare($1.value.title) == .orderedAscending }
        case .shippingStates:
            return params.sorted { $0.value.title.localizedStandardCompare($1.value.title) == .orderedAscending }
        case .yearFounded:
            return params.sorted { $0.value.title.localizedStandardCompare($1.value.title) == .orderedAscending }
        }
    }
}

extension Brewery {
    
    static let mock: Brewery = {
        let jsonString = """
        {
            "ID": 1,
            "avatar": null,
            "name": "Revolution Brewing",
            "home_state": "IL",
            "home_city": "Chicago",
            "locations": 2,
            "distribution_states": 11,
            "is_publicly_viewable": 1,
            "date_publicly_viewable": "2023-08-23 09:06:31",
            "date_created": "2023-06-05 17:27:51",
            "ios_brewery_color": "rgba(234, 0, 41, 1)",
            "ios_brewery_color_light": "rgba(234, 0, 41, 0.5)"
        }
        """
        
        let jsonData = jsonString.data(using: .utf8)!
        let decoder = JSONDecoder()
        let brewery = try! decoder.decode(Brewery.self, from: jsonData)
        return brewery
    }()
    
}
