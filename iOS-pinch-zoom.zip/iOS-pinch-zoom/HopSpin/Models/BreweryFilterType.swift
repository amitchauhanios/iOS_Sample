//
//  BreweryFilterType.swift
//  HopSpin
//
//  Created by Antonio Carella on 11/28/23.
//

import Foundation

enum BreweryFilterType: String, CaseIterable {
    case classifications = "Classification"
    case distributionStates = "Distribution State"
    case locationStates = "Location State"
    case shippingStates = "Shipping State"
    case yearFounded = "Year Founded"
    
    var title: String {
        self.rawValue
    }
    
    init(title: String) {
        self = Self.allCases.first { $0.title == title } ?? .classifications
    }
}
