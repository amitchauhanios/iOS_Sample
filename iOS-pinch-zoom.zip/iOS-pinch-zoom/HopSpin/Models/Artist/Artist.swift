//
//  Artist.swift
//  HopSpin
//
//  Created by Antonio Carella on 8/20/23.
//

import Foundation

import Foundation

class Artist: Decodable, FilteringParamsProtocol, Listable, Nameable, DatePubliclyViewable {
        let id: Int
        let name: String
        let classification: String
        let yearFounded: Int?
        let breweries: [String]?
        let datePubliclyViewable: String?
        let homeCity: String
        let homeState: String
        let distinctLocations: Int
        let locationState: [String]
        let distinctBeers: Int
        let distinctBreweries: Int
        let iosHeaderTextColor: String?
        let iosHeaderTextColorLight: String?
        let iosStatusBarColor: String?
    
    private enum CodingKeys: String, CodingKey {
            case id = "ID"
            case name
            case classification
            case yearFounded
            case breweries
            case datePubliclyViewable
            case homeCity
            case homeState
            case distinctLocations
            case locationState
            case distinctBeers
            case distinctBreweries
            case iosHeaderTextColor
            case iosHeaderTextColorLight
            case iosStatusBarColor
        }
    
    lazy var filteringParams: [FilterParam] = {
        createFilterParams(types: ArtistFilterType.allCases)
    }()
    
    private func createFilterParams(types: [ArtistFilterType]) -> [FilterParam] {
        var params = [FilterParam]()
        
        func append(key: String, value: (title: String?, image: String?)) {
            guard let title = value.title else { return }
            var imageURL: URL? {
                guard let image = value.image else { return nil }
                return URL(string: image)
            }
            let value = FilterValue(title: title)
            let param = FilterParam(key: key, value: value)
            params.append(param)
        }
        
        for type in types {
            let key = type.title
            switch type {
            case .breweries:
                breweries?.forEach { brewery in
                    append(key: key, value: (title: brewery, image: nil))
                }
            case .classifications:
                append(key: key, value: (title: classification, image: nil))
            case .locationStates:
                locationState.forEach { state in
                    append(key: key, value: (title: state, image: nil))
                }
            case .yearFounded:
                if let yearFounded {
                    append(key: key, value: (title: "\(yearFounded)", image: nil))
                } else {
                    append(key: key, value: (title: Self.noYearFoundedTitle, image: nil))
                }
            }
        }
        
        return params
    }
}

extension Artist {
    static let noYearFoundedTitle = "(Not Listed)"
}
