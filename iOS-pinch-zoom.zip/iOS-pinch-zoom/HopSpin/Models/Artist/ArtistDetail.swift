//
//  ArtistDetail.swift
//  HopSpin
//
//  Created by Antonio Carella on 8/20/23.
//

import Foundation

import Foundation

class ArtistDetail: Decodable, FilteringParamsProtocol {
    let ID: Int
    let name: String
    let classification: String  
    let yearFounded: Int?
    let website: String?
    let email: String?
    let about: String?
    let datePubliclyViewable: String
    let homeCity: String
    let homeState: String
    let distinctLocations: Int
    let locationState: [String]
    let distinctBeers: Int
    let distinctBreweries: Int
    let distinctBrandings: Int
    let breweries: [String]
    let branding: Branding
    let team: [TeamMember]
    let socialMedia: [SocialMedia]
    let locations: [Location]
    let iosHeaderTextColor: String?
    let iosHeaderTextColorLight: String?
    let iosStatusBarColor: String?
    let iosPressHoldColor: String?
    
    lazy var filteringParams: [FilterParam] = {
        createFilterParams(types: ArtistFilterType.allCases)
    }()
    
    struct Branding: Decodable {
        let avatar2d: String?
        let label2d: String?
        let logo2d: String?
        let portrait2d: String?
        let model3d: String?
    }

    struct SocialMedia: Decodable {
        let channel: String
        let channelIcon: String
        let profileName: String
        let profileAddress: String
    }

    struct Location: Decodable, Comparable {
        let locationID: Int
        let name: String?
        let address1: String?
        let address2: String?
        let address3: String?
        let zipCode: String?
        let city: String
        let state: String
        let country: String?
        let phoneCallingCode: Int?        
        let phoneNumber: String?
        let latitude: Double?
        let longitude: Double?
        let place: String?

        static func < (lhs: ArtistDetail.Location, rhs: ArtistDetail.Location) -> Bool {
            (lhs.name ?? "") < (rhs.name ?? "")
        }
    }
}

extension ArtistDetail {

    private func createFilterParams(types: [ArtistFilterType]) -> [FilterParam] {
        var params = [FilterParam]()

        func append(key: String, value: (title: String?, image: String?)) {
            guard let title = value.title else { return }
            var imageURL: URL? {
                guard let image = value.image else { return nil }
                return URL(string: image)
            }
            let value = FilterValue(title: title)
            let param = FilterParam(key: key, value: value)
            params.append(param)
        }

        for type in types {
            let key = type.title
            switch type {
            case .breweries:
                breweries.forEach { brewery in
                    append(key: key, value: (title: brewery, image: nil))
                }
            case .classifications:
                append(key: key, value: (title: classification, image: nil))
            case .locationStates:
                locations.forEach {
                    append(key: key, value: (title: $0.name, image: nil))
                }
            case .socialMediaAccounts:
                socialMedia.forEach {
                    append(key: key, value: (title: $0.channel, image: $0.channelIcon))
                }
            }
        }

        return params
    }

    private enum ArtistFilterType: String, CaseIterable {
        case breweries = "Brewery Partner"
        case classifications = "Classification"
        case locationStates = "Location State"
        case socialMediaAccounts = "Social Media Accounts"

        var title: String {
            self.rawValue
        }
    }
}
