//
//  BrewerySort.swift
//  HopSpin
//
//  Created by Antonio Carella on 11/28/23.
//

import Foundation

struct BrewerySort: Encodable {
    var field: BrewerySortingOption
    var direction: SortDirection
}
