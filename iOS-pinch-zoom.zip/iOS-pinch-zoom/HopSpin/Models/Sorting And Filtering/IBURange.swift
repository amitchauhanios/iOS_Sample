//
//  IBURange.swift
//  HopSpin
//
//  Created by Antonio Carella on 11/28/23.
//

import Foundation

enum IBURange: String, Encodable, CaseIterable {
    case from0to14_9
    case from15to29_9
    case from30to44_9
    case from45to59_9
    case from60to74_9
    case from75to89_9
    case from90up
    
    var title: String {
        switch self {
        case .from0to14_9: return "0.0 – 14.9"
        case .from15to29_9: return "15.0 – 29.9"
        case .from30to44_9: return "30.0 – 44.9"
        case .from45to59_9: return "45.0 – 59.9"
        case .from60to74_9: return "60.0 – 74.9"
        case .from75to89_9: return "75.0 – 89.9"
        case .from90up: return "90.0+"
        }
    }
    
    init?(title: String) {
        if let found = Self.allCases.first(where: { $0.title == title }) {
            self = found
            return
        } else {
            return nil
        }
    }
    
    init(intValue: Int) {

            switch intValue {
            case 0..<15:
                self = .from0to14_9
            case 15..<30:
                self = .from15to29_9
            case 30..<45:
                self = .from30to44_9
            case 45..<60:
                self = .from45to59_9
            case 60..<75:
                self = .from60to74_9
            case 75..<90:
                self = .from75to89_9
            case 90...:
                self = .from90up
            default:
                assertionFailure("IBU double value not in acceptable range")
                self = .from90up
            }
        }
}
