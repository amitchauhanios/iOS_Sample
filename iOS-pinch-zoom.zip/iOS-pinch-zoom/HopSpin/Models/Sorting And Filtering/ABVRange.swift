//
//  ABVRange.swift
//  HopSpin
//
//  Created by Antonio Carella on 11/28/23.
//

import Foundation

enum ABVRange: String, Encodable, CaseIterable {
    
    case from0to2_9
    case from3to5_9
    case from6to8_9
    case from9to11_9
    case from12to14_9
    case from15to17_9
    case from18to20_9
    case from21up
    
    var title: String {
        switch self {
        case .from0to2_9: return "0.0 – 2.9"
        case .from3to5_9: return "3.0 – 5.9"
        case .from6to8_9: return "6.0 – 8.9"
        case .from9to11_9: return "9.0 – 11.9"
        case .from12to14_9: return "12.0 – 14.9"
        case .from15to17_9: return "15.0 – 17.9"
        case .from18to20_9: return "18.0 – 20.9"
        case .from21up: return "21.0+"
        }
        
    }
    
    init?(doubleValue: Double?) {
            guard let doubleValue else { return nil }
            switch doubleValue {
            case 0...2.9:
                self = .from0to2_9
            case 3...5.9:
                self = .from3to5_9
            case 6...8.9:
                self = .from6to8_9
            case 9...11.9:
                self = .from9to11_9
            case 12...14.9:
                self = .from12to14_9
            case 15...17.9:
                self = .from15to17_9
            case 18...20.9:
                self = .from18to20_9
            case 20...:
                self = .from21up
            default:
                return nil
            }
    }
    
    init(stringValue: String) {
           // Split the string by the dash to get the range values
           let rangeComponents = stringValue.split(separator: "–").map { $0.trimmingCharacters(in: CharacterSet(charactersIn: "0123456789.").inverted) }

           // Function to determine the enum case based on a single value
           func enumForValue(_ value: Double) -> ABVRange? {
               switch value {
               case 0...2.9:
                   return .from0to2_9
               case 3...5.9:
                   return .from3to5_9
               case 6...8.9:
                   return .from6to8_9
               case 9...11.9:
                   return .from9to11_9
               case 12...14.9:
                   return .from12to14_9
               case 15...17.9:
                   return .from15to17_9
               case 18...20.9:
                   return .from18to20_9
               case 20...:
                   return .from21up
               default:
                   return .from21up
               }
           }

           // Determine the range based on the number of components
           switch rangeComponents.count {
           case 1:
               if let value = Double(rangeComponents[0]) {
                   self = enumForValue(value) ?? .from0to2_9 // Default case or nil handling
               } else {
                    assertionFailure("ABV init")
                   self = .from21up
               }
           case 2:
               if let lowerBound = Double(rangeComponents[0]),
                  let upperBound = Double(rangeComponents[1]),
                  let lowerEnum = enumForValue(lowerBound),
                  let upperEnum = enumForValue(upperBound),
                  lowerEnum == upperEnum {
                   self = lowerEnum
               } else {
                   assertionFailure("ABV init")
                   self = .from21up
               }
           default:
               assertionFailure("ABV init")
               self = .from21up
           }
       }
}
