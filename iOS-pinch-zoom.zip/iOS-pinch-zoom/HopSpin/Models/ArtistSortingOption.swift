//
//  ArtistSortingOption.swift
//  HopSpin
//
//  Created by Antonio Carella on 11/28/23.
//

import Foundation

enum ArtistSortingOption: String, CaseIterable, Encodable, Sortable {
    case breweries
    case distinctBreweries
    case classification
    case datePubliclyViewable
    case distinctBrandings
    case locationState
    case name
    case yearFounded

    var title: String {
        switch self {
        case .breweries: return "Brewery Partner"
        case .distinctBreweries: return "Brewery Partner (Total #)"
        case .classification: return "Classification"
        case .datePubliclyViewable: return "Date Added To HopSpin"
        case .distinctBrandings: return "Label Style (Total #)"
        case .locationState: return "Location State"
        case .name: return "Name"
        case .yearFounded: return "Year Founded"
        }
    }
    
    var isName: Bool {
        self == .name
    }
    
    init(title: String) {
        self = Self.allCases.first { $0.title == title } ?? .name
    }
}
