//
//  SettingDetail_IC.swift
//  iWatchSettingsDemo WatchKit Extension
//
//  Created by Ongraph on 24/05/22.
//

import WatchKit
import Foundation


class SettingDetail_IC: WKInterfaceController {
    
    var title:String = "Settings"

    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        self.setTitle(title)
        
        // Configure interface objects here.
    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

}
