//
//  InterfaceController.swift
//  iWatchSettingsDemo WatchKit Extension
//
//  Created by Ongraph on 24/05/22.
//

import WatchKit
import Foundation


class InterfaceController: WKInterfaceController {
    
    @IBOutlet weak var tblSettings:WKInterfaceTable!

    
    var SettingsList = ["Notification", "General", "Focus", "Airplane mode", "Wifi", "Cellular","Display & Brightness","Blutooth","App view","Doc","Accessbility","Spotify"]
    var SettingsImagesList = ["notification", "brightness", "settings", "flightmode","notification", "brightness", "settings", "flightmode","notification", "brightness", "settings", "flightmode"]
    

    override func awake(withContext context: Any?) {
        // Configure interface objects here.
        super.awake(withContext: context)
        tblSettings.setNumberOfRows(SettingsList.count, withRowType: "row")
        setupTable()

    }
    

    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
    }
    
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
    }
    func setupTable() {
//        tblSettings.setNumberOfRows(SettingsList.count, withRowType: "row")
        
        for (i,_) in SettingsList.enumerated() {
            if let row = tblSettings.rowController(at: i) as? TableRowController {
                row.lblSetting.setText(SettingsList[i])
                debugPrint("image is \(SettingsImagesList[i])")
                row.imgSetting?.setImage(UIImage(named: SettingsImagesList[i]))
            }
        }
    }
    
  override func table(_ table: WKInterfaceTable,
               didSelectRowAt rowIndex: Int){
        
        pushController(withName: "SettingDetail_IC", context: true)
    }

}

class TableRowController: NSObject {
    @IBOutlet weak var lblSetting: WKInterfaceLabel!
    @IBOutlet weak var imgSetting: WKInterfaceImage!

}
