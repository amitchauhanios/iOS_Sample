//
//  ViewController.swift
//  SaveAndFetch
//
//  Created by Ongraph on 22/12/21.
//

import UIKit

class ViewController: UIViewController {

    var arrPdf : [String]? 
    
    @IBOutlet weak var collectionView: UICollectionView!{
        didSet{
            self.collectionView.delegate = self
            self.collectionView.dataSource = self
//            self.collectionView.estimatedRowHeight = 200
//            self.collectionView.rowHeight = UIcollectionView.automaticDimension
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.collectionView.register(UINib(nibName: DownloadPdfCollectionCell.identifier, bundle: nil), forCellWithReuseIdentifier: DownloadPdfCollectionCell.identifier)

        // Do any additional setup after loading the view.
    }

    @IBAction func btnSaveAction(_ sender: Any) {
//    https://www.tutorialspoint.com/swift/swift_tutorial.pdf
        //http://www.africau.edu/images/default/sample.pdf

        let pdfURL = "http://www.africau.edu/images/default/sample.pdf"
        let url = URL(string: pdfURL)
        let fileName = String((url!.lastPathComponent))
        
        if (self.fileExist(strname: fileName)){
            // already exist in document directory
        }else{
            // not exist in document directory
            self.savePdfFileinDirectoryWith(fileURL: pdfURL, fileName: fileName)
        }
    }
    
    @IBAction func btnFetchAction(_ sender: Any) {
        self.fetchAllPdffiles()
    }
    
    func savePdfFileinDirectoryWith(fileURL : String, fileName : String){
        // Create destination URL
        let documentsUrl:URL =  FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let destinationFileUrl = documentsUrl.appendingPathComponent("\(fileName)")
        print("destinationFileUrl: \(destinationFileUrl)")

        //Create URL to the source file you want to download
        let fileURL = URL(string: fileURL)
        let sessionConfig = URLSessionConfiguration.default
        let session = URLSession(configuration: sessionConfig)
        let request = URLRequest(url:fileURL!)
        let task = session.downloadTask(with: request) { (tempLocalUrl, response, error) in
            if let tempLocalUrl = tempLocalUrl, error == nil {
                // Success
                print("tempLocalUrl: \(tempLocalUrl)")
                if let statusCode = (response as? HTTPURLResponse)?.statusCode {
                    print("Successfully downloaded. Status code: \(statusCode)")
                }
                do {
//                    try FileManager.default.removeItem(at: destinationFileUrl)
                    // Amit
                    try FileManager.default.copyItem(at: tempLocalUrl, to: destinationFileUrl)
                    do {
                        //Show UIActivityViewController to save the downloaded file
//                        let contents  = try FileManager.default.contentsOfDirectory(at: documentsUrl, includingPropertiesForKeys: nil, options: .skipsHiddenFiles)
//                        for indexx in 0..<contents.count {
//                            if contents[indexx].lastPathComponent == destinationFileUrl.lastPathComponent {
//                                DispatchQueue.main.async {
//                                    let activityViewController = UIActivityViewController(activityItems: [contents[indexx]], applicationActivities: nil)
//                                    self.present(activityViewController, animated: true, completion: nil)
//                                }
//                            }
//                        }
                    }
                    catch (let err) {
                        print("error: \(err)")
                    }
                } catch (let writeError) {
                    print("Error creating a file \(destinationFileUrl) : \(writeError)")
                }
            } else {
                print("Error took place while downloading a file. Error description: \(error?.localizedDescription ?? "")")
            }
        }
        task.resume()
    }
    
    
    func fetchAllPdffiles(){
        // Get the document directory url
        let documentsUrl =  FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        do {
            // Get the directory contents urls (including subfolders urls)
            let directoryContents = try FileManager.default.contentsOfDirectory(at: documentsUrl, includingPropertiesForKeys: nil)
            // if you want to filter the directory contents you can do like this:
            let mp3Files = directoryContents.filter{ $0.pathExtension == "pdf" }
//            let mp3FileNames = mp3Files.map{ $0.deletingPathExtension().lastPathComponent }
            let mp3FileNames = mp3Files.map{ $0.lastPathComponent }

            self.arrPdf = mp3FileNames
            self.collectionView.reloadData()
        } catch {
            print(error)
        }
    }
    
    func clearAllFilesFromTempDirectory(strname : String){
        let dirPath =  FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let destinationFileUrl = dirPath.appendingPathComponent("\(strname)")
        do {
            try FileManager.default.removeItem(at: destinationFileUrl)
            self.fetchAllPdffiles()
        }
        catch {
            print(error)
        }
    }
    
    func fileExist(strname : String) -> Bool{
        let dirPath =  FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let destinationFileUrl = dirPath.appendingPathComponent("\(strname)")
        let fileExists = FileManager().fileExists(atPath: destinationFileUrl.path)
        return fileExists
    }
}


extension ViewController : UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout{
    
//    func numberOfSections(in collectionView: UICollectionView) -> Int {
//        return 2
//    }
    
//    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
//
//        let headerView = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "HowToUseHeaderView", for: indexPath) as! HowToUseHeaderView
//        headerView.lblTitle.text = self.viewModel?.arrData?[indexPath.section].title ?? ""
//        return headerView
//    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.arrPdf?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: DownloadPdfCollectionCell.identifier, for: indexPath) as? DownloadPdfCollectionCell else {
            return UICollectionViewCell()
        }
        
        let data = self.arrPdf?[indexPath.item]
        cell.setupCellDatawith(name: data, index: indexPath.item)
        
        // Button Cashback action Action
        cell.callBack = {(tag, title) in

            print("title of pdf >>", title)
            self.clearAllFilesFromTempDirectory(strname: title)
            
        }

        return cell
    }
    
    
    
    
    
    
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = (self.collectionView.frame.width - 45) / 2
//        let height = width * 1.05
        return CGSize(width: width, height: width)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
//        let data = self.viewModel?.arrData?[indexPath.section]
//        let final = data?.videos?[indexPath.item]
//        print("Final >>", final)
        
        
//        PDFViewer.openPDFViewer(url: url, viewController: self, openFromSideMenu: false) {
//        }

    }
    
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
    }
    

    
}
