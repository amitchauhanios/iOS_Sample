//
//  PDFViewer.swift
//  Dolfil
//
//  Created by Himanshu Goyal on 25/01/21.
//

import UIKit
import PDFKit
import Alamofire

class PDFViewer: UIViewController {
    
    /*
     MARK: Properties
     */
    @IBOutlet weak var btnExit                  : UIButton!
    @IBOutlet weak var pdfView                  : PDFView!
    @IBOutlet weak var pdfThumbnailView         : PDFThumbnailView!
    private var completionBlock                 : PDFViewerCompletionBlock!
    internal typealias PDFViewerCompletionBlock  = () -> Void

    @IBOutlet weak var footerView               : UIView!
    @IBOutlet weak var previousView             : UIView!
    @IBOutlet weak var nextView                 : UIView!
    @IBOutlet weak var btnPrevious              : UIButton!
    @IBOutlet weak var btnNext                  : UIButton!
    @IBOutlet weak var lblPrevious              : UILabel!
    @IBOutlet weak var lblNext                  : UILabel!
    @IBOutlet weak var lblCurrentPage           : UILabel!
    @IBOutlet weak var pageControl              : UIPageControl!
    
    @IBOutlet weak var progressBGBiew           : UIView!
    @IBOutlet weak var progressView             : ProgressBarView!
    @IBOutlet weak var lblProgress              : UILabel!

    
    private var openFromSideMenu : Bool = false
    
    
    //end
    
    /*
     MARK: UIViewController Life Cycle
     */
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setupView()

        NotificationCenter.default.addObserver(self, selector: #selector(handlePageChange(notification:)), name: Notification.Name.PDFViewPageChanged, object: nil)
    }
    
    override func viewWillAppear(_ animated: Bool){
        super.viewWillAppear (animated)
    }

    //end
    
    @objc private func handlePageChange(notification: Notification)
    {
        if let page: PDFPage = pdfView.currentPage {

            let pageNumber = page.pageRef?.pageNumber ?? 0
            let totalPages =  self.pdfView.document?.pageCount ?? 0
            
            self.pageControl.currentPage = pageNumber - 1
            
            if pageNumber == 1{
                self.previousView.isUserInteractionEnabled = false
                self.previousView.alpha = 0.6
                self.nextView.isUserInteractionEnabled = true
                self.nextView.alpha = 1.0
            }else if pageNumber == totalPages{
                self.previousView.isUserInteractionEnabled = true
                self.previousView.alpha = 1.0
                self.nextView.isUserInteractionEnabled = false
                self.nextView.alpha = 0.6
            }else{
                self.previousView.isUserInteractionEnabled = true
                self.previousView.alpha = 1.0
                self.nextView.isUserInteractionEnabled = true
                self.nextView.alpha = 1.0
            }
            
            self.lblCurrentPage.text = "\(pageNumber) of \(totalPages)"
        }
    }
    
    //MARK: - SETUP VIEW
    /// This function is used to setupview
    func setupView(){
        self.btnExit.setTitle("EXIT".localized(), for: .normal)
        self.progressBGBiew.isHidden = true
        self.footerView.isHidden = true
    }
    
    class func openPDFViewer(url: String, viewController: UIViewController? = nil, openFromSideMenu: Bool? = false, completionHandler: @escaping PDFViewerCompletionBlock) {
        
        let story = UIStoryboard(name: "Common", bundle: nil)
        var alert: PDFViewer!
        
        if #available(iOS 13, *) {
            alert = story.instantiateViewController(identifier: "PDFViewer") as? PDFViewer
        } else {
            alert = story.instantiateViewController(withIdentifier: "PDFViewer") as? PDFViewer
        }
        
        alert.completionBlock = completionHandler
        
        alert.openPDFViewer(url: url, viewController: viewController, openFromSideMenu: openFromSideMenu, tapBlock: completionHandler)

    }
    
    private func openPDFViewer(url: String, viewController: UIViewController? = nil, openFromSideMenu: Bool? = false, tapBlock:(() -> Void)){
        
        guard var rootVC = kSharedRootController else {
            return
        }
        
        if let vc = rootVC.presentedViewController {
            rootVC = vc
        }
        
        self.openFromSideMenu = openFromSideMenu ?? false

        self.modalPresentationStyle = UIModalPresentationStyle.overCurrentContext
              
        
        if openFromSideMenu ?? false{
            viewController?.addChildController(content: self, in: viewController?.view)

            viewController?.view.addSubview(self.view)
            
            self.progressBGBiew.isHidden = true
            
            self.footerView.isHidden = true
            
            self.downloadPDF(urlString: url)
            
            self.view.bringSubviewToFront(self.btnExit)
            self.view.bringSubviewToFront(self.footerView)
            self.footerView.bringSubviewToFront(self.previousView)
            self.footerView.bringSubviewToFront(self.nextView)
        }else{
            rootVC.present(self, animated: true) {

                self.progressBGBiew.isHidden = true
                
                self.footerView.isHidden = true
                
                self.downloadPDF(urlString: url)
                
                self.view.bringSubviewToFront(self.btnExit)
                self.view.bringSubviewToFront(self.footerView)
                self.footerView.bringSubviewToFront(self.previousView)
                self.footerView.bringSubviewToFront(self.nextView)
                
            }
        }
    }
    
    
    /*
     MARK: - Open PDF
     - This function is used to open a pdf from Directory
     */
    private func openPDF(_ path: String)
    {
        DispatchQueue.main.async {
            
            self.pdfView.setNeedsLayout()
            self.pdfView.setNeedsDisplay()
            
            if let document = PDFDocument(url: URL.init(string: path)!)
            {
                self.pdfView.document = document
                self.pdfView.displayMode = .singlePageContinuous
                self.pdfView.displayDirection = .horizontal
                self.pdfView.contentMode = .center
                self.pdfView.autoScales = true
                self.pdfView.minScaleFactor = self.pdfView.scaleFactorForSizeToFit
                self.pdfView.scaleFactor = self.pdfView.scaleFactorForSizeToFit
                self.pdfView.autoresizingMask = [.flexibleWidth, .flexibleHeight]

                self.pdfView.reloadInputViews()
                
                if let totalPages: Int = self.pdfView.document?.pageCount {
                    self.pageControl.numberOfPages = totalPages
                    self.pageControl.currentPage = 0

                    if totalPages > 1{
                        self.previousView.isUserInteractionEnabled = true
                        self.previousView.alpha = 1.0
                        self.nextView.isUserInteractionEnabled = true
                        self.nextView.alpha = 1.0
                        self.previousView.isHidden = false
                        self.nextView.isHidden = false
                    }else{
                        self.previousView.isHidden = true
                        self.nextView.isHidden = true
                    }
                    
                    self.lblCurrentPage.text = "\(1) of \(totalPages)"
                    
                }else{
                    self.previousView.isHidden = true
                    self.nextView.isHidden = true
                }
            }else{
                print("INVALID")
            }
        }
    }

    //end

    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    @IBAction func btnExitTapped(_ sender: Any) {
        if self.openFromSideMenu{
            if self.completionBlock != nil{
                self.completionBlock()
            }
            
            self.view.removeFromSuperview()
        }else{
            self.dismiss(animated: true) {
                if self.completionBlock != nil{
                    self.completionBlock()
                }
            }
        }
    }
    
    @IBAction func btnPreviousTapped(_ sender: Any) {
        self.pdfView.goToPreviousPage(sender)
    }
    
    @IBAction func btnNextTapped(_ sender: Any) {
        self.pdfView.goToNextPage(sender)
    }
    

    func downloadPDF(urlString: String) {
        
        self.progressBGBiew.isHidden = false
        
        self.progressView.initHorizontalBar(filledBarColor: UIColor(named: "sky")!, emptyBarColor: UIColor(named: "pale_sky_blue")!)
        
        self.progressView.setHorizontalProgressValue(currentValue: 0)
        
        self.lblProgress.text = "0%"
        
        let fileUrl = self.getSaveFileUrl(fileName: urlString)
        let destination: DownloadRequest.DownloadFileDestination = { _, _ in
            return (fileUrl, [.removePreviousFile, .createIntermediateDirectories])
        }
        
        guard let url = URL(string: urlString) else {
            return
        }
        
        Alamofire.download(url, to:destination)
            .downloadProgress { (progress) in
                let percentage = CGFloat(progress.fractionCompleted) * CGFloat(100)
                let strPercentage = String(format: "%.0f", percentage)
                self.progressView.setHorizontalProgressValue(currentValue: percentage)
                UIView.animate(withDuration: 0.6, delay: 0, options: [.curveEaseInOut], animations: {
                    self.lblProgress.text = strPercentage + "%"
                }, completion: nil)
                
            }
            .responseData { (data) in
                
                UIView.animate(withDuration: 0, delay: 0.5, options: [.curveEaseInOut], animations: {
                    self.progressBGBiew.isHidden = true
                    self.footerView.isHidden = false
                    self.openPDF(data.destinationURL?.absoluteString ?? "")
                }, completion: nil)
                
            }
    }

    func getSaveFileUrl(fileName: String) -> URL {
        let documentsURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let nameUrl = URL(string: fileName)
        let fileURL = documentsURL.appendingPathComponent((nameUrl?.lastPathComponent)!)
        NSLog(fileURL.absoluteString)
        return fileURL;
    }
}

