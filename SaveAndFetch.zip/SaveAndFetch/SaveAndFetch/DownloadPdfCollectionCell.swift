//
//  DownloadPdfCollectionCell.swift
//  SaveAndFetch
//
//  Created by Ongraph on 27/12/21.
//

import UIKit

class DownloadPdfCollectionCell: UICollectionViewCell {

    static let identifier = "DownloadPdfCollectionCell"

    @IBOutlet weak var btnDelete: UIButton!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var viewMain: UIView!

    override func awakeFromNib() {
        super.awakeFromNib()
        
        self.viewMain.layer.cornerRadius = 15.0
        self.viewMain.layer.borderColor = UIColor.purple.cgColor
        self.viewMain.layer.borderWidth = 2.0
        self.viewMain.layer.masksToBounds = true
        self.viewMain.backgroundColor = UIColor.lightGray
        
        // Initialization code
    }
    
    
    var callBack :((_ btnTag : Int,_ btnTitle : String)->())?

    @IBAction func btnDeleteAction(_ sender: UIButton) {
        self.callBack?(sender.tag, self.lblName.text ?? "")

    }
    
    func setupCellDatawith(name : String?, index : Int){
        self.lblName.text = name ?? ""
    }
    
}
