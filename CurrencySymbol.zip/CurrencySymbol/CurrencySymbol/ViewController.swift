//
//  ViewController.swift
//  CurrencySymbol
//
//  Created by Ongraph on 26/01/1940 Saka.
//  Copyright © 1940 Saka Amit. All rights reserved.
//

import UIKit

import CoreTelephony


class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
       let currencySymbol = getCountryName()
        debugPrint("currencySymbol <<", currencySymbol)

       /* let countryCode = NSLocale.current.regionCode
        debugPrint("countryCode <<", countryCode!)
        
        
        let countryCode11 = NSLocale.current.currencySymbol
        debugPrint("countryCode11 <<", countryCode11!)*/

        
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    //Get country from network or locale
    func getCountryName() -> String{
        
        let networkInfo = CTTelephonyNetworkInfo()
        let carrier = networkInfo.subscriberCellularProvider
        
        if carrier?.isoCountryCode != nil {
            debugPrint("carrier?.isoCountryCode", carrier?.isoCountryCode ?? "US")
            let localIdentifier = countryName(countryCode: (carrier?.isoCountryCode)!.uppercased())
            
            debugPrint("carrier?.isoCountryCode", (carrier?.isoCountryCode)!.uppercased())

            let countryCode = NSLocale.current.regionCode
            debugPrint("countryCode <<", countryCode!)
            
            let currencySymbol = NSLocale.current.currencySymbol
            debugPrint("currencySymbol <<", currencySymbol!)

            return currencySymbol!
            
            let locales = NSLocale(localeIdentifier: localIdentifier!)

            if let countryCode = locales.object(forKey: .countryCode) as? String {
                debugPrint(countryCode)
                
                if let country:String = locales.displayName(forKey: .countryCode, value: countryCode) {
                    debugPrint(country)
                    
                    return country
                }
            }
        }else {
            
            let localIdentifier = Locale.current.identifier //returns identifier of your telephones country/region settings
            
            let locales = NSLocale(localeIdentifier: localIdentifier)
            
            if let countryCode = locales.object(forKey: .countryCode) as? String {
                
                if let country:String = locales.displayName(forKey: .countryCode, value: countryCode) {
                    debugPrint(country)
                    
                    return country
                }
            }
        }
        return ""
    }
    
    
    func countryName(countryCode: String) -> String? {
        debugPrint("countryCode << ",countryCode)
        let current = Locale(identifier: "en_US")
        return current.localizedString(forRegionCode: countryCode) ?? nil
    }

}

