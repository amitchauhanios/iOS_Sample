//
//  ViewController.swift
//  languageDemo
//
//  Created by Ongraph on 19/01/1940 Saka.
//  Copyright © 1940 Saka Amit. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var lbl: UILabel!
    @IBOutlet weak var lbl1: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        //    self.navigationItem.title = NSLocalizedString(@"User Record", nil);
        lbl.text = NSLocalizedString("test", comment: "")
        lbl1.text = NSLocalizedString("test1", comment: "")

        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

