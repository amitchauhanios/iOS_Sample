//
//  ViewController.swift
//  SpotifyDemo
//
//  Created by Ongraph Technologies on 03/02/23.
//

import UIKit
import SpotifyLogin
import Alamofire
import Intents
import IntentsUI

class ViewController: UIViewController {
    
    @IBOutlet weak var logInButton: UIButton!
    @IBOutlet weak var tableView: UITableView!
    var token = ""
    var songs = [Song]()
    
    override func viewDidLoad() {

        super.viewDidLoad()
        // Do any additional setup after loading the view.

        NotificationCenter.default.addObserver(self, selector: #selector(loginSuccessful), name: .SpotifyLoginSuccessful, object: nil)
        self.tableView.isHidden = true
        self.checkUserLogIn()
        self.addSiriButton(to: self.view)
        self.setTableView()
    }
    
    func setTableView() {
        self.tableView.dataSource = self
        self.tableView.delegate = self
        self.tableView.reloadData()
    }
    
    func addSiriButton(to view: UIView) {
        if #available(iOS 12.0, *) {
            let button = INUIAddVoiceShortcutButton(style: .whiteOutline)
                button.shortcut = INShortcut(intent: intent )
                button.delegate = self
                button.translatesAutoresizingMaskIntoConstraints = false
                view.addSubview(button)
                view.centerXAnchor.constraint(equalTo: button.centerXAnchor).isActive = true
                view.centerYAnchor.constraint(equalTo: button.centerYAnchor).isActive = true
            }
        
        }
        

    @IBAction func logInTapped() {
        SpotifyLoginPresenter.login(from: self, scopes: [.userLastTrackRead])
    }
    
    func checkUserLogIn() {
        SpotifyLogin.shared.getAccessToken { (accessToken, error) in
            if error != nil {
                // User is not logged in, show log in flow.
                print("Error \(error?.localizedDescription ?? "Error")")
            } else {
                self.logInButton.isHidden = true
                self.tableView.isHidden = false
                self.askForAuthentication()
                if let _accessToken = accessToken {
                    self.token = _accessToken
                }
            }
        }
    }
    
    func askForAuthentication() {
        INPreferences.requestSiriAuthorization { status in
            switch status {
            case .notDetermined:
                print("Status is notDetermined")
            case .restricted:
                print("Status is Restricted)")
            case .denied:
                print("Status is Denied")
            case .authorized:
                print("Status is Authorized")
            @unknown default:
                print("Error")
            }
        }
    }

    @objc func loginSuccessful() {
        self.checkUserLogIn()
    }
    //https://api.spotify.com/v1/me/player/recently-played // Url for Recently played


    func getSongService() {
        NetworkManager.instance.request(method: .get, URLString:"https://api.spotify.com/v1/me/player/currently-playing", parameters: nil, encoding:JSONEncoding.default,headers:CommonClass.sharedInstance.prepareHeader(self.token) ) { success, response, error in
            if success {
                if let data = response {
                    print("Data is \(data)")
                    let songsParser = SongsParser(dict: data)
                    self.songs = songsParser.songs
                    self.tableView.reloadData()
                } else {
                    print("Something went wrong")
                }
            } else {
                print(error?.localizedDescription ?? "Error")
            }
        }
    }

}

extension ViewController {
    @available(iOS 12.0, *)
    public var intent: GetLastTracksIntent {
        let testIntent = GetLastTracksIntent()
        testIntent.suggestedInvocationPhrase = "fetch lists"
        return testIntent
    }
}



extension ViewController: INUIAddVoiceShortcutButtonDelegate {
    @available(iOS 12.0, *)
    func present(_ addVoiceShortcutViewController: INUIAddVoiceShortcutViewController, for addVoiceShortcutButton: INUIAddVoiceShortcutButton) {
        addVoiceShortcutViewController.delegate = self
        addVoiceShortcutViewController.modalPresentationStyle = .formSheet
        present(addVoiceShortcutViewController, animated: true, completion: nil)
    }
    
    @available(iOS 12.0, *)
    func present(_ editVoiceShortcutViewController: INUIEditVoiceShortcutViewController, for addVoiceShortcutButton: INUIAddVoiceShortcutButton) {
        editVoiceShortcutViewController.delegate = self
        editVoiceShortcutViewController.modalPresentationStyle = .formSheet
        present(editVoiceShortcutViewController, animated: true, completion: nil)
    }
    
    
}

extension ViewController: INUIAddVoiceShortcutViewControllerDelegate {
    @available(iOS 12.0, *)
    func addVoiceShortcutViewController(_ controller: INUIAddVoiceShortcutViewController, didFinishWith voiceShortcut: INVoiceShortcut?, error: Error?) {
        controller.dismiss(animated: true, completion: nil)
    }
    
    @available(iOS 12.0, *)
    func addVoiceShortcutViewControllerDidCancel(_ controller: INUIAddVoiceShortcutViewController) {
        controller.dismiss(animated: true, completion: nil)
    }
    
    
}

extension ViewController: INUIEditVoiceShortcutViewControllerDelegate {
    @available(iOS 12.0, *)
    func editVoiceShortcutViewController(_ controller: INUIEditVoiceShortcutViewController, didUpdate voiceShortcut: INVoiceShortcut?, error: Error?) {
        controller.dismiss(animated: true, completion: nil)
    }
    
    @available(iOS 12.0, *)
    func editVoiceShortcutViewController(_ controller: INUIEditVoiceShortcutViewController, didDeleteVoiceShortcutWithIdentifier deletedVoiceShortcutIdentifier: UUID) {
        controller.dismiss(animated: true, completion: nil)
    }
    
    @available(iOS 12.0, *)
    func editVoiceShortcutViewControllerDidCancel(_ controller: INUIEditVoiceShortcutViewController) {
        controller.dismiss(animated: true, completion: nil)
    }
}

class Song {
    
    var name = ""
    
    init() {}
    
    init(_ data : [String:AnyObject]) {
        if let _track = data["track"] as? [String:AnyObject] {
            if let _name = _track["name"] as? String {
                self.name = _name
            }
        }
    }
    
}

class SongsParser: NSObject {
    var songs = [Song]()
    init(dict: [String: AnyObject]){
        if let _items =  dict["items"] as? [[String:AnyObject]] {
            for _item in _items {
                self.songs.append(Song(_item))
            }
        }
    }
}

extension ViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.songs.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SongTableViewCell", for: indexPath) as! SongTableViewCell
        cell.songLabel.text = self.songs[indexPath.row].name
        print("Song Name \(self.songs[indexPath.row].name)")
        cell.selectionStyle = .none
        return cell
    }
    
}
