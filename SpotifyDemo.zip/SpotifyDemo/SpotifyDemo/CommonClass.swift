//
//  CommonClass.swift
//  SpotifyDemo
//
//  Created by Ongraph Technologies on 06/02/23.
//

import Foundation
import UIKit
import Alamofire
import CoreLocation

class CommonClass {
    
    static let sharedInstance = CommonClass()
    
    private init() {}
    
    // For Alert
    func showAlertWithOkay(_ controller: UIViewController, _ message: String,_ title: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: { action in
            alert.dismiss(animated: true)
        }))
        controller.present(alert, animated: true, completion: nil)
    }
    
    func showAlertAndManageOk(_ controller: UIViewController, _ message: String,_ title: String, completion: @escaping ()->()) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: { action in
            alert.dismiss(animated: true)
            completion()
        }))
        controller.present(alert, animated: true, completion: nil)
    }
    
    func prepareHeader(_ token:String) -> HTTPHeaders {
        var header : HTTPHeaders = [:]
        header.update(name: "Authorization", value:"Bearer \(token)" )
        header.update(name:"Content-Type",value:"application/json")
        return header
    }
    
}
