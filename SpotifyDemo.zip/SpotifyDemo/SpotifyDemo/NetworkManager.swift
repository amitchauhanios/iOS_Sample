//
//  NetworkManager.swift
//  SpotifyDemo
//
//  Created by Ongraph Technologies on 06/02/23.
//

import Foundation
import Alamofire

class NetworkManager: NSObject
{
    //MARK: - Variable Declearation
    
    var reachability : NetworkReachabilityManager?
    var alertShowing = false
    static let instance = NetworkManager()
    
    //MARK: - Enum For Method Type
    
    enum Method: String
    {
        case GET_REQUEST = "GET"
        case POST_REQUEST = "POST"
        case PUT_REQUEST = "PUT"
        case DELETE_REQUEST = "DELETE"
        case PATCH_REQUEST = "PATCH"
    }
    
    
    //MARK: - Function For Hitting The Service With Normal Parameters

    
    func request(method: HTTPMethod, URLString: String, parameters: [String : AnyObject]?, encoding: ParameterEncoding, headers:  HTTPHeaders ,completionHandler: @escaping (_ success:Bool,[String : AnyObject]?, NSError?) -> ())
    {
        if Reachability.isConnectedToNetwork() {
            let kApiURL = URLString;
            print("Hit \(kApiURL) with headers \(headers) and Params \(String(describing: parameters))")
            AF.request(kApiURL, method: method, parameters: parameters, encoding: encoding, headers: headers)
                .response(completionHandler: { (response) in
                do
                {
                    if (response.error == nil)
                    {
                        let jsonResult = try JSONSerialization.jsonObject(with: response.data!, options: []) as! [String : AnyObject]
                        completionHandler(true, jsonResult, nil)
                    } else {
                        completionHandler(false, nil, response.error! as NSError)
                    }
                }
                catch let error as NSError
                {
                    completionHandler(false, nil, error)
                }
            })
        } else {
            completionHandler(false ,nil, CustomError.noNetwork as NSError)
        }
    }
    
    //MARK: - Function For Hitting The Service With Image (Multipart Data)
    
    func requestWithImage(image:UIImage,method: HTTPMethod, URLString: String, parameters: [String : AnyObject], encoding: ParameterEncoding, headers:  HTTPHeaders ,completionHandler: @escaping (_ success:Bool,[String : AnyObject]?, NSError?) -> ())
    {
        if Reachability.isConnectedToNetwork() {
            let kApiURL = URLString;
            print("Hit \(kApiURL) with headers \(headers) and Params \(String(describing: parameters))")
            AF.upload(multipartFormData: { multipartFormData in
                let size = CGSize(width: 0, height: 0)
                if (image.size.width != size.width)
                {
                    let imageData = image.jpegData(compressionQuality: 0.5)!
                    multipartFormData.append(imageData, withName: "profile", fileName: "\(imageData)image.jpg", mimeType: "image/jpeg")
                }
                print(parameters)
                for (key, value) in parameters
                {
                    if let v = value as? String, let valueAsData = v.data(using: .utf8) {
                        multipartFormData.append(valueAsData, withName: key)
                    }
                }
            }, to: kApiURL,
                      method : method,
                      headers: headers).response(completionHandler: { (response) in
                print(response)
                do
                {
                    if (response.error == nil)
                    {
                        print(response.data)
                        let jsonResult = try JSONSerialization.jsonObject(with: response.data!, options: []) as! [String : AnyObject]
                        completionHandler(true, jsonResult, nil)
                    }
                    else
                    {
                        print(response.error!)
                        completionHandler(false, nil, response.error! as NSError)
                    }
                }
                catch let error as NSError
                {
                    print(error)
                    completionHandler(false, nil, error)
                    
                }
            })
        } else {
            completionHandler(false ,nil,CustomError.noNetwork as NSError)
        }
    }
    
    //MARK: - Function For Hitting The Service With Multiple Images (Multipart Data)
    
func requestWithImages(images:[UIImage],method: HTTPMethod, URLString: String, parameters: [String : AnyObject]?, encoding: ParameterEncoding, headers:  HTTPHeaders ,completionHandler: @escaping (_ success:Bool,[String : AnyObject]?, NSError?) -> ())
    {
        if Reachability.isConnectedToNetwork() {
            let kApiURL = URLString;
            
            print("Hit \(kApiURL) with headers \(headers) and Params \(String(describing: parameters))")
            
            AF.upload(multipartFormData: { multipartFormData in
                print("Images Count \(images.count)")
                for imageData in images {          let data = imageData.jpegData(compressionQuality: 0.5)!
                    print("Data \(data)")
                    multipartFormData.append(data, withName: "images", fileName: "\(Date().timeIntervalSince1970).jpeg", mimeType: "image/jpeg")
                }
                if let params = parameters {
                    for (key, value) in params {
                        if let v = value as? String, let valueAsData = v.data(using: .utf8) {
                            multipartFormData.append(valueAsData, withName: key)
                        }
                    }
                }
            }, to: kApiURL,
                      method : method,
                      headers: headers).response(completionHandler: { (response) in
                print(" Response \(response)")
                do
                {
                    if (response.error == nil)
                    {
                        let jsonResult = try JSONSerialization.jsonObject(with: response.data!, options: []) as! [String:AnyObject]
                        completionHandler(true, jsonResult, nil)
                    }
                    else
                    {
                        completionHandler(false, nil, response.error! as NSError)
                    }
                }
                catch let error as NSError
                {
                    completionHandler(false, nil, error)

                }
            })
        } else {
            completionHandler(false ,nil,CustomError.noNetwork as NSError)
        }
    }
}

