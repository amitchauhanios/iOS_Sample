//
//  NetworkReachibility.swift
//  SpotifyDemo
//
//  Created by Ongraph Technologies on 06/02/23.
//

import Foundation
import SystemConfiguration

public class Reachability
{
    
    class func isConnectedToNetwork() -> Bool {
        
        var zeroAddress = sockaddr_in()
        zeroAddress.sin_len = UInt8(MemoryLayout.size(ofValue: zeroAddress))
        zeroAddress.sin_family = sa_family_t(AF_INET)
        
        let defaultRouteReachability = withUnsafePointer(to: &zeroAddress) {
            $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {zeroSockAddress in
                SCNetworkReachabilityCreateWithAddress(nil, zeroSockAddress)
            }
        }
        var flags : SCNetworkReachabilityFlags = []
        if !SCNetworkReachabilityGetFlags(defaultRouteReachability!, &flags) {
            return false
        }
        let isReachable = flags.contains(.reachable)
        let needsConnection = flags.contains(.connectionRequired)
        return (isReachable && !needsConnection)
    }
}

public enum CustomError: Error {
    case noNetwork
}

extension CustomError: LocalizedError {
    public var errorDescription: String? {
        switch self {
        case .noNetwork:
            return NSLocalizedString("No internet connection Found", comment: "My error")
        }
    }
}
