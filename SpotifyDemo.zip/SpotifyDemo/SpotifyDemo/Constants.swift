//
//  Constants.swift
//  SpotifyDemo
//
//  Created by Ongraph Technologies on 06/02/23.
//

import Foundation

let redirectUri = URL(string:"SpotifyDemo://")!
let spotifyClientId = "6613d44e791a4e04a4d48bb4bd9dfda8"
let spotifyClientSecretKey = "0927f5dd2e55449dabc8b13c6a811dcd"
