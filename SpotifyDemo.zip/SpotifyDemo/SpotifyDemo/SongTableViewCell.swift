//
//  SongTableViewCell.swift
//  SpotifyDemo
//
//  Created by Ongraph Technologies on 06/02/23.
//

import UIKit

class SongTableViewCell: UITableViewCell {
    
    @IBOutlet weak var songLabel: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
